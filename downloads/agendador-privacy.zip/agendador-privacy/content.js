/* Agendador Privacy — content.js
 * Agenda mensagens em massa no calendário da Privacy.
 * O código da agenda é o mesmo do Chatix; esta extensão só põe ele num painel próprio. */

const esperar = (ms) => new Promise(r => setTimeout(r, ms));

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}


function baixarMapaTela() {
  const linhas = ['URL: ' + location.href];
  const UTEIS = /^(button|input|textarea|select|label|a|form|dialog|option)$/i;
  function attrs(el) {
    const p = [];
    if (el.id) p.push('#' + el.id);
    if (el.className && typeof el.className === 'string') p.push('.' + el.className.trim().split(/\s+/).slice(0, 4).join('.'));
    for (const a of ['type', 'name', 'placeholder', 'aria-label', 'role', 'title', 'href', 'data-testid', 'value']) {
      const v = el.getAttribute?.(a);
      if (v) p.push(`${a}="${String(v).slice(0, 60)}"`);
    }
    return p.join(' ');
  }
  function textoProprio(el) {
    let t = '';
    for (const n of el.childNodes) if (n.nodeType === 3) t += n.textContent;
    return t.trim().replace(/\s+/g, ' ').slice(0, 80);
  }
  function andar(root, nivel) {
    for (const el of root.children || []) {
      const tag = el.tagName.toLowerCase();
      if (tag === 'script' || tag === 'style' || tag === 'svg' || tag === 'path' || el.id === 'acp-embedded') continue;
      const txt = textoProprio(el);
      const temShadow = !!el.shadowRoot;
      if (UTEIS.test(tag) || txt || temShadow || tag.includes('-') || el.getAttribute('role') || /dialog|modal|schedule|agend|date|time|picker|massa|broadcast/i.test(el.className || '')) {
        linhas.push(`${'  '.repeat(Math.min(nivel, 30))}<${tag} ${attrs(el)}>${txt ? ' "' + txt + '"' : ''}${temShadow ? '  [SHADOW]' : ''}`);
      }
      if (el.shadowRoot) andar(el.shadowRoot, nivel + 1);
      andar(el, nivel + 1);
    }
  }
  andar(document.body, 0);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([linhas.join('\n')], { type: 'text/plain' }));
  a.download = 'mapa-privacy.txt';
  a.click();
}

// ═══════════════════════════════════════════════
// PROGRAMAR MENSAGEM EM MASSA (calendário nativo da Privacy)
// Fluxo: Calendário → Criar → Mensagem em massa → data/hora → Confirmar → Todos → Aplicar filtro → mensagem → enviar
// Cada item agendado recarrega /calendar e o content script retoma a fila salva em chrome.storage
// ═══════════════════════════════════════════════

const AGENDA_PROMPT_PADRAO = `# PROMPT — COPYWRITER PRIVACY | CONTEÚDO ADULTO

Você é um copywriter especializado em marketing para criadoras de conteúdo adulto (18+) na plataforma Privacy.

Sua função é criar mensagens que pareçam escritas naturalmente pela própria criadora, com foco em despertar curiosidade, gerar respostas no chat e converter assinantes em compradores de PPV, packs e videochamadas.

## 1. ESTILO PRINCIPAL — MENSAGENS NATURAIS

As mensagens precisam ser:

- Curtas, íntimas, espontâneas e provocantes.
- Escritas como uma conversa real, não como propaganda.
- Com linguagem brasileira informal: "mo", "bb", "amor", "neném", "vida", "rsrs", "kkkk", "hihi".
- Com 0 a 2 emojis, quando fizer sentido: 🙈 🥺 🖤 😈 🤭 💗.
- Com perguntas que estimulem respostas.
- Com CTAs simples e diretos.

Exemplos de estilo:

"mo, cê sumiu… volta aqui pra conversar comigo? 🥺"

"tô aqui sozinha e lembrei de você rsrs 🙈"

"um presentinho pra animar sua tarde, neném 🎁"

"gravei uma coisinha hoje… quer ver? 🤭"

"bb, achei um vídeo antigo na minha galeria kkkkk"

"passa aqui no chat rapidinho, amor?"

"essa foto é só um convite… quer descobrir o resto?"

"mo, não vou te mandar só uma fotinha hoje não rsrs"

## 2. ESTILO SECUNDÁRIO — TÍTULOS DE PPV

Misture o estilo natural com títulos chamativos de conteúdo adulto.

Temas permitidos:

- Universitária adulta (18+).
- Look de universitária e saia xadrez.
- Vídeo caseiro.
- POV.
- Vídeo completo.
- Gravação encontrada na galeria.
- Bastidores e conteúdo exclusivo.
- Packs de fotos e vídeos.

Exemplos:

"POV: CHEGUEI DA FACULDADE E GRAVEI UMA SURPRESA 🙈"

"(VÍDEO NOVO) mo, olha o que eu encontrei na galeria rsrs"

"UNIVERSITÁRIA DE 18 ANOS — VÍDEO CASEIRO COMPLETO"

"bb, coloquei minha sainha xadrez e resolvi gravar 🤭"

Use somente personagens claramente adultos. Não crie situações envolvendo menores ou alegações falsas de vazamento.

## 3. TIPOS DE COPY

1. Bom dia, boa tarde e boa noite.
2. Aquecimento e abertura de conversa.
3. Reativação de assinantes que sumiram.
4. Venda de PPV e vídeos completos.
5. Venda de packs.
6. Convites para videochamadas.
7. Promoções reais e ofertas especiais.
8. Lançamento de vídeos novos.
9. Remarketing para quem não desbloqueou.
10. Temática de universitária adulta.

## 4. CTAs

Priorize CTAs que indiquem claramente a próxima ação:

- "vem ver, amor?"
- "abre o cadeadinho?"
- "desbloqueia pra ver?"
- "volta aqui no chat?"
- "quer que eu te mostre?"
- "vem assistir o vídeo completo"
- "topa uma chamadinha?"
- "libera e depois me conta se gostou?"

Evite terminar todas as mensagens da mesma forma.

## 5. REGRAS DE CONVERSÃO

- A primeira frase deve chamar atenção na prévia da caixa de entrada.
- Alterne mensagens muito curtas com mensagens de duas frases.
- Crie curiosidade usando detalhes concretos.
- Evite frases genéricas como "conteúdo imperdível" e "experiência inesquecível".
- Não repita sempre a mesma estrutura.
- Não use letras maiúsculas em todas as mensagens.
- Não invente descontos, escassez, vídeos ou disponibilidade.
- Não prometa algo que a criadora não oferece.
- Não afirme que um vídeo vazou se isso não for verdade.
- Mantenha a linguagem sensual e comercial sem descrições sexuais gráficas.

## 6. REGRA MAIS IMPORTANTE

Combine sempre os DOIS estilos:

**70% mensagem íntima e natural + 30% título chamativo de PPV.**

O resultado precisa parecer uma mensagem espontânea da própria criadora, com curiosidade e uma chamada clara para ação.

A copy deve fazer o assinante pensar: "quero abrir isso agora".

## 7. MENSAGEM EM MASSA (CHATIX)

- Cada mensagem vai pra TODOS os assinantes de uma vez: nunca use nome de fã.
- Vou te passar o horário de envio de cada mensagem; adapte ao momento do dia quando fizer sentido (bom dia, almoço, tarde, noite, madrugada), sem forçar em todas.
- Mensagens do mesmo dia precisam ser bem diferentes entre si (tipo de copy, abertura e CTA).
- Se eu NÃO passar um ASSUNTO PRINCIPAL, os disparos são SÓ DE AQUECIMENTO (isto vale acima das seções 2, 4 e 6): o único objetivo é fazer o assinante responder no chat.
- No aquecimento, tipos permitidos: bom dia/boa tarde/boa noite, abertura de conversa, saudade, reativação de quem sumiu, curiosidade leve.
- No aquecimento é proibido: título de PPV, texto em maiúsculas, falar de preço, pack, vídeo completo, desbloquear, cadeadinho ou chamada de vídeo.
- Se eu passar um ASSUNTO PRINCIPAL (sexting, chamada de vídeo, desconto...), as mensagens giram em torno dele, sempre chamando pra combinar no chat ("me chama aqui", "quer saber como funciona?"). Ainda nada de maiúsculas em todas nem cara de propaganda.
- Valor, porcentagem e prazo de desconto: use SÓ o que eu passar no detalhe da oferta. Se eu não passar, fale do desconto sem citar número nem prazo.
- Termine com pergunta ou convite pra responder (ex.: "cê tá aí?", "me conta?", "volta aqui no chat?"), variando sempre.
- Máximo de 2 linhas por mensagem; muitas devem ter 1 linha só. Varie o formato (só pergunta, só provocação leve, frase única).
- Formato: entregue só as mensagens, na ordem pedida, SEM numeração e SEM explicações, separadas por uma linha contendo apenas ---`;

const _AGENDA_CFG_PADRAO = {
  dias: [],
  horarios: '09:00, 12:00, 15:00, 18:00, 20:00, 22:00',
  limiteDia: 10,
  briefing: '',
  mensagens: '',
  prompt: '',
  teste: true,
  tiposCopy: ['bomdia', 'conversa', 'saudade', 'sumiu', 'curiosidade', 'provocante'],
  emojiCopy: 'misto',
  oferta: '',
  // Modelos e pacotes começam vazios: cada PC configura o seu ou importa um backup (botão no topo)
  modelo: '',
  pacotesReg: [],
  packProx: 0,
  videoProx: 0,
  persona: 'ketlin',
  personas: [
    { id: 'ketlin', nome: 'Ketlin', desc: 'Professora adulta, uns 30 anos. Séria na sala de aula, safadinha fora dela. Fala de correção de prova, aluno chato, sala dos professores, "depois da aula". Tom de quem manda, mas carinhosa.' },
    { id: 'leticia', nome: 'Letícia', desc: 'Universitária de 20 anos. Fala de faculdade, prova, trabalho em grupo, república, festa, ônibus lotado. Jeitinho meiga e tímida, mas curiosa.' },
    { id: 'marjorie', nome: 'Marjorie', desc: 'Garçonete adulta, uns 25 anos. Fala de turno no bar/restaurante, cliente que dá em cima, uniforme apertado, chegando cansada em casa. Descontraída e provocadora.' }
  ]
};

// Tipos de copy de aquecimento: id → [rótulo do botão, instrução pra IA]
const _TIPOS_COPY = {
  bomdia: ['☀️ Bom dia/noite', 'cumprimento do momento do dia (bom dia, boa tarde, boa noite, madrugada)'],
  conversa: ['💬 Puxar papo', 'abrir conversa com pergunta do dia a dia'],
  saudade: ['🥺 Saudade', 'saudade e carência, "lembrei de você"'],
  sumiu: ['👻 Quem sumiu', 'chamar de volta quem sumiu do chat'],
  curiosidade: ['🤭 Curiosidade', 'criar curiosidade leve sem vender nada'],
  provocante: ['😈 Provocante', 'provocação leve e sensual, sem nada explícito']
};
// Assunto principal do disparo: id → [rótulo do botão, instrução pra IA]
const _ASSUNTOS_COPY = {
  aquecimento: ['🔥 Aquecer', 'aquecimento (só puxar conversa, sem vender nada)'],
  sexting: ['💋 Sexting', 'vender sexting: conversa quente por mensagem no chat, com fotos e áudios na hora'],
  chamada: ['📹 Chamada', 'vender videochamada (chamadinha) ao vivo com ela'],
  desc_chamada: ['💸 Promo chamada', 'promoção com desconto na videochamada'],
  desc_sexting: ['🎁 Promo sexting', 'promoção com desconto no sexting'],
  // Pack não passa pela IA: anexa o pacote do Acervo e usa o texto do próprio pacote
  pack: ['📦 Pack', 'pacote do Acervo'],
  video: ['🎬 Vídeo', 'vídeo único (pacote com prévia + vídeo) do Acervo']
};
// Modelos prontos de roteiro: [rótulo, sequência de assuntos ao longo do dia]
const _MODELOS_ROTEIRO = [
  ['🔥 Só aquecer', 'aquecimento'],
  ['🔥→📹', 'aquecimento,chamada'],
  ['🔥→💋', 'aquecimento,sexting'],
  ['🔥→💋→📹', 'aquecimento,sexting,chamada'],
  ['🔥→💸', 'aquecimento,desc_chamada'],
  ['🔥→📦', 'aquecimento,pack'],
  ['🔥→📦→📹', 'aquecimento,pack,chamada'],
  ['🔥→🎬→📦', 'aquecimento,video,pack']
];
const _EMOJI_COPY = {
  com: ['🙂 Com emoji', 'use 1 ou 2 emojis em toda mensagem'],
  misto: ['🎲 Misturado', 'use emoji em mais ou menos metade das mensagens'],
  sem: ['🚫 Sem emoji', 'não use nenhum emoji']
};
const _MESES_PT = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const _DIAS_SEMANA_PT = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
let _agendaProgresso = '';

async function obterAgendaCfg() {
  const { acp_agenda_cfg } = await chrome.storage.local.get('acp_agenda_cfg');
  const padrao = structuredClone(_AGENDA_CFG_PADRAO);
  const cfg = { ...padrao, ...(acp_agenda_cfg || {}) };
  const hoje = _dataISO(new Date());
  cfg.dias = cfg.dias.filter(d => d >= hoje);
  return cfg;
}

async function salvarAgendaCfg(cfg) {
  await chrome.storage.local.set({ acp_agenda_cfg: cfg });
}

function _dataISO(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function _horariosValidos(texto, limite) {
  const horas = (texto || '').split(/[,;\s]+/)
    .map(h => h.trim())
    .filter(h => /^\d{1,2}:\d{2}$/.test(h))
    .map(h => h.padStart(5, '0'))
    .filter(h => parseInt(h) < 24 && parseInt(h.slice(3)) < 60);
  return [...new Set(horas)].sort().slice(0, limite || 10);
}

function _separarMensagens(texto) {
  return (texto || '').split(/\n\s*\n/).map(s => s.trim()).filter(Boolean);
}

function montarPlanoAgenda(cfg) {
  const horas = _horariosValidos(cfg.horarios, cfg.limiteDia);
  const minimo = Date.now() + 10 * 60 * 1000;
  const itens = [];
  for (const dia of [...cfg.dias].sort()) {
    const [Y, M, D] = dia.split('-').map(Number);
    for (const h of horas) {
      const [hh, mm] = h.split(':').map(Number);
      if (new Date(Y, M - 1, D, hh, mm).getTime() < minimo) continue;
      itens.push({ dia, hora: h });
    }
  }
  return itens;
}

// Assunto (id) de cada horário, escolhido no roteiro (cfg.roteiroHoras); sem escolha = aquecimento.
// Tudo aquecimento → [] (sem roteiro, a IA segue a regra padrão de só aquecer).
function _assuntoDaHora(cfg, hora) {
  const a = cfg.roteiroHoras?.[hora];
  return _ASSUNTOS_COPY[a] ? a : 'aquecimento';
}

// ── Mensagens por horário ──
// cfg.msgsMapa = { 'AAAA-MM-DD HH:MM': texto }; sem dia escolhido a chave é ' HH:MM'
const HISTORICO_MAX = 80;
const _chaveMsg = (it) => `${it.dia || ''} ${it.hora}`;

// Horários que levam texto (não são pack/vídeo), na ordem em que saem: [{ dia, hora, assunto }]
function _slotsTexto(cfg) {
  const plano = montarPlanoAgenda(cfg);
  const itens = plano.length ? plano : _horariosValidos(cfg.horarios, cfg.limiteDia).map(hora => ({ dia: '', hora }));
  return itens.map(it => ({ dia: it.dia, hora: it.hora, assunto: _assuntoDaHora(cfg, it.hora) })).filter(it => !_ACERVO_PROX[it.assunto]);
}

// Mapa de mensagens; config antiga (um texto só, em rodízio) vira mapa na ordem dos horários
function _msgsMapa(cfg) {
  if (!cfg.msgsMapa) {
    cfg.msgsMapa = {};
    const antigas = _separarMensagens(cfg.mensagens);
    _slotsTexto(cfg).forEach((it, i) => { if (antigas[i]) cfg.msgsMapa[_chaveMsg(it)] = antigas[i]; });
    antigas.slice(_slotsTexto(cfg).length).forEach((t, i) => { cfg.msgsMapa['extra ' + i] = t; });
  }
  return cfg.msgsMapa;
}

const _msgDoHorario = (mapa, it) => (mapa[_chaveMsg(it)] || mapa[_chaveMsg({ hora: it.hora })] || '').trim();
const _msgsPool = (mapa) => [...new Set(Object.values(mapa).map(t => (t || '').trim()).filter(Boolean))];

// Texto da persona que vai pra IA (campos guiados + exemplos). Sem persona → ''
function _textoPersona(p) {
  if (!p) return '';
  const idade = Math.max(18, parseInt(p.idade) || 0);
  const exemplos = _separarMensagens(p.exemplos);
  return [
    `Nome: ${p.nome || 'sem nome'}`,
    p.idade ? `Idade: ${idade} anos (adulta)` : '',
    p.desc ? `Quem ela é: ${p.desc}` : '',
    p.jeito ? `Jeito de falar: ${p.jeito}` : '',
    p.nunca ? `Nunca diz / nunca faz: ${p.nunca}` : '',
    exemplos.length ? `Exemplos reais de como ela escreve (imite o estilo, o tamanho e o vocabulário; NÃO copie):\n${exemplos.map(t => '- ' + t.replace(/\s+/g, ' ')).join('\n')}` : ''
  ].filter(Boolean).join('\n');
}

// Modelo pronto → divide os horários do dia em blocos seguidos na ordem da sequência ({hora: assunto})
function _distribuirRoteiro(seq, horas) {
  const mapa = {};
  horas.forEach((h, i) => { mapa[h] = seq[Math.floor(i * seq.length / horas.length)]; });
  return mapa;
}

// Modelos do registro de pacotes (separadas da persona da IA). Sem lista salva, começa com os nomes das personas.
function _modelosPack(cfg) {
  if (!cfg.modelos) cfg.modelos = (cfg.personas || []).map(p => ({ id: p.id, nome: p.nome }));
  return cfg.modelos;
}

function _nomeModeloPack(cfg) {
  return _modelosPack(cfg).find(m => m.id === cfg.modelo)?.nome || 'nenhuma modelo';
}

// Pacote pertence à modelo escolhida no registro? Sem modelo escolhida = nenhum
function _pacoteDaModelo(cfg, p) {
  return !!cfg.modelo && (p.modelo || p.persona) === cfg.modelo;
}

// Pacote sem modelo ou de uma modelo que foi apagada
function _pacoteSemModelo(cfg, p) {
  const id = p.modelo || p.persona;
  return !id || !_modelosPack(cfg).some(m => m.id === id);
}

// Pacotes do registro marcados pro rodízio (precisam de preço ou nome pra achar no Acervo), só da modelo escolhida
function _listaPacotes(cfg, tipo = 'pack') {
  return (cfg.pacotesReg || []).filter(p => p.usar && (p.preco || p.nome) && (p.tipo || 'pack') === tipo && _pacoteDaModelo(cfg, p));
}

// Assuntos que anexam pacote do Acervo → campo do cfg que guarda o próximo do rodízio
const _ACERVO_PROX = { pack: 'packProx', video: 'videoProx' };

// Próximo do rodízio é separado por modelo (cfg.proxModelo[persona][assunto]); sem registro usa o antigo global
function _proxRodizio(cfg, assunto) {
  return cfg.proxModelo?.[cfg.modelo || '']?.[assunto] ?? (cfg[_ACERVO_PROX[assunto]] || 0);
}

// Agrupa as falhas da programação por motivo: "12× motivo (20/10 14:00, ...)"
function _resumoFalhas(falhas) {
  const grupos = new Map();
  for (const f of falhas || []) {
    const m = f.match(/^(\d{4})-(\d\d)-(\d\d) (\d\d:\d\d): ([\s\S]*)$/);
    const motivo = m ? m[5] : f;
    if (!grupos.has(motivo)) grupos.set(motivo, []);
    if (m) grupos.get(motivo).push(`${m[3]}/${m[2]} ${m[4]}`);
  }
  return [...grupos].sort((a, b) => b[1].length - a[1].length)
    .map(([motivo, quando]) => `${quando.length || 1}× ${motivo}${quando.length ? ` (${quando.slice(0, 6).join(', ')}${quando.length > 6 ? '…' : ''})` : ''}`)
    .join('\n');
}

function _rotuloPacote(p) {
  return `${p.apelido || p.nome || 'pacote'} (R$ ${p.preco || '?'})`;
}

function _roteiroAssuntos(cfg, itens) {
  const ids = itens.map(it => _assuntoDaHora(cfg, it.hora));
  return ids.every(a => a === 'aquecimento') ? [] : ids;
}

// ── UI (aba Disparo) ──

async function renderizarSecaoAgendaMassa(content) {
  const cfg = await obterAgendaCfg();
  const hoje = new Date();
  const opcoesDias = [];
  for (let i = 0; i < 14; i++) {
    const d = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() + i);
    const iso = _dataISO(d);
    const rotulo = i === 0 ? 'Hoje' : i === 1 ? 'Amanhã' : `${_DIAS_SEMANA_PT[d.getDay()]} ${d.getDate()}`;
    opcoesDias.push(`<button class="acp-pill ${cfg.dias.includes(iso) ? 'acp-pill-ativo' : ''}" data-dia="${iso}">${rotulo}</button>`);
  }

  const horasMarcadas = _horariosValidos(cfg.horarios, 99);

  content.insertAdjacentHTML('beforeend', `
    <div id="acp-agenda-sec">
      <div id="acp-modelo-bar">
        <div id="acp-modelo-card-info"></div>
        <button class="acp-pill" id="acp-modelo-detectar"></button>
      </div>

      <div id="acp-header">
        <div id="acp-tabs">
          <button class="acp-tab acp-tab-ativa" data-abatab="quando">${icone('calendario')}Quando</button>
          <button class="acp-tab" data-abatab="agitacao">${icone('raio')}Agitação</button>
          <button class="acp-tab" data-abatab="persona">${icone('pessoa')}Persona</button>
          <button class="acp-tab" data-abatab="copy">${icone('brilho')}Copy</button>
          <button class="acp-tab" data-abatab="roteiro">${icone('lista')}Roteiro</button>
          <button class="acp-tab" data-abatab="pacotes">${icone('pacote')}Pacotes</button>
        </div>
      </div>

      <div class="acp-abatab-painel" data-abatab-painel="quando">
        <div class="acp-card">
          <div class="acp-card-label">${icone('calendario')}Dias</div>
          <div class="agd-atalhos" id="acp-dias-atalhos">
            <button data-atalho="semana" title="Hoje e os próximos 6 dias">Próx. 7 dias</button>
            <button data-atalho="uteis" title="Segunda a sexta dos próximos 7 dias">Dias úteis</button>
            <button data-atalho="fds" title="Sábado e domingo dos próximos 7 dias">Fim de semana</button>
            <button data-atalho="limpar">Limpar</button>
          </div>
          <div class="agd-grade-dias" id="acp-agenda-dias">${opcoesDias.join('')}</div>
        </div>

        <div class="acp-card">
          <div class="acp-card-label">${icone('relogio')}Horários <span class="agd-label-extra" id="acp-agenda-horas-info"></span></div>
          <div class="agd-agitada" data-agitada hidden>
            <span class="agd-agitada-txt">${icone('raio')}<span data-agitada-txt></span></span>
            <button class="agd-agitada-btn" data-agitacao="desfazer">Tirar agitação</button>
          </div>
          <div class="agd-grade-horas" id="acp-agenda-horarios"></div>
          <label class="agd-linha-campo">
            Máximo de disparos por dia
            <input class="acp-save-input" id="acp-agenda-limite" type="number" min="1" max="30" value="${cfg.limiteDia}">
          </label>
        </div>
      </div>

      <div class="acp-abatab-painel" data-abatab-painel="agitacao" hidden>
        <div class="acp-card">
          <div class="acp-card-label">${icone('raio')}Vários disparos por hora</div>
          <div class="agd-dica">Preenche os horários sozinho: tantos disparos por hora, espalhados dentro de cada hora, no período que você escolher.</div>
          <div class="agd-grade-3">
            <label class="agd-campo"><span>Por hora</span><input class="acp-save-input" id="acp-agitacao-qtd" type="number" min="1" max="12" value="5"></label>
            <label class="agd-campo"><span>Das</span><input class="acp-save-input" id="acp-agitacao-de" type="time" value="08:00"></label>
            <label class="agd-campo"><span>Até</span><input class="acp-save-input" id="acp-agitacao-ate" type="time" value="23:00"></label>
          </div>
          <button class="acp-save-btn" id="acp-agitacao-aplicar">${icone('raio')}Aplicar nos horários</button>
          <div class="agd-status" id="acp-agitacao-status"></div>
          <div class="agd-agitada agd-agitada-card" data-agitada hidden>
            <span class="agd-agitada-txt">${icone('raio')}<span data-agitada-txt></span></span>
            <div class="agd-agitada-acoes">
              <button class="agd-agitada-btn" data-agitacao="desfazer" title="Volta os horários (e o roteiro) de antes de aplicar a agitação">Tirar agitação</button>
              <button class="agd-agitada-btn agd-agitada-sec" data-agitacao="um" title="Mantém as mesmas horas, mas só 1 disparo em cada (hora cheia)">Deixar 1 por hora</button>
            </div>
          </div>
        </div>
      </div>

      <div class="acp-abatab-painel" data-abatab-painel="persona" hidden>
        <div class="acp-card">
          <div class="acp-card-label">${icone('pessoa')}Persona</div>
          <div class="agd-dica">Quem "escreve" as copies. Vincule cada persona à conta da modelo: ao detectar a conta, a persona certa já vem escolhida.</div>
          <div class="acp-pills" id="acp-agenda-personas"></div>
          <div class="agd-aviso-box" id="acp-persona-aviso" hidden></div>
          <div class="agd-espaco" id="acp-agenda-persona-edit"></div>
        </div>
      </div>

      <div class="acp-abatab-painel" data-abatab-painel="copy" hidden>
        <div class="agd-aviso-box agd-sem-chave" id="acp-sem-chave" hidden>${icone('alerta')}<span>Falta a chave da OpenRouter pra IA funcionar.</span><button class="agd-link" data-abrir-config>Configurar</button></div>
        <div class="acp-card">
          <div class="acp-card-label">${icone('brilho')}Copy com IA</div>
          <div class="agd-sub-label">Jeito de chamar <em class="agd-campo-uso">só nos horários de 🔥 Aquecer</em></div>
          <div class="acp-pills" id="acp-agenda-tipos">
            ${Object.entries(_TIPOS_COPY).map(([id, [rotulo]]) =>
              `<button class="acp-pill ${cfg.tiposCopy.includes(id) ? 'acp-pill-ativo' : ''}" data-tipo="${id}">${rotulo}</button>`).join('')}
          </div>
          <div class="agd-sub-label">Emojis</div>
          <div class="acp-pills" id="acp-agenda-emoji">
            ${Object.entries(_EMOJI_COPY).map(([id, [rotulo]]) =>
              `<button class="acp-pill ${cfg.emojiCopy === id ? 'acp-pill-ativo' : ''}" data-emoji="${id}">${rotulo}</button>`).join('')}
          </div>
          <label class="agd-campo">
            <span>Tema (opcional)</span>
            <input class="acp-save-input" id="acp-agenda-briefing" placeholder="ex. foto nova de lingerie, promo no PPV..." value="${escapeHtml(cfg.briefing)}">
          </label>
          <button class="acp-save-btn" id="acp-agenda-gerar">${icone('brilho')}Gerar copies</button>
          <button class="agd-link agd-link-centro" id="acp-agenda-refazer" hidden>Refazer todas</button>
          <div class="agd-historico" id="acp-historico"></div>
          <details>
            <summary>Prompt da IA (cole aqui as instruções do seu GPT)</summary>
            <textarea class="acp-disparo-msg agd-txt-prompt" id="acp-agenda-prompt">${escapeHtml(cfg.prompt || AGENDA_PROMPT_PADRAO)}</textarea>
            <div class="agd-prompt-acoes"><span id="acp-prompt-estado"></span><button class="agd-link" id="acp-prompt-restaurar">${icone('atualizar')}Restaurar padrão</button></div>
          </details>
        </div>

        <div class="acp-card">
          <div class="acp-card-label">${icone('mensagem')}Mensagens <span class="agd-label-extra" id="acp-msgs-info"></span></div>
          <div class="agd-dica">Uma mensagem por horário, na ordem em que saem. ↻ gera de novo só aquela. Horário vazio repete uma das outras.</div>
          <div id="acp-msgs-lista"></div>
          <details>
            <summary>Colar várias de uma vez</summary>
            <textarea class="acp-disparo-msg agd-txt-msgs" id="acp-msgs-colar" placeholder="Uma por bloco, separadas por linha em branco. Preenche os horários na ordem, do primeiro ao último."></textarea>
            <div class="agd-prompt-acoes"><span></span><button class="acp-save-btn agd-btn-auto" id="acp-msgs-aplicar">Preencher horários</button></div>
          </details>
        </div>
      </div>

      <div class="acp-abatab-painel" data-abatab-painel="roteiro" hidden>
        <div class="acp-card">
          <div class="acp-card-label">${icone('lista')}Roteiro do dia
            <button class="agd-link" id="acp-roteiro-limpar" title="Volta todos os horários pra 🔥 Aquecer">${icone('atualizar')}Limpar</button>
          </div>
          <div class="agd-sub-label">Modelos prontos <span class="agd-roteiro-estado" id="acp-roteiro-estado"></span></div>
          <div class="acp-pills" id="acp-roteiro-modelos">
            ${_MODELOS_ROTEIRO.map(([rotulo, seq]) => `<button class="acp-pill" data-modelo="${seq}">${rotulo}</button>`).join('')}
          </div>
          <div id="acp-roteiro-resumo"></div>
          <div id="acp-agenda-ordem"></div>
          <label class="agd-campo agd-espaco" id="acp-agenda-oferta-campo">
            <span>Detalhe da oferta <em class="agd-campo-uso" id="acp-agenda-oferta-uso"></em></span>
            <input class="acp-save-input" id="acp-agenda-oferta" placeholder="ex. chamada 10min R$50, 30% off até domingo" value="${escapeHtml(cfg.oferta)}">
          </label>
        </div>
      </div>

      <div class="acp-abatab-painel" data-abatab-painel="pacotes" hidden>
        <div class="acp-card">
          <div class="acp-card-label">${icone('pacote')}Registro de pacotes</div>
          <div class="agd-dica">Marque ✓ os que entram no rodízio. O nome tem que ser igual ao do Acervo › Pacotes.</div>
          <div class="agd-sub-label">Modelo</div>
          <div class="acp-pills" id="acp-agenda-modelos-pack"></div>
          <div id="acp-agenda-pacotes"></div>
          <div class="agd-linha agd-espaco">
            <button class="acp-pill" data-pacote-novo="pack">${icone('mais')}📦 Pack</button>
            <button class="acp-pill" data-pacote-novo="video">${icone('mais')}🎬 Vídeo</button>
          </div>
          <button class="acp-save-btn" id="acp-agenda-sync-acervo">${icone('atualizar')}Sincronizar pacotes do Acervo</button>
          <div class="agd-status" id="acp-agenda-sync-status"></div>
          <div class="agd-prox" id="acp-agenda-pack-prox"></div>
        </div>
      </div>

      <div id="agd-rodape">
        <div class="acp-progress-bar" id="acp-agenda-progresso" ${_agendaProgresso ? '' : 'hidden'}>
          <div class="acp-progress-text">${escapeHtml(_agendaProgresso)}</div>
        </div>
        <div id="acp-agenda-ultimo" hidden></div>
        <div class="agd-rodape-linha">
          <label class="agd-switch" title="Agenda só 1 disparo pra conferir se está tudo certo">
            <input type="checkbox" id="acp-agenda-teste" ${cfg.teste ? 'checked' : ''}>
            Modo teste
          </label>
          <button class="acp-big-btn" id="acp-agenda-programar">Programar</button>
        </div>
      </div>
    </div>`);

  const sec = content.querySelector('#acp-agenda-sec');
  const q = (s) => sec.querySelector(s);

  sec.querySelectorAll('#acp-tabs .acp-tab').forEach(btn => btn.addEventListener('click', () => {
    sec.querySelectorAll('#acp-tabs .acp-tab').forEach(b => b.classList.remove('acp-tab-ativa'));
    btn.classList.add('acp-tab-ativa');
    const alvo = btn.dataset.abatab;
    sec.querySelectorAll('[data-abatab-painel]').forEach(p => { p.hidden = p.dataset.abatabPainel !== alvo; });
    content.scrollTop = 0;
  }));

  const lerCfg = () => ({
    ...cfg,
    dias: [...sec.querySelectorAll('#acp-agenda-dias .acp-pill-ativo')].map(p => p.dataset.dia),
    horarios: [...sec.querySelectorAll('#acp-agenda-horarios .acp-pill-ativo')].flatMap(p => (p.dataset.horas || '').split(',').filter(Boolean)).join(', '),
    limiteDia: Math.max(1, parseInt(q('#acp-agenda-limite').value) || 10),
    briefing: q('#acp-agenda-briefing').value,
    mensagens: cfg.mensagens || '',
    msgsMapa: _msgsMapa(cfg),
    historicoCopies: cfg.historicoCopies || [],
    prompt: q('#acp-agenda-prompt').value.trim() === AGENDA_PROMPT_PADRAO ? '' : q('#acp-agenda-prompt').value,
    teste: q('#acp-agenda-teste').checked,
    tiposCopy: [...sec.querySelectorAll('#acp-agenda-tipos .acp-pill-ativo')].map(p => p.dataset.tipo),
    emojiCopy: sec.querySelector('#acp-agenda-emoji .acp-pill-ativo')?.dataset.emoji || 'misto',
    oferta: q('#acp-agenda-oferta').value,
    pacotesReg: cfg.pacotesReg,
    proxModelo: cfg.proxModelo || {},
    modelos: _modelosPack(cfg),
    modelo: cfg.modelo || '',
    roteiroHoras: cfg.roteiroHoras || {},
    persona: cfg.persona,
    personas: cfg.personas
  });

  // Personas: pílula "Sem persona" + uma por persona + Nova; editor em campos guiados da escolhida
  const contaAtiva = () => cfg.modeloAtivo?.handle || '';
  const renderPersonas = () => {
    const atual = cfg.personas.find(p => p.id === cfg.persona);
    const conta = contaAtiva();
    q('#acp-agenda-personas').innerHTML =
      `<button class="acp-pill ${atual ? '' : 'acp-pill-ativo'}" data-persona="">Sem persona</button>`
      + cfg.personas.map(p =>
        `<button class="acp-pill ${cfg.persona === p.id ? 'acp-pill-ativo' : ''}" data-persona="${p.id}" title="${p.conta ? 'Conta ' + escapeHtml(p.conta) : 'Sem conta vinculada'}">${escapeHtml(p.nome || 'Sem nome')}${p.conta && p.conta === conta ? ' ✓' : ''}</button>`).join('')
      + `<button class="acp-pill" data-persona="+">${icone('mais')}Nova</button>`;

    // Aviso: persona escolhida é de outra conta, ou a conta ativa tem outra persona vinculada
    const daConta = conta && cfg.personas.find(p => p.conta === conta);
    const aviso = q('#acp-persona-aviso');
    let txtAviso = '';
    if (atual?.conta && conta && atual.conta !== conta) txtAviso = `${atual.nome} é da conta ${atual.conta}, mas a conta ativa é ${conta}.`;
    else if (daConta && daConta !== atual) txtAviso = `A conta ativa (${conta}) é da persona ${daConta.nome}.`;
    aviso.hidden = !txtAviso;
    aviso.innerHTML = txtAviso ? `${icone('alerta')}<span>${escapeHtml(txtAviso)}</span>${daConta && daConta !== atual ? `<button class="agd-link" data-persona-usar="${daConta.id}">Usar ${escapeHtml(daConta.nome)}</button>` : ''}` : '';

    const campo = (id, rotulo, html) => `<label class="agd-campo agd-espaco"><span>${rotulo}</span>${html}</label>`;
    q('#acp-agenda-persona-edit').innerHTML = atual ? `
      <div class="agd-persona-linha">
        ${campo('nome', 'Nome', `<input class="acp-save-input" data-campo="nome" placeholder="Nome" value="${escapeHtml(atual.nome)}">`)}
        ${campo('idade', 'Idade', `<input class="acp-save-input" data-campo="idade" type="number" min="18" max="70" placeholder="18+" value="${escapeHtml(atual.idade || '')}">`)}
        <button class="agd-btn-icone agd-perigo" id="acp-persona-apagar" title="Apagar persona">${icone('lixo')}</button>
      </div>
      <div class="agd-erro" id="acp-persona-idade-erro" hidden>A idade mínima é 18 anos.</div>
      <div class="agd-persona-conta">
        ${icone('pessoa')}
        <span>${atual.conta ? `Conta vinculada: <b>${escapeHtml(atual.conta)}</b>` : 'Sem conta vinculada'}</span>
        <span class="agd-pc-acoes">${conta && atual.conta !== conta ? `<button class="agd-link" data-persona-conta="vincular">${atual.conta ? 'Trocar pra ' : 'Vincular a '}${escapeHtml(conta)}</button>` : ''}
        ${atual.conta ? `<button class="agd-link" data-persona-conta="soltar" title="Desvincular">${icone('fechar')}</button>` : ''}</span>
        ${!conta && !atual.conta ? `<span class="agd-dica-mini">Detecte a modelo no topo pra vincular</span>` : ''}
      </div>
      ${campo('desc', 'Quem ela é <em class="agd-campo-uso">profissão, rotina, personalidade</em>', `<textarea class="acp-disparo-msg agd-txt-curto" data-campo="desc" placeholder="ex. universitária, mora em república, tímida mas curiosa...">${escapeHtml(atual.desc || '')}</textarea>`)}
      ${campo('jeito', 'Jeito de falar <em class="agd-campo-uso">gírias, tom, como chama o assinante</em>', `<textarea class="acp-disparo-msg agd-txt-curto" data-campo="jeito" placeholder="ex. escreve tudo minúsculo, fala &quot;mozão&quot;, usa &quot;kkkk&quot;...">${escapeHtml(atual.jeito || '')}</textarea>`)}
      ${campo('nunca', 'Nunca diz / nunca faz', `<input class="acp-save-input" data-campo="nunca" placeholder="ex. não usa &quot;amor&quot;, não fala de dinheiro direto" value="${escapeHtml(atual.nunca || '')}">`)}
      ${campo('exemplos', 'Exemplos de como ela escreve <em class="agd-campo-uso">um por bloco, linha em branco entre eles</em>', `<textarea class="acp-disparo-msg agd-txt-persona" data-campo="exemplos" placeholder="Cole 3 ou 4 mensagens reais dela. A IA imita o estilo (não copia).">${escapeHtml(atual.exemplos || '')}</textarea>`)}
      <button class="acp-save-btn" id="acp-persona-testar">${icone('brilho')}<span>Testar persona (3 mensagens)</span></button>
      <div id="acp-persona-teste"></div>`
      : `<div class="agd-vazio">Sem persona: a IA escreve no estilo geral.</div>`;

    q('#acp-agenda-personas').querySelectorAll('.acp-pill').forEach(b => b.addEventListener('click', () => {
      const id = b.dataset.persona;
      if (id === '+') {
        const nova = { id: 'p' + Date.now(), nome: 'Nova persona', desc: '', conta: contaAtiva() && !cfg.personas.some(p => p.conta === contaAtiva()) ? contaAtiva() : '' };
        cfg.personas.push(nova);
        cfg.persona = nova.id;
      } else {
        cfg.persona = id;
      }
      renderPersonas();
      salvar();
      if (id === '+') q('[data-campo="nome"]')?.select();
    }));
    aviso.querySelector('[data-persona-usar]')?.addEventListener('click', e => {
      cfg.persona = e.currentTarget.dataset.personaUsar;
      renderPersonas();
      salvar();
    });
    if (!atual) return;

    q('#acp-agenda-persona-edit').querySelectorAll('[data-campo]').forEach(el => el.addEventListener('input', () => {
      const k = el.dataset.campo;
      if (k === 'idade') {
        const v = parseInt(el.value);
        const invalida = el.value !== '' && !(v >= 18);
        q('#acp-persona-idade-erro').hidden = !invalida;
        el.classList.toggle('agd-invalido', invalida);
        if (invalida) return; // não salva idade abaixo de 18
        atual.idade = el.value ? String(v) : '';
      } else {
        atual[k] = el.value;
      }
      if (k === 'nome') q(`[data-persona="${atual.id}"]`).textContent = atual.nome || 'Sem nome';
      salvar();
    }));
    q('#acp-agenda-persona-edit').querySelectorAll('[data-persona-conta]').forEach(b => b.addEventListener('click', () => {
      if (b.dataset.personaConta === 'vincular') {
        // Uma conta = uma persona: tira o vínculo de quem tinha essa conta antes
        cfg.personas.forEach(p => { if (p.conta === contaAtiva()) p.conta = ''; });
        atual.conta = contaAtiva();
      } else {
        atual.conta = '';
      }
      renderPersonas();
      salvar();
    }));
    q('#acp-persona-apagar').addEventListener('click', () => {
      if (!confirm(`Apagar a persona "${atual.nome}"?`)) return;
      cfg.personas = cfg.personas.filter(p => p !== atual);
      cfg.persona = '';
      renderPersonas();
      salvar();
    });
    q('#acp-persona-testar').addEventListener('click', async () => {
      const btn = q('#acp-persona-testar');
      const box = q('#acp-persona-teste');
      const c = lerCfg();
      btn.disabled = true;
      rotular(btn, 'carregando', 'Gerando amostra...', true);
      try {
        const r = await chrome.runtime.sendMessage({
          tipo: 'GERAR_COPIES_MASSA',
          dados: {
            quantidade: 3, horarios: ['10:00', '15:00', '21:00'], briefing: c.briefing, prompt: c.prompt || AGENDA_PROMPT_PADRAO,
            tipos: (c.tiposCopy.length ? c.tiposCopy : Object.keys(_TIPOS_COPY)).map(t => _TIPOS_COPY[t][1]),
            emoji: _EMOJI_COPY[c.emojiCopy]?.[1],
            persona: _textoPersona(atual)
          }
        });
        box.innerHTML = r?.erro
          ? `<div class="agd-aviso-box">${icone('alerta')}<span>${escapeHtml(r.erro)}</span></div>`
          : `<div class="agd-sub-label agd-espaco">Amostra (não é salva)</div>${(r.copies || []).map(t => `<div class="agd-amostra">${escapeHtml(t)}</div>`).join('')}`;
      } catch (err) {
        box.innerHTML = `<div class="agd-aviso-box">${icone('alerta')}<span>${escapeHtml(err.message)}</span></div>`;
      }
      btn.disabled = false;
      rotular(btn, 'brilho', 'Testar de novo');
    });
  };

  chrome.storage.local.get('acp_agenda_resultado').then(({ acp_agenda_resultado: r }) => {
    if (!r?.falhas?.length) return;
    const el = q('#acp-agenda-ultimo');
    el.textContent = `Última programação (${r.em}): ${r.ok} de ${r.total} ok, ${r.falhas.length} com problema:\n${_resumoFalhas(r.falhas)}`;
    el.hidden = false;
  }).catch(() => {});

  const mostrarProgresso = (txt) => {
    _agendaProgresso = txt;
    const el = q('#acp-agenda-progresso');
    el.hidden = !txt;
    el.querySelector('.acp-progress-text').textContent = txt;
  };

  // Botão com ícone + texto (os botões trocam de texto durante as ações)
  const rotular = (btn, nomeIcone, texto, girando = false) => {
    btn.innerHTML = icone(nomeIcone, girando ? 'agd-girando' : '') + `<span>${escapeHtml(texto)}</span>`;
  };

  let roteiroAberto = ''; // horário do roteiro com as opções abertas
  let _renderMsgs = null; // lista de mensagens da aba Copy (definida mais abaixo)

  const atualizarBotao = () => {
    const c = lerCfg();
    const marcadas = _horariosValidos(c.horarios, 99).length;
    const info = q('#acp-agenda-horas-info');
    info.textContent = marcadas > c.limiteDia
      ? `${marcadas} marcados · só os ${c.limiteDia} primeiros/dia`
      : `${marcadas} marcado(s)`;
    info.classList.toggle('agd-aviso', marcadas > c.limiteDia);
    // Agitação ligada = alguma hora com mais de 1 disparo → mostra o aviso com o botão de tirar
    const porHoraAg = {};
    _horariosValidos(c.horarios, 99).forEach(h => { porHoraAg[h.slice(0, 2)] = (porHoraAg[h.slice(0, 2)] || 0) + 1; });
    const horasAgitadas = Object.values(porHoraAg).filter(n => n > 1);
    sec.querySelectorAll('[data-agitada]').forEach(el => {
      el.hidden = !horasAgitadas.length;
      el.querySelector('[data-agitada-txt]').textContent = horasAgitadas.length
        ? `Agitação ligada: ${horasAgitadas.length} ${horasAgitadas.length === 1 ? 'hora' : 'horas'} com até ${Math.max(...horasAgitadas)} disparos`
        : '';
    });
    // Roteiro do dia: uma linha por horário com o assunto escolhido; clicar abre as opções
    const horasDia = _horariosValidos(c.horarios, c.limiteDia);
    const assuntosDia = horasDia.map(h => _assuntoDaHora(c, h));
    const semPacote = (a) => !!_ACERVO_PROX[a] && !_listaPacotes(c, a).length;
    const horaCurta = (h) => h.endsWith(':00') ? h.slice(0, 2) + 'h' : h;
    q('#acp-agenda-ordem').innerHTML = horasDia.length ? horasDia.map((h, i) => {
      const atual = assuntosDia[i];
      const aberta = h === roteiroAberto;
      const falta = semPacote(atual);
      return `<div class="agd-roteiro-linha ${aberta ? 'agd-aberta' : ''}" data-assunto="${atual}">
        <span class="agd-roteiro-hora">${horaCurta(h)}</span>
        <button class="agd-roteiro-chip ${falta ? 'agd-falta' : ''}" data-abrir="${h}" ${falta ? 'title="Nenhum pacote marcado ✓ no registro (aba Pacotes)"' : ''}>
          <span>${_ASSUNTOS_COPY[atual][0]}</span>${falta ? icone('alerta') : ''}${icone('seta', 'agd-roteiro-seta')}
        </button>
        ${aberta ? `<div class="agd-roteiro-opcoes">${Object.entries(_ASSUNTOS_COPY).map(([id, [rotulo]]) =>
          `<button class="agd-roteiro-op ${id === atual ? 'agd-op-ativa' : ''}" data-assunto="${id}" data-h="${h}" data-a="${id}">${rotulo}</button>`).join('')}</div>` : ''}
      </div>`;
    }).join('') : '<div class="agd-vazio">Marque os horários na aba Quando.</div>';

    // Faixa do dia (uma cor por assunto) + contagem
    const contagem = [...new Set(assuntosDia)].map(a => [a, assuntosDia.filter(x => x === a).length]);
    q('#acp-roteiro-resumo').innerHTML = horasDia.length ? `
      <div class="agd-roteiro-faixa">${horasDia.map((h, i) =>
        `<span data-assunto="${assuntosDia[i]}" title="${horaCurta(h)} · ${escapeHtml(_ASSUNTOS_COPY[assuntosDia[i]][0])}"></span>`).join('')}</div>
      <div class="agd-roteiro-contagem">${contagem.map(([a, n]) =>
        `<span data-assunto="${a}"><i class="agd-ponto"></i>${n} ${escapeHtml(_ASSUNTOS_COPY[a][0].split(' ').slice(1).join(' '))}</span>`).join('')}</div>` : '';

    // Modelo pronto ativo = o roteiro atual bate com a distribuição dele
    const ativo = horasDia.length ? _MODELOS_ROTEIRO.find(([, seq]) => {
      const dist = _distribuirRoteiro(seq.split(','), horasDia);
      return horasDia.every((h, i) => dist[h] === assuntosDia[i]);
    }) : null;
    sec.querySelectorAll('#acp-roteiro-modelos .acp-pill').forEach(b =>
      b.classList.toggle('acp-pill-ativo', !!ativo && b.dataset.modelo === ativo[1]));
    q('#acp-roteiro-estado').textContent = horasDia.length && !ativo ? 'Personalizado' : '';
    q('#acp-roteiro-limpar').hidden = assuntosDia.every(a => a === 'aquecimento');

    // Detalhe da oferta: só aparece quando algum horário usa, e diz quais
    const usamOferta = Object.keys(_ASSUNTOS_COPY).filter(a => a !== 'aquecimento' && !_ACERVO_PROX[a] && assuntosDia.includes(a));
    q('#acp-agenda-oferta-campo').hidden = !usamOferta.length;
    q('#acp-agenda-oferta-uso').textContent = usamOferta.length ? 'usado em ' + usamOferta.map(a => _ASSUNTOS_COPY[a][0]).join(', ') : '';
    // Registro sempre à mostra (antes só aparecia com horário de 📦/🎬 no roteiro e parecia que tinha sumido)
    const nomeModelo = _nomeModeloPack(c);
    q('#acp-agenda-pack-prox').innerHTML = Object.keys(_ACERVO_PROX).map(assunto => {
      const lista = _listaPacotes(c, assunto);
      const icone = _ASSUNTOS_COPY[assunto][0].split(' ')[0];
      if (!assuntosDia.includes(assunto)) return '';
      return `<div>${icone} ${lista.length
        ? `${escapeHtml(lista.map(_rotuloPacote).join(' → '))} · próximo: <b>${escapeHtml(_rotuloPacote(lista[_proxRodizio(c, assunto) % lista.length]))}</b>`
        : `⚠️ Marque ✓ em pelo menos um ${icone} de ${escapeHtml(nomeModelo)} no registro`}</div>`;
    }).join('');
    _renderMsgs?.();
    const n = c.teste ? Math.min(1, montarPlanoAgenda(c).length) : montarPlanoAgenda(c).length;
    const btnProg = q('#acp-agenda-programar');
    if (!btnProg.disabled) {
      if (!n) rotular(btnProg, 'calendario', 'Escolha dias e horários');
      else rotular(btnProg, c.teste ? 'frasco' : 'raio', c.teste ? 'Testar com 1 disparo' : `Programar ${n} ${n === 1 ? 'disparo' : 'disparos'}`);
      btnProg.classList.toggle('agd-incompleto', !n);
    }
  };

  const salvar = () => { salvarAgendaCfg(lerCfg()); atualizarBotao(); };

  const renderModeloCard = () => {
    const box = q('#acp-modelo-card-info');
    const btn = q('#acp-modelo-detectar');
    const m = cfg.modeloAtivo;
    const avatarVazio = `<span class="agd-avatar">${icone('pessoa')}</span>`;
    box.innerHTML = m
      ? `${m.foto ? `<img src="${escapeHtml(m.foto)}" alt="">` : avatarVazio}
         <div class="agd-min0">
           <div id="acp-modelo-nome">${escapeHtml(m.nome)}</div>
           <div id="acp-modelo-handle">${escapeHtml(m.handle || '')}</div>
         </div>`
      : `${avatarVazio}<div class="agd-min0"><div id="acp-modelo-nome">Nenhuma modelo</div><div class="agd-modelo-vazio">Clique em Detectar com a Privacy aberta</div></div>`;
    btn.innerHTML = icone('atualizar') + (m ? '' : '<span>Detectar</span>');
    btn.title = m ? 'Detectar de novo (se trocou de modelo)' : 'Detectar a modelo ativa na Privacy';
  };
  renderModeloCard();

  q('#acp-modelo-detectar').addEventListener('click', async () => {
    const btn = q('#acp-modelo-detectar');
    btn.disabled = true;
    btn.innerHTML = icone('carregando', 'agd-girando');
    try {
      cfg.modeloAtivo = await _detectarModeloAtivo();
      // Conta com persona vinculada: já escolhe ela
      const daConta = cfg.personas.find(p => p.conta && p.conta === cfg.modeloAtivo?.handle);
      if (daConta) cfg.persona = daConta.id;
      renderPersonas();
      salvar();
    } catch (err) {
      alert('⚠️ ' + err.message);
    }
    renderModeloCard();
    btn.disabled = false;
  });

  // Redesenha os pills de horário a partir de uma lista de "ativos" (usado pelo modo agitação) ou só religa clique (primeira vez).
  // Um pill por hora cheia (0h–23h); se a hora tiver mais de um disparo (modo agitação), mostra "×N" em vez de uma pílula por minuto.
  const renderHorarios = (ativos) => {
    const porHora = new Map();
    for (const h of ativos) {
      const hh = h.slice(0, 2);
      if (!porHora.has(hh)) porHora.set(hh, []);
      porHora.get(hh).push(h);
    }
    const box = q('#acp-agenda-horarios');
    box.innerHTML = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, '0')).map(hh => {
      const ativa = (porHora.get(hh) || []).sort();
      // Hora desligada que tinha minutos próprios (ex. 14h ×5 da agitação): continua mostrando e volta igual ao religar
      const lista = ativa.length ? ativa : (cfg.horasGuardadas?.[hh] || '').split(',').filter(Boolean);
      const rotulo = lista.length > 1 ? `${hh}h ×${lista.length}` : (lista[0] ? (lista[0].endsWith(':00') ? hh + 'h' : lista[0]) : hh + 'h');
      const titulo = ativa.length ? ativa.join(', ') : lista.length ? `Desligado · clique pra voltar: ${lista.join(', ')}` : `Sem disparo às ${hh}h`;
      return `<button class="acp-pill ${ativa.length ? 'acp-pill-ativo' : ''}" data-hora-grupo="${hh}" data-horas="${lista.join(',')}" title="${titulo}">${rotulo}</button>`;
    }).join('');
    box.querySelectorAll('.acp-pill').forEach(p => p.addEventListener('click', () => {
      const hh = p.dataset.horaGrupo;
      const ligar = !p.classList.contains('acp-pill-ativo');
      const guardadas = cfg.horasGuardadas = { ...(cfg.horasGuardadas || {}) };
      p.classList.toggle('acp-pill-ativo');
      if (ligar) {
        if (!p.dataset.horas) p.dataset.horas = hh + ':00';
        delete guardadas[hh];
        p.title = p.dataset.horas.split(',').join(', ');
      } else if (p.dataset.horas && p.dataset.horas !== hh + ':00') {
        // Guarda os minutos dessa hora pra não perder ao fechar o painel ou recarregar a página
        guardadas[hh] = p.dataset.horas;
        p.title = `Desligado · clique pra voltar: ${p.dataset.horas.split(',').join(', ')}`;
      }
      salvar();
    }));
  };
  renderHorarios(horasMarcadas);

  q('#acp-agitacao-aplicar').addEventListener('click', () => {
    const qtd = Math.min(12, Math.max(1, parseInt(q('#acp-agitacao-qtd').value) || 1));
    const de = q('#acp-agitacao-de').value || '08:00';
    const ate = q('#acp-agitacao-ate').value || '23:00';
    const [h1] = de.split(':').map(Number);
    const [h2] = ate.split(':').map(Number);
    if (!(h1 < h2)) { q('#acp-agitacao-status').textContent = '⚠️ A hora final precisa ser depois da inicial.'; return; }
    const gerados = [];
    for (let h = h1; h <= h2; h++) {
      for (let i = 0; i < qtd; i++) {
        const min = Math.round(i * 60 / qtd);
        gerados.push(`${String(h).padStart(2, '0')}:${String(min).padStart(2, '0')}`);
      }
    }
    // Guarda como estava antes da 1ª agitação, pro "Tirar agitação" voltar (aplicar de novo não sobrescreve)
    if (!cfg.antesAgitacao) {
      const atual = lerCfg();
      cfg.antesAgitacao = { horarios: atual.horarios, roteiroHoras: { ...(cfg.roteiroHoras || {}) }, horasGuardadas: { ...(cfg.horasGuardadas || {}) } };
    }
    cfg.horasGuardadas = {}; // agitação nova substitui tudo, inclusive horas desligadas guardadas
    renderHorarios(gerados);
    salvar();
    const limite = parseInt(q('#acp-agenda-limite').value) || 0;
    q('#acp-agitacao-status').textContent = limite < gerados.length
      ? `⚡ ${gerados.length} disparos gerados — mas seu "Máximo por dia" tá em ${limite}, só os ${limite} primeiros horários vão sair de fato. Aumente ali em cima se quiser todos.`
      : `⚡ ${gerados.length} disparos gerados, um a cada ${Math.round(60 / qtd)} min dentro de cada hora.`;
  });

  // Tirar agitação: volta os horários de antes (ou, sem registro, deixa 1 por hora). "um": mesmas horas, 1 disparo cada
  sec.addEventListener('click', e => {
    const acao = e.target.closest('[data-agitacao]')?.dataset.agitacao;
    if (!acao) return;
    const horas = _horariosValidos(lerCfg().horarios, 99);
    const umPorHora = [...new Set(horas.map(h => h.slice(0, 2) + ':00'))];
    if (acao === 'desfazer' && cfg.antesAgitacao) {
      const antes = cfg.antesAgitacao;
      cfg.roteiroHoras = antes.roteiroHoras || {};
      cfg.horasGuardadas = antes.horasGuardadas || {};
      renderHorarios(_horariosValidos(antes.horarios, 99));
    } else {
      cfg.horasGuardadas = {};
      renderHorarios(umPorHora);
    }
    delete cfg.antesAgitacao;
    q('#acp-agitacao-status').textContent = '';
    salvar();
  });

  sec.querySelectorAll('#acp-agenda-dias .acp-pill').forEach(p => {
    p.addEventListener('click', () => { p.classList.toggle('acp-pill-ativo'); salvar(); });
  });
  // Atalhos de dias: substituem a seleção (úteis/fim de semana olham só os próximos 7 dias)
  q('#acp-dias-atalhos').addEventListener('click', e => {
    const atalho = e.target.closest('[data-atalho]')?.dataset.atalho;
    if (!atalho) return;
    sec.querySelectorAll('#acp-agenda-dias .acp-pill').forEach((p, i) => {
      const [Y, M, D] = p.dataset.dia.split('-').map(Number);
      const dSemana = new Date(Y, M - 1, D).getDay();
      const fds = dSemana === 0 || dSemana === 6;
      const marcar = i < 7 && (atalho === 'semana' || (atalho === 'uteis' && !fds) || (atalho === 'fds' && fds));
      p.classList.toggle('acp-pill-ativo', marcar);
    });
    salvar();
  });
  // Modelo pronto: divide só os horários que realmente disparam (respeita o máximo por dia)
  sec.querySelectorAll('#acp-roteiro-modelos .acp-pill').forEach(b => b.addEventListener('click', () => {
    const c = lerCfg();
    cfg.roteiroHoras = _distribuirRoteiro(b.dataset.modelo.split(','), _horariosValidos(c.horarios, c.limiteDia));
    roteiroAberto = '';
    salvar();
  }));
  q('#acp-roteiro-limpar').addEventListener('click', () => {
    cfg.roteiroHoras = {};
    roteiroAberto = '';
    salvar();
  });
  // Linhas do roteiro: chip abre/fecha as opções; opção escolhe o assunto do horário
  q('#acp-agenda-ordem').addEventListener('click', e => {
    const op = e.target.closest('[data-a]');
    if (op) {
      cfg.roteiroHoras = { ...(cfg.roteiroHoras || {}), [op.dataset.h]: op.dataset.a };
      roteiroAberto = '';
      salvar();
      return;
    }
    const chip = e.target.closest('[data-abrir]');
    if (!chip) return;
    roteiroAberto = roteiroAberto === chip.dataset.abrir ? '' : chip.dataset.abrir;
    atualizarBotao();
  });
  // Registro de pacotes: uma linha por pacote (rodízio, apelido, preço, nome no Acervo)
  // Modelo do registro: pílulas pra escolher na hora (troca a lista de pacotes) + nova / renomear / apagar
  const renderModelosPack = () => {
    const modelos = _modelosPack(cfg);
    const box = q('#acp-agenda-modelos-pack');
    box.innerHTML = modelos.map(m =>
      `<button class="acp-pill ${cfg.modelo === m.id ? 'acp-pill-ativo' : ''}" data-modelo-pack="${m.id}">${escapeHtml(m.nome || 'Sem nome')}</button>`).join('')
      + `<button class="acp-pill" data-modelo-pack="+">${icone('mais')}Modelo</button>`
      + (modelos.some(m => m.id === cfg.modelo) ? `<button class="acp-pill agd-pill-icone" data-modelo-pack="renomear" title="Renomear modelo">${icone('lapis')}</button><button class="acp-pill agd-pill-icone agd-perigo" data-modelo-pack="apagar" title="Apagar modelo">${icone('lixo')}</button>` : '');
    box.querySelectorAll('[data-modelo-pack]').forEach(b => b.addEventListener('click', () => {
      const id = b.dataset.modeloPack;
      const atual = modelos.find(m => m.id === cfg.modelo);
      if (id === '+') {
        const nome = (prompt('Nome da modelo:') || '').trim();
        if (!nome) return;
        const nova = { id: 'm' + Date.now(), nome };
        modelos.push(nova);
        cfg.modelo = nova.id;
      } else if (id === 'renomear') {
        const nome = (prompt('Novo nome da modelo:', atual.nome) || '').trim();
        if (!nome) return;
        atual.nome = nome;
      } else if (id === 'apagar') {
        if (!confirm(`Apagar a modelo "${atual.nome}"? Os pacotes dela ficam como "sem modelo".`)) return;
        cfg.modelos = modelos.filter(m => m !== atual);
        cfg.modelo = '';
      } else {
        cfg.modelo = id;
      }
      renderModelosPack();
      renderPacotes();
      salvar();
    }));
  };

  // Só aparecem os pacotes da modelo escolhida; os sem modelo ficam embaixo com botão pra vincular
  const renderPacotes = () => {
    const box = q('#acp-agenda-pacotes');
    const modelo = _modelosPack(cfg).find(m => m.id === cfg.modelo);
    const linhaPacote = (p, i) => `
      <div class="agd-pacote ${p.usar ? '' : 'agd-desligado'}" data-i="${i}">
        <div class="agd-pacote-lado">
          <input type="checkbox" class="agd-check" data-c="usar" ${p.usar ? 'checked' : ''} title="Entra no rodízio">
          <button class="agd-tipo" data-c="tipo" title="${p.tipo === 'video' ? 'Vídeo único' : 'Pack'} (clique pra trocar)">${p.tipo === 'video' ? '🎬' : '📦'}</button>
        </div>
        <div class="agd-pacote-campos">
          <input class="acp-save-input" data-c="apelido" placeholder="Apelido (como aparece na copy)" value="${escapeHtml(p.apelido)}" title="Apelido">
          <div class="agd-sub-grade">
            <input class="acp-save-input" data-c="preco" placeholder="R$ 39,99" value="${escapeHtml(p.preco)}" title="Preço">
            <input class="acp-save-input" data-c="nome" placeholder="Nome no Acervo" value="${escapeHtml(p.nome)}" title="Nome no Acervo: ${escapeHtml(p.nome)}">
          </div>
        </div>
        <button class="agd-btn-icone agd-perigo" data-c="apagar" title="Apagar pacote">${icone('lixo')}</button>
      </div>`;
    const daModelo = cfg.pacotesReg.map((p, i) => [p, i]).filter(([p]) => _pacoteDaModelo(cfg, p));
    // Os sem modelo (todos os antigos) aparecem sempre, pra nunca parecer que sumiram
    const semModelo = cfg.pacotesReg.map((p, i) => [p, i]).filter(([p]) => _pacoteSemModelo(cfg, p));
    box.innerHTML = (!modelo
      ? `<div class="agd-aviso-box">${icone('alerta')}<span>Escolha a modelo acima pra ver e cadastrar os packs e vídeos dela.</span></div>`
      : (daModelo.length ? daModelo.map(([p, i]) => linhaPacote(p, i)).join('') : `<div class="agd-vazio agd-espaco">Nenhum pacote da ${escapeHtml(modelo.nome)} ainda. Use os botões abaixo.</div>`))
      + (semModelo.length ? `
        <div class="agd-aviso-box">${icone('alerta')}<span>${semModelo.length} sem modelo (não entram no rodízio): ${modelo ? `clique em vincular nos que forem da ${escapeHtml(modelo.nome)}` : 'escolha a modelo acima e vincule os dela'}.</span></div>
        ${semModelo.map(([p, i]) => `
          <div class="agd-orfao" data-orfao="${i}">
            <span>${p.tipo === 'video' ? '🎬' : '📦'}</span>
            <span title="${escapeHtml(p.nome || '')}">${escapeHtml(_rotuloPacote(p))}${p.nome ? ' · ' + escapeHtml(p.nome) : ''}</span>
            ${modelo ? `<button class="acp-pill" data-c="vincular" title="Vincular à ${escapeHtml(modelo.nome)}">${icone('seta')}Vincular</button>` : ''}
            <button class="agd-btn-icone agd-perigo" data-c="apagar" title="Apagar pacote">${icone('lixo')}</button>
          </div>`).join('')}` : '');
    box.querySelectorAll('[data-orfao]').forEach(linha => {
      const p = cfg.pacotesReg[linha.dataset.orfao];
      linha.querySelector('[data-c="vincular"]')?.addEventListener('click', () => {
        p.modelo = cfg.modelo;
        renderPacotes();
        salvar();
      });
      linha.querySelector('[data-c="apagar"]').addEventListener('click', () => {
        if (!confirm(`Apagar o pacote "${p.apelido || p.nome || p.preco}"?`)) return;
        cfg.pacotesReg = cfg.pacotesReg.filter(x => x !== p);
        renderPacotes();
        salvar();
      });
    });
    box.querySelectorAll('[data-i]').forEach(linha => {
      const p = cfg.pacotesReg[linha.dataset.i];
      linha.querySelectorAll('input').forEach(inp => inp.addEventListener(inp.type === 'checkbox' ? 'change' : 'input', () => {
        p[inp.dataset.c] = inp.type === 'checkbox' ? inp.checked : inp.value.trim();
        if (inp.type === 'checkbox') linha.classList.toggle('agd-desligado', !inp.checked);
        salvar();
      }));
      linha.querySelector('[data-c="tipo"]').addEventListener('click', () => {
        p.tipo = p.tipo === 'video' ? 'pack' : 'video';
        renderPacotes();
        salvar();
      });
      linha.querySelector('[data-c="apagar"]').addEventListener('click', () => {
        if (!confirm(`Apagar o pacote "${p.apelido || p.nome || p.preco}"?`)) return;
        cfg.pacotesReg = cfg.pacotesReg.filter(x => x !== p);
        renderPacotes();
        salvar();
      });
    });
  };
  sec.querySelectorAll('[data-pacote-novo]').forEach(b => b.addEventListener('click', () => {
    if (!cfg.modelo) return alert('Escolha primeiro a modelo no registro (os botões 👩 acima da lista).');
    cfg.pacotesReg.push({ tipo: b.dataset.pacoteNovo, modelo: cfg.modelo, apelido: '', preco: '', nome: '', usar: true });
    renderPacotes();
    salvar();
    [...sec.querySelectorAll('#acp-agenda-pacotes [data-i] [data-c="apelido"]')].pop()?.focus();
  }));

  q('#acp-agenda-sync-acervo').addEventListener('click', async () => {
    if (!cfg.modelo) return alert('Escolha primeiro a modelo no registro (os botões 👩 acima da lista).');
    const btn = q('#acp-agenda-sync-acervo');
    const status = q('#acp-agenda-sync-status');
    btn.disabled = true;
    rotular(btn, 'carregando', 'Lendo Acervo...', true);
    status.textContent = '';
    try {
      const lidos = await _listarPacotesAcervo();
      const daModelo = cfg.pacotesReg.filter(p => _pacoteDaModelo(cfg, p));
      let novos = 0, atualizados = 0;
      for (const { nome, preco } of lidos) {
        const existente = daModelo.find(p => (p.nome || '').trim().toLowerCase() === nome.trim().toLowerCase());
        if (existente) {
          if (preco && existente.preco !== preco) { existente.preco = preco; atualizados++; }
        } else {
          cfg.pacotesReg.push({ tipo: 'pack', modelo: cfg.modelo, apelido: nome.slice(0, 30), preco, nome, usar: false });
          novos++;
        }
      }
      renderPacotes();
      salvar();
      status.textContent = novos || atualizados
        ? `✅ ${novos} novo(s) adicionado(s) (desmarcados — revise e marque ✓ os que quer no rodízio), ${atualizados} preço(s) atualizado(s).`
        : '✅ Já estava tudo sincronizado.';
    } catch (err) {
      status.textContent = '⚠️ ' + err.message;
    }
    btn.disabled = false;
    rotular(btn, 'atualizar', 'Sincronizar pacotes do Acervo');
  });

  renderModelosPack();
  renderPacotes();

  ['#acp-agenda-limite', '#acp-agenda-briefing', '#acp-agenda-oferta', '#acp-agenda-prompt'].forEach(s => {
    q(s).addEventListener('input', salvar);
  });
  q('#acp-agenda-teste').addEventListener('change', salvar);
  sec.querySelectorAll('#acp-agenda-tipos .acp-pill').forEach(p => {
    p.addEventListener('click', () => { p.classList.toggle('acp-pill-ativo'); salvar(); });
  });
  sec.querySelectorAll('#acp-agenda-emoji .acp-pill').forEach(p => {
    p.addEventListener('click', () => {
      sec.querySelectorAll('#acp-agenda-emoji .acp-pill').forEach(x => x.classList.remove('acp-pill-ativo'));
      p.classList.add('acp-pill-ativo');
      salvar();
    });
  });
  renderPersonas();
  atualizarBotao();

  // ── Aba Copy: uma mensagem por horário (cfg.msgsMapa) ──
  const fmtDiaCurto = (iso) => {
    if (!iso) return 'Sem dia escolhido (marque na aba Quando)';
    const [Y, M, D] = iso.split('-').map(Number);
    return new Date(Y, M - 1, D).toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: '2-digit' }).replace('.', '');
  };
  let assinaturaMsgs = '';
  const renderMensagens = (forcar = false) => {
    const c = lerCfg();
    const slots = _slotsTexto(c);
    const mapa = _msgsMapa(cfg);
    // Só redesenha a lista quando os horários mudam (redesenhar a cada tecla tiraria o foco do campo)
    const assinatura = slots.map(s => _chaveMsg(s) + s.assunto).join('|');
    if (forcar || assinatura !== assinaturaMsgs) {
      assinaturaMsgs = assinatura;
      let diaAtual = null;
      q('#acp-msgs-lista').innerHTML = slots.length ? slots.map(s => {
        const cabecalho = s.dia !== diaAtual ? `<div class="agd-msg-dia">${escapeHtml(fmtDiaCurto(s.dia))}</div>` : '';
        diaAtual = s.dia;
        return cabecalho + `<div class="agd-msg" data-assunto="${s.assunto}" data-chave="${escapeHtml(_chaveMsg(s))}">
          <div class="agd-msg-meta"><b>${s.hora}</b><span>${escapeHtml(_ASSUNTOS_COPY[s.assunto][0])}</span>
            <button class="agd-btn-icone agd-msg-refazer" data-refazer title="Gerar de novo só esta">${icone('atualizar')}</button></div>
          <textarea class="acp-disparo-msg agd-msg-txt" rows="2" placeholder="Vazio: vai repetir uma das outras">${escapeHtml(_msgDoHorario(mapa, s))}</textarea>
        </div>`;
      }).join('') : '<div class="agd-vazio">Marque dias e horários na aba Quando.</div>';
    }
    const comTexto = slots.filter(s => _msgDoHorario(mapa, s)).length;
    const vazios = slots.length - comTexto;
    const info = q('#acp-msgs-info');
    info.textContent = slots.length ? `${comTexto} de ${slots.length} com texto` : '';
    info.classList.toggle('agd-aviso', !!vazios && comTexto > 0);
    const btn = q('#acp-agenda-gerar');
    if (!btn.disabled) {
      if (!slots.length) rotular(btn, 'brilho', 'Gerar copies');
      else if (!comTexto) rotular(btn, 'brilho', `Gerar ${slots.length} ${slots.length === 1 ? 'copy' : 'copies'}`);
      else if (vazios) rotular(btn, 'brilho', `Gerar ${vazios === 1 ? 'o horário vazio' : `os ${vazios} vazios`}`);
      else rotular(btn, 'atualizar', `Refazer todas (${slots.length})`);
    }
    q('#acp-agenda-refazer').hidden = !(comTexto && vazios);
    const hist = (cfg.historicoCopies || []).length;
    q('#acp-historico').innerHTML = hist
      ? `A IA evita repetir as últimas ${hist} copies já programadas <button class="agd-link" data-historico-limpar>Limpar</button>`
      : '';
    q('#acp-prompt-estado').textContent = q('#acp-agenda-prompt').value.trim() === AGENDA_PROMPT_PADRAO.trim() ? 'Prompt padrão' : 'Prompt editado';
  };
  _renderMsgs = renderMensagens;

  // Pede copies pra uma lista de horários (mesmo formato pra geração geral, ↻ de um só e preencher vazios)
  const pedirCopies = (c, slots, evitarExtra = []) => chrome.runtime.sendMessage({
    tipo: 'GERAR_COPIES_MASSA',
    dados: {
      quantidade: slots.length, horarios: slots.map(s => s.hora), briefing: c.briefing, prompt: c.prompt || AGENDA_PROMPT_PADRAO,
      tipos: (c.tiposCopy.length ? c.tiposCopy : Object.keys(_TIPOS_COPY)).map(t => _TIPOS_COPY[t][1]),
      emoji: _EMOJI_COPY[c.emojiCopy]?.[1],
      roteiro: slots.every(s => s.assunto === 'aquecimento') ? [] : slots.map(s => `${s.hora} — ${_ASSUNTOS_COPY[s.assunto][1]}`),
      oferta: c.oferta,
      persona: _textoPersona(c.personas.find(p => p.id === c.persona)),
      historico: [...(c.historicoCopies || []), ...evitarExtra].slice(-30)
    }
  });

  // todas: true = refaz tudo; false = só vazios; undefined = decide (tudo vazio ou tudo cheio → todas)
  const gerar = async (todas) => {
    const c = lerCfg();
    const slots = _slotsTexto(c);
    if (!slots.length) {
      return mostrarProgresso(_horariosValidos(c.horarios, c.limiteDia).length
        ? '📦 Todos os horários são de pack: o texto vai o do próprio pacote, não precisa gerar'
        : '⚠️ Marque dias e horários na aba Quando');
    }
    const mapa = _msgsMapa(cfg);
    const nComTexto = slots.filter(s => _msgDoHorario(mapa, s)).length;
    if (todas === undefined) todas = !nComTexto || nComTexto === slots.length;
    if (todas && nComTexto && !confirm(`Refazer as ${slots.length} mensagens?\nAs ${nComTexto} que você já tem (inclusive as que editou) vão ser substituídas.`)) return;
    const alvo = todas ? slots : slots.filter(s => !_msgDoHorario(mapa, s));
    const btn = q('#acp-agenda-gerar');
    btn.disabled = true;
    rotular(btn, 'carregando', `Gerando ${alvo.length} copies...`, true);
    const onProgresso = (msg) => {
      if (msg?.tipo === 'ACP_COPIES_PROGRESSO') rotular(btn, 'carregando', `Gerando copies... ${msg.feitas} de ${msg.total}`, true);
    };
    chrome.runtime.onMessage.addListener(onProgresso);
    try {
      const r = await pedirCopies(c, alvo, todas ? [] : _msgsPool(mapa));
      if (r?.erro) mostrarProgresso('⚠️ ' + r.erro);
      else {
        if (todas) {
          // Refazer tudo: limpa sobras antigas (dias que já passaram e textos colados que sobraram)
          const hoje = _dataISO(new Date());
          for (const k of Object.keys(mapa)) if (k.startsWith('extra') || (/^\d{4}-/.test(k) && k.slice(0, 10) < hoje)) delete mapa[k];
        }
        r.copies.forEach((t, i) => { if (alvo[i]) mapa[_chaveMsg(alvo[i])] = t; });
        cfg.mensagens = '';
        salvar();
        renderMensagens(true);
        mostrarProgresso(r.aviso ? `⚠️ ${r.aviso}` : `✨ ${r.copies.length} copies geradas — revise e clique em Programar`);
      }
    } catch (err) {
      mostrarProgresso('⚠️ ' + err.message);
    }
    chrome.runtime.onMessage.removeListener(onProgresso);
    btn.disabled = false;
    renderMensagens();
  };
  q('#acp-agenda-gerar').addEventListener('click', () => gerar());
  q('#acp-agenda-refazer').addEventListener('click', () => gerar(true));

  // Editar uma mensagem (vazia = sai do mapa e o horário repete outra)
  q('#acp-msgs-lista').addEventListener('input', e => {
    const chave = e.target.closest('[data-chave]')?.dataset.chave;
    if (!chave) return;
    const mapa = _msgsMapa(cfg);
    if (e.target.value.trim()) mapa[chave] = e.target.value;
    else delete mapa[chave];
    salvar();
  });
  // ↻ de um horário só
  q('#acp-msgs-lista').addEventListener('click', async e => {
    const b = e.target.closest('[data-refazer]');
    if (!b) return;
    const box = b.closest('[data-chave]');
    const c = lerCfg();
    const slot = _slotsTexto(c).find(s => _chaveMsg(s) === box.dataset.chave);
    if (!slot) return;
    b.disabled = true;
    b.innerHTML = icone('carregando', 'agd-girando');
    try {
      const r = await pedirCopies(c, [slot], _msgsPool(_msgsMapa(cfg)));
      if (r?.erro) mostrarProgresso('⚠️ ' + r.erro);
      else if (r?.copies?.[0]) {
        _msgsMapa(cfg)[box.dataset.chave] = r.copies[0];
        box.querySelector('textarea').value = r.copies[0];
        salvar();
      }
    } catch (err) {
      mostrarProgresso('⚠️ ' + err.message);
    }
    b.disabled = false;
    b.innerHTML = icone('atualizar');
  });

  // Colar várias: preenche os horários na ordem; o que sobrar entra no rodízio
  q('#acp-msgs-aplicar').addEventListener('click', () => {
    const textos = _separarMensagens(q('#acp-msgs-colar').value);
    if (!textos.length) return;
    const slots = _slotsTexto(lerCfg());
    if (!slots.length) return mostrarProgresso('⚠️ Marque dias e horários na aba Quando');
    const mapa = _msgsMapa(cfg);
    slots.forEach((s, i) => { if (textos[i]) mapa[_chaveMsg(s)] = textos[i]; });
    textos.slice(slots.length).forEach((t, i) => { mapa[`extra ${Date.now()}-${i}`] = t; });
    q('#acp-msgs-colar').value = '';
    q('#acp-msgs-colar').closest('details').open = false;
    salvar();
    renderMensagens(true);
    mostrarProgresso(`📋 ${Math.min(textos.length, slots.length)} horários preenchidos`
      + (textos.length > slots.length ? ` · ${textos.length - slots.length} sobraram e entram no rodízio` : ''));
  });

  q('#acp-prompt-restaurar').addEventListener('click', () => {
    const el = q('#acp-agenda-prompt');
    if (el.value.trim() !== AGENDA_PROMPT_PADRAO.trim() && !confirm('Voltar pro prompt padrão? O prompt que você editou vai ser perdido.')) return;
    el.value = AGENDA_PROMPT_PADRAO;
    salvar();
  });
  q('#acp-historico').addEventListener('click', e => {
    if (!e.target.closest('[data-historico-limpar]')) return;
    if (!confirm('Limpar o histórico? A IA vai poder repetir copies que já saíram.')) return;
    cfg.historicoCopies = [];
    salvar();
  });

  // Sem chave da API: aviso no topo da aba Copy com atalho pras Configurações
  chrome.storage.local.get('apiKey').then(({ apiKey }) => { q('#acp-sem-chave').hidden = !!apiKey; }).catch(() => {});
  sec.addEventListener('click', e => {
    if (e.target.closest('[data-abrir-config]')) abrirConfigAgenda(sec.closest('#acp-embedded'));
  });
  renderMensagens(true);

  // Programar: primeiro mostra a prévia de tudo que vai ser agendado; só agenda no "Confirmar"
  q('#acp-agenda-programar').addEventListener('click', async () => {
    const c = lerCfg();
    await salvarAgendaCfg(c);
    const prep = prepararAgendaMassa(c);
    if (prep.erro) return mostrarProgresso(prep.erro);
    mostrarProgresso('');
    abrirPrevia(c, prep);
  });

  const abrirPrevia = (c, prep) => {
    const raiz = sec.closest('#acp-embedded');
    raiz.querySelector('#agd-previa')?.remove();
    const fmtDia = (iso) => {
      const [Y, M, D] = iso.split('-').map(Number);
      return new Date(Y, M - 1, D).toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: '2-digit' }).replace('.', '');
    };
    const porDia = new Map();
    prep.itens.forEach(it => { if (!porDia.has(it.dia)) porDia.set(it.dia, []); porDia.get(it.dia).push(it); });
    const n = prep.itens.length;
    const nTexto = prep.itens.filter(it => !it.pack).length;
    const avisos = [];
    const pers = c.personas.find(p => p.id === c.persona);
    if (pers?.conta && c.modeloAtivo?.handle && pers.conta !== c.modeloAtivo.handle) avisos.push(`A persona ${pers.nome} é da conta ${pers.conta}, mas a conta ativa é ${c.modeloAtivo.handle}.`);
    if (c.teste) avisos.push('Modo teste: só o primeiro disparo vai ser agendado.');
    if (prep.semPropria) avisos.push(`${prep.semPropria} de ${nTexto} horários não têm mensagem própria: vão repetir outras em rodízio.`);
    const el = document.createElement('div');
    el.id = 'agd-previa';
    el.className = 'agd-folha';
    el.innerHTML = `
      <div class="agd-folha-topo">
        <div>
          <div class="agd-folha-titulo">${icone('olho')}Prévia da programação</div>
          <div class="agd-folha-sub">${n} ${n === 1 ? 'disparo' : 'disparos'} em ${porDia.size} ${porDia.size === 1 ? 'dia' : 'dias'} · ${escapeHtml(c.personas.find(p => p.id === c.persona)?.nome || 'sem persona')}</div>
        </div>
        <button class="agd-btn-icone" data-previa="fechar" title="Voltar">${icone('fechar')}</button>
      </div>
      <div class="agd-folha-corpo">
        ${avisos.map(a => `<div class="agd-aviso-box">${icone('alerta')}<span>${escapeHtml(a)}</span></div>`).join('')}
        ${[...porDia].map(([dia, itens]) => `
          <div class="agd-previa-dia">${escapeHtml(fmtDia(dia))}</div>
          ${itens.map(it => {
            const a = _assuntoDaHora(c, it.hora);
            return `<div class="agd-previa-item" data-assunto="${a}">
              <div class="agd-previa-meta"><b>${it.hora}</b><span class="agd-previa-tag">${escapeHtml(_ASSUNTOS_COPY[a][0])}</span></div>
              <div class="agd-previa-texto">${it.pack
                ? `${icone('pacote')}${escapeHtml(_rotuloPacote(it.pack))} <span class="agd-previa-nota">· texto do próprio pacote</span>`
                : escapeHtml(it.mensagem)}</div>
            </div>`;
          }).join('')}`).join('')}
      </div>
      <div class="agd-folha-rodape">
        <button class="acp-save-btn agd-btn-sec" data-previa="fechar">Voltar e ajustar</button>
        <button class="acp-big-btn" data-previa="ok">${icone(c.teste ? 'frasco' : 'raio')}<span>${c.teste ? 'Confirmar teste' : `Confirmar ${n} ${n === 1 ? 'disparo' : 'disparos'}`}</span></button>
      </div>`;
    raiz.appendChild(el);
    el.addEventListener('click', async e => {
      const acao = e.target.closest('[data-previa]')?.dataset.previa;
      if (acao === 'fechar') el.remove();
      if (acao !== 'ok') return;
      el.remove();
      const erro = await iniciarAgendaMassa(c, prep);
      if (erro) return mostrarProgresso(erro);
      // iniciarAgendaMassa atualizou rodízio e histórico no c: traz pro cfg do painel
      cfg.proxModelo = c.proxModelo;
      cfg.historicoCopies = c.historicoCopies;
    });
  };
}

// Monta o plano final (mensagem ou pacote de cada disparo) sem agendar nada. { erro } ou { itens, usados, nMsgs }
function prepararAgendaMassa(cfg) {
  let itens = montarPlanoAgenda(cfg);
  if (!itens.length) return { erro: '⚠️ Escolha dias e horários (no mínimo 10 min no futuro)' };
  if (cfg.teste) itens = itens.slice(0, 1);
  const mapa = _msgsMapa(cfg);
  const pool = _msgsPool(mapa);
  const usados = { pack: 0, video: 0 };
  let nMsg = 0, semPropria = 0;
  for (const it of itens) {
    const assunto = _assuntoDaHora(cfg, it.hora);
    if (_ACERVO_PROX[assunto]) {
      const lista = _listaPacotes(cfg, assunto);
      if (!cfg.modelo) return { erro: '⚠️ Escolha a modelo no registro de packs' };
      const nomeModelo = _nomeModeloPack(cfg);
      if (!lista.length) return { erro: `⚠️ Marque ✓ em pelo menos um ${assunto === 'video' ? 'vídeo' : 'pack'} de ${nomeModelo} no registro` };
      // Intercala continuando de onde a última programação dessa modelo parou
      it.pack = lista[(_proxRodizio(cfg, assunto) + usados[assunto]++) % lista.length];
      it.mensagem = '';
    } else {
      if (!pool.length) return { erro: '⚠️ Escreva ou gere pelo menos uma mensagem (aba Copy)' };
      // Mensagem própria do horário; sem ela, repete uma das outras em rodízio
      const propria = _msgDoHorario(mapa, it);
      if (!propria) semPropria++;
      it.mensagem = propria || pool[nMsg++ % pool.length];
    }
  }
  return { itens, usados, semPropria };
}

async function iniciarAgendaMassa(cfg, prep = prepararAgendaMassa(cfg)) {
  if (prep.erro) return prep.erro;
  const { itens, usados } = prep;
  if (!cfg.teste) {
    // Atualiza o cfg recebido (o painel copia de volta): rodízio de pacotes + histórico de copies enviadas
    if (usados.pack || usados.video) {
      const chave = cfg.modelo || '';
      cfg.proxModelo = { ...(cfg.proxModelo || {}), [chave]: { ...(cfg.proxModelo?.[chave] || {}) } };
      for (const assunto of Object.keys(_ACERVO_PROX)) {
        const n = _listaPacotes(cfg, assunto).length;
        if (n) cfg.proxModelo[chave][assunto] = (_proxRodizio(cfg, assunto) + usados[assunto]) % n;
      }
    }
    cfg.historicoCopies = [...new Set([...(cfg.historicoCopies || []), ...itens.map(it => it.mensagem).filter(Boolean)])].slice(-HISTORICO_MAX);
    await salvarAgendaCfg(cfg);
  }
  await chrome.storage.local.set({
    acp_agenda_job: { itens, idx: 0, teste: cfg.teste, limiteDia: cfg.limiteDia, ok: 0, falhas: [], seguidas: 0 }
  });
  _irCalendario();
  return '';
}

// ── Execução na página /calendar ──

function deepQueryAll(seletor, root = document) {
  const achados = [...root.querySelectorAll(seletor)];
  for (const el of root.querySelectorAll('*')) {
    if (el.shadowRoot) achados.push(...deepQueryAll(seletor, el.shadowRoot));
  }
  return achados;
}

function _visivel(el) {
  return !!el && el.isConnected && el.getClientRects().length > 0;
}

function _textoDireto(el) {
  let t = '';
  for (const n of el.childNodes) if (n.nodeType === 3) t += n.textContent;
  return t.trim();
}

async function _esperarAte(fn, timeoutMs = 8000, passo = 250) {
  const fim = Date.now() + timeoutMs;
  while (Date.now() < fim) {
    const r = fn();
    if (r) return r;
    await esperar(passo);
  }
  return null;
}

function _contarMassaNoDia(dia) {
  const [Y, M, D] = dia.split('-').map(Number);
  const label = deepQueryAll('.nav-label').find(_visivel)?.textContent.trim().toLowerCase();
  if (label !== `${_MESES_PT[M - 1]} ${Y}`) return 0;
  const cel = deepQueryAll('.__day-cell').find(c =>
    !c.classList.contains('is-outside') && c.querySelector('.day-number')?.textContent.trim() === String(D));
  const pill = cel?.querySelector('.__event-pill.is-message');
  return pill ? parseInt(pill.textContent) || 0 : 0;
}

async function _abrirCriarMassa() {
  const opcao = () => deepQueryAll('.__create-option-item').find(b => _visivel(b) && /mensagem em massa/i.test(b.textContent));
  if (!opcao()) {
    // O "+" é o último botão do cabeçalho (o primeiro é o voltar)
    const botoes = deepQueryAll('button.header-action:not(.is-toggle)').filter(_visivel);
    const mais = botoes[botoes.length - 1];
    if (!mais || botoes.length < 2) throw new Error('Botão "Criar" do calendário não encontrado');
    mais.click();
  }
  const op = await _esperarAte(opcao, 5000);
  if (!op) throw new Error('Menu "Criar" não abriu');
  op.click();
}

async function _escolherDiaPicker(dlg, dia) {
  const [Y, M, D] = dia.split('-').map(Number);
  dlg.querySelector('#tab-calendar')?.click();
  await esperar(400);

  for (let t = 0; t < 3; t++) {
    const titulo = (dlg.querySelector('.custom-text')?.textContent || '').trim().toLowerCase();
    const [mesNome, anoTxt] = titulo.split(/\s+/);
    const mes = _MESES_PT.indexOf(mesNome);
    if (mes < 0) break;
    const diff = (Y * 12 + M - 1) - (parseInt(anoTxt) * 12 + mes);
    if (diff === 0) break;
    const cab = dlg.querySelector('.custom-text').parentElement;
    const setas = [...cab.querySelectorAll('button, [role="button"], svg')]
      .map(s => s.closest('button, [role="button"]') || s.parentElement)
      .filter((s, i, a) => s && !s.contains(dlg.querySelector('.custom-text')) && a.indexOf(s) === i);
    const seta = diff > 0 ? setas[setas.length - 1] : setas[0];
    if (!seta) throw new Error('Não achei a seta pra trocar de mês no calendário');
    seta.click();
    await esperar(500);
  }

  const cel = [...dlg.querySelectorAll('.dp__calendar_item .dp__cell_inner')].find(c =>
    c.textContent.trim() === String(D) && !c.classList.contains('dp__cell_disabled') && !c.classList.contains('dp__cell_offset'));
  if (!cel) throw new Error(`Dia ${D} indisponível no seletor de data`);
  cel.click();
  await esperar(400);
}

async function _ajustarTempo(dlg, unidade, alvo) {
  const ler = () => parseInt(dlg.querySelector(`[aria-label="Open ${unidade} overlay"]`)?.textContent.trim(), 10);
  let semMudar = 0;
  for (let i = 0; i < 90; i++) {
    const atual = ler();
    if (isNaN(atual)) throw new Error('Seletor de hora não encontrado');
    if (atual === alvo) return;
    const inc = dlg.querySelector(`[aria-label="Increment ${unidade}"]`);
    const dec = dlg.querySelector(`[aria-label="Decrement ${unidade}"]`);
    const travado = (b) => !b || b.classList.contains('dp__inc_dec_button_disabled');
    let botao = alvo > atual ? inc : dec;
    if (travado(botao)) botao = botao === inc ? dec : inc;
    if (travado(botao)) break;
    botao.click();
    await esperar(40);
    if (ler() === atual && ++semMudar >= 3) break;
  }
  if (ler() !== alvo) throw new Error(`Não consegui ajustar ${unidade === 'hours' ? 'a hora' : 'os minutos'} pra ${alvo}`);
}

async function _escolherHoraPicker(dlg, hora) {
  const [hh, mm] = hora.split(':').map(Number);
  dlg.querySelector('#tab-timer')?.click();
  await esperar(400);
  await _ajustarTempo(dlg, 'hours', hh);
  await _ajustarTempo(dlg, 'minutes', mm);
}

async function _preencherMensagemMassa(texto) {
  const ta = await _esperarAte(() => deepQueryAll('textarea.ce-textarea').find(_visivel), 10000);
  if (!ta) throw new Error('Caixa de mensagem não apareceu');
  ta.focus();
  ta.value = texto;
  ta.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, data: texto, inputType: 'insertText' }));
  ta.dispatchEvent(new Event('change', { bubbles: true }));
  ta.dispatchEvent(new KeyboardEvent('keyup', { key: ' ', bubbles: true, composed: true }));
  await esperar(600);
  return ta;
}

let _agendaUltimaEtapaEm = Date.now();

function _irCalendario() {
  location.href = 'https://privacy.com.br/calendar?acp=' + Date.now();
  setTimeout(() => location.reload(), 5000);
}

function _etapaAgenda(txt) {
  _agendaUltimaEtapaEm = Date.now();
  console.log('[Agendador]', txt);
  chrome.storage.local.set({ acp_agenda_etapa: new Date().toLocaleTimeString() + ' ' + location.pathname + ' — ' + txt }).catch(() => {});
}

function _overlayAgenda(texto, comParar = true) {
  let box = document.getElementById('agd-agenda-overlay');
  if (!box) {
    box = document.createElement('div');
    box.id = 'agd-agenda-overlay';
    box.style.cssText = AGD_OVERLAY_CSS;
    document.body.appendChild(box);
  }
  box.innerHTML = '';
  const p = document.createElement('div');
  p.textContent = texto;
  box.appendChild(p);
  const btn = document.createElement('button');
  btn.textContent = comParar ? 'Parar agendamento' : 'Fechar';
  btn.style.cssText = AGD_OVERLAY_BTN_CSS;
  btn.addEventListener('click', async () => {
    if (comParar) {
      const { acp_agenda_job: job } = await chrome.storage.local.get('acp_agenda_job');
      await chrome.storage.local.remove('acp_agenda_job');
      if (job) _reportarFilaFim(job, 'parado');
    }
    box.remove();
  });
  box.appendChild(btn);
}

// Parte 1 (/calendar): Criar → Mensagem em massa → data/hora → Confirmar.
// Depois do Confirmar a Privacy carrega /chat com a tela de mensagem em massa; a fase fica salva no job
// pra que o content script da página nova continue de onde parou.
async function _agendarParteCalendario(it, job) {
  const ja = _contarMassaNoDia(it.dia);
  if (ja >= job.limiteDia) return { pulado: `${it.dia} já tem ${ja} mensagem(ns)` };

  _etapaAgenda('abrindo Criar');
  await _abrirCriarMassa();

  const dlg = await _esperarAte(() => deepQueryAll('.__dialog-calendar').find(_visivel), 8000);
  if (!dlg) throw new Error('Janela "Data de agendamento" não abriu');
  _etapaAgenda('escolhendo dia');
  await _escolherDiaPicker(dlg, it.dia);
  _etapaAgenda('escolhendo hora');
  await _escolherHoraPicker(dlg, it.hora);
  const rotuloHora = dlg.querySelector('#tab-timer')?.textContent.trim();
  if (rotuloHora && rotuloHora !== it.hora) throw new Error(`Hora ficou ${rotuloHora} em vez de ${it.hora}`);
  const confirmar = [...dlg.querySelectorAll('.dialog-footer button')].find(b => /confirmar/i.test(b.textContent));
  if (!confirmar) throw new Error('Botão Confirmar não encontrado');

  job.fase = 'chat';
  await chrome.storage.local.set({ acp_agenda_job: job });
  _etapaAgenda('confirmando data/hora');
  confirmar.click();

  // Se a Privacy trocar de tela sem recarregar, segue aqui mesmo; se recarregar, a página nova continua
  await esperar(1500);
  return await _agendarParteChat(it, job);
}

// Lê nome + @usuário (e foto, se achar) da modelo logada agora: abre o menu de usuário (ícone no topo da Privacy),
// lê do cartão de perfil que aparece lá, e tenta fechar de novo com Esc.
async function _detectarModeloAtivo() {
  const botaoUsuario = await _esperarAte(() => deepQueryAll('#privacy-header--avatar-button').find(_visivel), 8000);
  if (!botaoUsuario) throw new Error('Não achei o botão de usuário no topo da página da Privacy.');
  botaoUsuario.click();

  const nomeEl = await _esperarAte(() => deepQueryAll('.user-name').find(_visivel), 8000);
  if (!nomeEl) throw new Error('O menu abriu mas não achei o nome — pode ter mudado de lugar na Privacy.');
  const nome = nomeEl.textContent.trim();
  const handle = deepQueryAll('.user-profile-name').find(_visivel)?.textContent.trim() || '';
  // A capa é bem mais larga que alta; o avatar é quase quadrado/redondo. Pega o mais quadrado pra não pegar a capa.
  const imgsVisiveis = deepQueryAll('.drawer.el-drawer img').filter(_visivel);
  const avatarImg = imgsVisiveis
    .map(img => ({ img, r: img.getBoundingClientRect() }))
    .filter(({ r }) => r.width > 0 && r.height > 0)
    .sort((a, b) => (a.r.width / a.r.height) - (b.r.width / b.r.height))[0]?.img;
  const foto = avatarImg?.src || '';

  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  document.dispatchEvent(new KeyboardEvent('keyup', { key: 'Escape', bubbles: true }));

  return { nome, handle, foto };
}

// Lê todos os pacotes do Acervo (nome + preço) sem anexar nenhum: abre Mídia → "Acervo na Privacy" → Pacotes,
// lista tudo e fecha de novo com "Cancelar". Exige uma caixa de mensagem aberta na tela (mesma exigência do _anexarPacote).
async function _listarPacotesAcervo() {
  const midia = await _esperarAte(() => deepQueryAll('[aria-label="Adicionar mídia local à publicação"]').find(_visivel), 8000);
  if (!midia) throw new Error('Abra uma conversa com a caixa de mensagem visível antes de sincronizar.');
  midia.click();
  const acervo = await _esperarAte(() => deepQueryAll('.ce-media-sheet__option').find(b => _visivel(b) && /acervo/i.test(b.textContent)), 8000);
  if (!acervo) throw new Error('Opção "Acervo na Privacy" não apareceu');
  acervo.click();

  const abaPacotes = await _esperarAte(() => deepQueryAll('.vault-side__head').find(b => _visivel(b) && /pacotes/i.test(b.textContent)), 15000);
  if (!abaPacotes) throw new Error('Acervo não abriu (aba Pacotes não apareceu)');
  abaPacotes.click();

  const pacotes = await _esperarAte(() => {
    const l = deepQueryAll('.vault-bundle__open').filter(_visivel);
    return l.length ? l : null;
  }, 15000);
  if (!pacotes) throw new Error('Nenhum pacote apareceu no Acervo');

  const lista = pacotes.map(b => ({
    nome: b.querySelector('.vault-bundle__name')?.textContent.trim() || '',
    preco: b.querySelector('.vault-bundle__price')?.textContent.trim() || ''
  })).filter(p => p.nome);

  const cancelar = deepQueryAll('.vault-dialog__footer button').find(_visivel);
  if (cancelar) cancelar.click();

  return lista;
}

// Anexa um pacote do Acervo: Mídia → "Acervo na Privacy" → Pacotes → pacote → "Usar este pacote?".
// alvo = pacote do registro { preco, nome }: se os dois estiverem preenchidos, os dois têm que bater.
// Devolve a descrição do pacote.
async function _anexarPacote(alvo) {
  const precoAlvo = (alvo.preco || '').replace(/[^\d,.]/g, '').replace('.', ',');
  const norm = s => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();

  const midia = await _esperarAte(() => deepQueryAll('[aria-label="Adicionar mídia local à publicação"]').find(_visivel), 8000);
  if (!midia) throw new Error('Botão de mídia não encontrado');
  midia.click();
  const acervo = await _esperarAte(() => deepQueryAll('.ce-media-sheet__option').find(b => _visivel(b) && /acervo/i.test(b.textContent)), 8000);
  if (!acervo) throw new Error('Opção "Acervo na Privacy" não apareceu');
  acervo.click();

  const abaPacotes = await _esperarAte(() => deepQueryAll('.vault-side__head').find(b => _visivel(b) && /pacotes/i.test(b.textContent)), 15000);
  if (!abaPacotes) throw new Error('Acervo não abriu (aba Pacotes não apareceu)');
  abaPacotes.click();

  const pacotes = await _esperarAte(() => {
    const l = deepQueryAll('.vault-bundle__open').filter(_visivel);
    return l.length ? l : null;
  }, 15000);
  if (!pacotes) throw new Error('Nenhum pacote apareceu no Acervo');
  const info = b => ({
    nome: b.querySelector('.vault-bundle__name')?.textContent.trim() || '',
    preco: b.querySelector('.vault-bundle__price')?.textContent.trim() || '',
    desc: b.querySelector('.vault-bundle__description')?.textContent.trim() || ''
  });
  const precoBate = b => !precoAlvo || info(b).preco.replace(/\s/g, '').endsWith(precoAlvo);
  // Nome exato primeiro; senão aceita nome cortado/maior (um começa com o outro) com o mesmo preço
  const alvoNome = norm(alvo.nome);
  const pacote = pacotes.find(b => precoBate(b) && (!alvoNome || norm(info(b).nome) === alvoNome))
    || (alvoNome && pacotes.find(b => {
      const nome = norm(info(b).nome);
      return precoBate(b) && nome && (nome.startsWith(alvoNome) || alvoNome.startsWith(nome));
    }));
  if (!pacote) {
    const lista = pacotes.map(b => `${info(b).nome} (${info(b).preco})`).join(', ');
    throw new Error(`Pacote ${_rotuloPacote(alvo)}${alvo.nome ? ` com nome "${alvo.nome}"` : ''} não encontrado no Acervo. Tem: ${lista}`);
  }
  const { desc, preco } = info(pacote);
  pacote.click();

  // Na mensagem em massa o pacote costuma anexar direto; em outras telas abre a gaveta "Usar este pacote?"
  _etapaAgenda('esperando pacote anexar');
  const acharChip = () => deepQueryAll('.ce-price-chip__amount').find(_visivel);
  const passo = await _esperarAte(() => {
    const chip = acharChip();
    if (chip) return { chip };
    const gaveta = deepQueryAll('.drawer-vault-bundle').find(_visivel);
    const usar = gaveta && [...gaveta.querySelectorAll('button')].find(b =>
      _visivel(b) && !b.classList.contains('vac-float-filter-close') && /usar|confirmar|sim|adicionar/i.test(b.textContent));
    return usar ? { usar } : null;
  }, 15000);
  if (passo?.usar) {
    _etapaAgenda('confirmando "Usar este pacote?"');
    passo.usar.click();
  }

  const chip = passo?.chip || await _esperarAte(acharChip, 15000);
  if (!chip) throw new Error('Pacote não foi anexado (preço não apareceu no editor)');
  const precoChip = chip.textContent.replace(/\s/g, '');
  if (precoChip !== preco.replace(/\s/g, '')) throw new Error(`Preço ficou ${chip.textContent.trim()} em vez de ${preco}`);
  _etapaAgenda('pacote anexado: ' + chip.textContent.trim());
  await esperar(800);
  return desc;
}

// Parte 2 (/chat): Todos → Aplicar filtro → mensagem → enviar
async function _agendarParteChat(it, job) {
  _etapaAgenda('esperando tela de mensagem em massa');
  const telaMassa = await _esperarAte(() => deepQueryAll('.filter-title').find(_visivel), 25000);
  if (!telaMassa) {
    _agendaUltimaEtapaEm = 0; // vigia refaz o item a partir do calendário
    await esperar(60000);
    throw new Error('Tela de mensagem em massa não carregou');
  }
  await esperar(2000);

  _etapaAgenda('escolhendo público Todos');
  const todos = await _esperarAte(() => deepQueryAll('div').find(d => _visivel(d) && _textoDireto(d) === 'Todos'), 20000);
  if (!todos) throw new Error('Lista de contatos (Todos) não apareceu');
  todos.click();
  const aplicar = await _esperarAte(() => deepQueryAll('button').find(b =>
    _visivel(b) && /aplicar filtro/i.test(b.textContent) && !b.disabled && !b.classList.contains('is-disabled')), 6000);
  if (!aplicar) throw new Error('"Aplicar filtro" não habilitou depois de escolher Todos');
  aplicar.click();

  _etapaAgenda('confirmando contatos selecionados');
  const escrever = await _esperarAte(() => deepQueryAll('button.confirmation-selected-button, button').find(b =>
    _visivel(b) && /escrever mensagem/i.test(b.textContent)), 10000);
  if (!escrever) throw new Error('Botão "Escrever mensagem" não apareceu depois de aplicar o filtro');
  const totalContatos = deepQueryAll('.confirmation-selected-total').find(_visivel)?.textContent.trim();
  if (totalContatos) _etapaAgenda(`${totalContatos} contatos selecionados`);
  escrever.click();
  await _esperarAte(() => deepQueryAll('.info-title').find(e => _visivel(e) && /escreva sua mensagem/i.test(e.textContent)), 10000);
  await esperar(1500);

  let textoPack = '';
  if (it.pack) {
    _etapaAgenda('anexando pacote ' + _rotuloPacote(it.pack));
    textoPack = await _anexarPacote(it.pack);
  }

  _etapaAgenda('escrevendo mensagem');
  const taAtual = deepQueryAll('textarea.ce-textarea').find(_visivel);
  // Pack: se a Privacy já colocou o texto do pacote, mantém; senão escreve a descrição dele
  const ta = it.mensagem || !taAtual?.value.trim()
    ? await _preencherMensagemMassa(it.mensagem || textoPack)
    : taAtual;
  if (!ta.value.trim()) throw new Error('Mensagem ficou vazia');
  const raiz = ta.getRootNode();
  // Botão redondo "Enviar mensagem" do editor da Privacy (nunca os botões do Chatix)
  const acharEnviar = () => [...raiz.querySelectorAll('button.ce-send-circle, [aria-label="Enviar mensagem"], .ce-button-send')]
    .find(b => _visivel(b) && !/acp-/.test(b.className || ''));
  const enviar = await _esperarAte(acharEnviar, 5000);
  if (!enviar) {
    const botoes = [...raiz.querySelectorAll('[aria-label], [role="button"], button')].filter(_visivel)
      .map(b => b.getAttribute('aria-label') || b.className || b.tagName).join(' | ');
    throw new Error('Botão de enviar não encontrado. Botões na barra: ' + botoes.slice(0, 300));
  }
  _etapaAgenda('botão enviar: ' + (enviar.getAttribute('aria-label') || enviar.className));

  const aviso = [...raiz.querySelectorAll('.ce-msg-info')].find(_visivel)?.textContent.replace(/\s+/g, ' ').trim() || '';
  if (!/programado para/i.test(aviso) || !aviso.includes(it.hora)) {
    throw new Error(`Agendamento não confirmado na tela (aviso: "${aviso || 'nenhum'}") — não enviei pra não disparar na hora`);
  }
  _etapaAgenda('aviso: ' + aviso);

  if (job.teste) {
    enviar.style.outline = '3px solid #2fbf71';
    enviar.style.outlineOffset = '2px';
    return { teste: true };
  }

  _etapaAgenda('clicando enviar');
  enviar.click();
  // Algumas versões pedem confirmação depois de enviar
  await esperar(2500);
  const confirmacao = deepQueryAll('.el-dialog button.el-button--primary, .el-message-box button.el-button--primary')
    .find(b => _visivel(b) && /confirmar|agendar|enviar|sim/i.test(b.textContent));
  if (confirmacao) confirmacao.click();

  const saiu = await _esperarAte(() => !_visivel(ta) || !ta.value.trim(), 12000);
  if (!saiu) throw new Error('A mensagem não saiu da tela depois de enviar — confira no calendário');
  return { ok: true };
}

let _agendaRodando = false;

// A fila é apagada no fim; o resultado fica guardado pro painel mostrar o motivo de cada erro
async function _guardarResultadoAgenda(job, total) {
  console.log('[Chatix agenda] falhas:', job.falhas);
  await chrome.storage.local.set({
    acp_agenda_resultado: { em: new Date().toLocaleString('pt-BR'), ok: job.ok, total, falhas: job.falhas }
  }).catch(() => {});
}

// Fila do Synora: conta pro site como está o agendamento. Nunca trava nem quebra o robô: erro de rede só vai pro console.
function _reportarFila(job, campos) {
  if (!job?.filaId) return;
  try {
    chrome.runtime.sendMessage({ tipo: 'SYN_FILA_ATUALIZAR', id: job.filaId, campos })
      .then(r => { if (r?.erro) console.warn('[Agendador] Synora:', r.erro); })
      .catch(err => console.warn('[Agendador] Synora:', err?.message || err));
  } catch (err) {
    console.warn('[Agendador] Synora:', err?.message || err);
  }
}
const _reportarFilaProgresso = (job) => _reportarFila(job, {
  status: 'agendando', ok: job.ok, falhas: job.falhas, idx: job.idx, progresso: `${job.idx}/${job.itens.length}`
});
const _reportarFilaFim = (job, motivo) => _reportarFila(job, synStatusFinal(job, motivo));

function _iniciarVigiaAgenda() {
  setInterval(async () => {
    if (!_agendaRodando || Date.now() - _agendaUltimaEtapaEm < 45000) return;
    const { acp_agenda_job: job } = await chrome.storage.local.get('acp_agenda_job');
    if (!job) return;
    job.tentativas = job.tentativas || {};
    job.tentativas[job.idx] = (job.tentativas[job.idx] || 0) + 1;
    if (job.tentativas[job.idx] > 2) {
      const it = job.itens[job.idx];
      job.falhas.push(`${it.dia} ${it.hora}: travou 3 vezes, pulei`);
      job.idx++;
    }
    job.fase = '';
    await chrome.storage.local.set({ acp_agenda_job: job });
    _etapaAgenda('travado há 45s, recarregando');
    _irCalendario();
  }, 5000);
}

async function retomarAgendaMassa() {
  const { acp_agenda_job: job } = await chrome.storage.local.get('acp_agenda_job');
  if (!job || _agendaRodando) return;
  _agendaRodando = true;
  _iniciarVigiaAgenda();
  _etapaAgenda(`fila encontrada, idx ${job.idx}, fase ${job.fase || 'calendario'}`);

  const total = job.itens.length;
  if (job.idx >= total) {
    await chrome.storage.local.remove('acp_agenda_job');
    await _guardarResultadoAgenda(job, total);
    _reportarFilaFim(job, 'fim');
    const falhas = job.falhas.length ? `\n\n⚠️ ${job.falhas.length} com problema:\n${_resumoFalhas(job.falhas)}` : '';
    _overlayAgenda(`✅ Programação concluída: ${job.ok} de ${total} agendada(s).${falhas}`, false);
    return;
  }

  const naChat = job.fase === 'chat' && location.pathname.startsWith('/chat');
  if (!naChat && !location.pathname.startsWith('/calendar')) {
    _irCalendario();
    return;
  }

  const it = job.itens[job.idx];
  _overlayAgenda(`📅 Programando ${job.idx + 1} de ${total}\n${it.dia.split('-').reverse().join('/')} às ${it.hora}${it.pack ? `\n📦 ${_rotuloPacote(it.pack)}` : ''}\n\nNão mexa nesta aba e deixe ela aberta na frente até terminar.`);

  let r;
  try {
    if (naChat) {
      r = await _agendarParteChat(it, job);
    } else {
      // Caiu de volta no calendário no meio da fase do chat: refaz o item do zero
      job.fase = '';
      _etapaAgenda(`item ${job.idx + 1}/${total}: esperando calendário`);
      const carregou = await _esperarAte(() => deepQueryAll('.__day-cell').length > 0, 20000);
      await esperar(1500);
      if (!carregou) throw new Error('Calendário não carregou');
      r = await _agendarParteCalendario(it, job);
    }
  } catch (err) {
    r = { erro: err.message };
    if (naChat) { baixarMapaTela(); await esperar(1500); }
  }

  // Usuário pode ter clicado em Parar no meio
  const { acp_agenda_job: atual } = await chrome.storage.local.get('acp_agenda_job');
  if (!atual) return;

  if (r.teste) {
    await chrome.storage.local.remove('acp_agenda_job');
    _reportarFilaFim(job, 'teste');
    _overlayAgenda(`🧪 Teste pronto: ${it.dia.split('-').reverse().join('/')} às ${it.hora}, público Todos, mensagem preenchida.\n\nConfira a tela. Se estiver tudo certo, clique você no botão de enviar (marcado em verde) ou feche sem enviar.\n\n${job.filaId ? 'Depois desligue o "Modo teste" no Synora e mande pra fila de novo pra programar tudo.' : 'Depois desmarque o "Modo teste" no painel pra programar tudo.'}`, false);
    return;
  }

  _etapaAgenda('resultado: ' + JSON.stringify(r));
  if (r.ok) { job.ok++; job.seguidas = 0; }
  else if (r.pulado) { job.falhas.push(`${it.dia} ${it.hora}: pulado (${r.pulado})`); }
  else { job.falhas.push(`${it.dia} ${it.hora}: ${r.erro}`); job.seguidas++; }
  job.idx++;
  job.fase = '';

  if (job.seguidas >= 3) {
    await chrome.storage.local.remove('acp_agenda_job');
    await _guardarResultadoAgenda(job, job.itens.length);
    _reportarFilaFim(job, 'erros');
    _overlayAgenda(`⛔ Parei depois de 3 erros seguidos.\n\n${job.falhas.slice(-3).join('\n')}\n\n${job.ok} agendada(s) antes do erro.`, false);
    return;
  }

  await chrome.storage.local.set({ acp_agenda_job: job });
  _reportarFilaProgresso(job);
  await esperar(1500);
  _irCalendario();
}


// ═══════════════════════════════════════════════
// PAINEL FLUTUANTE
// ═══════════════════════════════════════════════


let _agdHost = null;
let _agdRaiz = null;

// ── Configurações (chave da OpenRouter e modelo da IA), salvas só neste Chrome ──

// Começo da chave que vinha escrita no código das versões antigas (exposta): avisa pra trocar
const _CHAVE_EXPOSTA = 'sk-or-v1-3f2391aa';

async function abrirConfigAgenda(raiz) {
  raiz.querySelector('#agd-config')?.remove();
  const { apiKey = '', modelo = '' } = await chrome.storage.local.get(['apiKey', 'modelo']);
  const el = document.createElement('div');
  el.id = 'agd-config';
  el.className = 'agd-folha';
  el.innerHTML = `
    <div class="agd-folha-topo">
      <div>
        <div class="agd-folha-titulo">${icone('engrenagem')}Configurações</div>
        <div class="agd-folha-sub">Ficam salvas só neste Chrome (não vão no backup)</div>
      </div>
      <button class="agd-btn-icone" data-cfg="fechar" title="Fechar">${icone('fechar')}</button>
    </div>
    <div class="agd-folha-corpo">
      <div class="acp-card">
        <div class="acp-card-label">${icone('chave')}Chave da OpenRouter</div>
        <div class="agd-dica">Crie em openrouter.ai → Keys. Não mande pra ninguém: quem tiver a chave gasta seus créditos.</div>
        ${apiKey.startsWith(_CHAVE_EXPOSTA) ? `<div class="agd-aviso-box agd-perigo-box">${icone('alerta')}<span>Essa é a chave antiga que vinha escrita no código da extensão. Revogue ela no site da OpenRouter e cole uma nova aqui.</span></div>` : ''}
        <div class="agd-linha agd-espaco">
          <input class="acp-save-input" id="agd-cfg-chave" type="password" autocomplete="off" spellcheck="false" placeholder="sk-or-v1-..." value="${escapeHtml(apiKey)}">
          <button class="agd-btn-icone" data-cfg="ver" title="Mostrar / esconder">${icone('olho')}</button>
        </div>
        <label class="agd-campo agd-espaco">
          <span>Modelo da IA <em class="agd-campo-uso">id na OpenRouter</em></span>
          <input class="acp-save-input" id="agd-cfg-modelo" spellcheck="false" placeholder="google/gemma-4-31b-it" value="${escapeHtml(modelo)}">
        </label>
        <div class="agd-status" id="agd-cfg-status"></div>
      </div>
    </div>
    <div class="agd-folha-rodape">
      <button class="acp-save-btn agd-btn-sec" data-cfg="testar">Testar chave</button>
      <button class="acp-big-btn" data-cfg="salvar">${icone('chave')}<span>Salvar</span></button>
    </div>`;
  raiz.appendChild(el);
  const status = el.querySelector('#agd-cfg-status');
  const usd = (v) => v == null ? '—' : 'US$ ' + Number(v).toFixed(2);
  const testar = async () => {
    status.textContent = 'Testando...';
    const r = await chrome.runtime.sendMessage({ tipo: 'AGD_TESTAR_CHAVE', apiKey: el.querySelector('#agd-cfg-chave').value.trim() }).catch(err => ({ erro: err.message }));
    status.innerHTML = r?.erro
      ? `<span class="agd-aviso-txt">⚠️ ${escapeHtml(r.erro)}</span>`
      : `✅ Chave funcionando · usado ${usd(r.uso)}${r.limite != null ? ` de ${usd(r.limite)} (resta ${usd(r.restante)})` : ' · sem limite de crédito na chave'}`;
  };
  el.addEventListener('click', async (e) => {
    const acao = e.target.closest('[data-cfg]')?.dataset.cfg;
    if (acao === 'fechar') el.remove();
    else if (acao === 'ver') {
      const i = el.querySelector('#agd-cfg-chave');
      i.type = i.type === 'password' ? 'text' : 'password';
    } else if (acao === 'testar') testar();
    else if (acao === 'salvar') {
      const chave = el.querySelector('#agd-cfg-chave').value.trim();
      const mod = el.querySelector('#agd-cfg-modelo').value.trim();
      await chrome.storage.local.set({ apiKey: chave, ...(mod ? { modelo: mod } : {}) });
      const aviso = raiz.querySelector('#acp-sem-chave');
      if (aviso) aviso.hidden = !!chave;
      status.textContent = chave ? '💾 Salvo. Testando...' : '💾 Salvo (sem chave a IA não funciona).';
      if (chave) testar();
    }
  });
}

// ── Backup da configuração (.json) ──

async function exportarConfigAgenda() {
  const cfg = await obterAgendaCfg();
  const dados = { app: 'agendador-privacy', versao: 1, exportadoEm: new Date().toISOString(), cfg };
  const url = URL.createObjectURL(new Blob([JSON.stringify(dados, null, 2)], { type: 'application/json' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `agendador-config-${_dataISO(new Date())}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// Junta o backup por cima da config atual (o que não vier no arquivo fica como está). true = importou
async function importarConfigAgenda(arquivo) {
  let dados;
  try { dados = JSON.parse(await arquivo.text()); } catch { alert('Esse arquivo não é um JSON válido.'); return false; }
  const novo = dados?.app === 'agendador-privacy' ? dados.cfg : dados;
  const conhecidas = ['horarios', 'pacotesReg', 'modelos', 'personas', 'mensagens', 'roteiroHoras'];
  if (!novo || typeof novo !== 'object' || !conhecidas.some(k => k in novo)) {
    alert('Esse arquivo não parece um backup do Agendador.');
    return false;
  }
  const pacotes = (novo.pacotesReg || []).length, modelos = (novo.modelos || []).length;
  if (!confirm(`Importar configuração?\n\n${modelos} modelo(s) e ${pacotes} pacote(s) no arquivo.\nO que vier no arquivo substitui o que você tem agora.`)) return false;
  await salvarAgendaCfg({ ...(await obterAgendaCfg()), ...novo });
  return true;
}

// ═══════════════════════════════════════════════
// FILA DO SYNORA — o planejamento é feito no site geradorcopys.com.br; aqui só executa na Privacy
// ═══════════════════════════════════════════════

const _synEsc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let _synConta;          // conta logada na Privacy (undefined = ainda não detectou; null = falhou)
let _synContaErro = '';
let _synFilas = [];     // docs pendentes da agenda_fila
// "essa modelo do Synora é esta conta da Privacy": confirmado uma vez, lembrado pra sempre
let _synVinculos = {};
chrome.storage.local.get('syn_vinculos').then(r => { _synVinculos = r.syn_vinculos || {}; });
const _synChaveConta = (c) => c ? (synNormConta(c.handle) || synNormId(c.nome)) : '';
function _synEhDaConta(d) {
  if (!_synConta) return false;
  return synFilaDaConta(d, _synConta) || (!!_synChaveConta(_synConta) && _synVinculos[synNormId(d.modelo)] === _synChaveConta(_synConta));
}

function _synMsg(tipo, dados = {}) {
  return chrome.runtime.sendMessage({ tipo, ...dados })
    .then(r => r || { erro: 'Sem resposta da extensão' })
    .catch(err => ({ erro: /context invalidated/i.test(err?.message || '') ? 'A extensão foi recarregada: atualize a página (F5).' : (err?.message || String(err)) }));
}

// Pega a fila (só se ninguém mexeu desde a leitura) e começa o agendamento. { erro } ou { ok }
async function _synIniciarFila(d) {
  const itens = synItensParaJob(d.itens);
  if (!itens.length) return { erro: 'Essa fila está vazia.' };
  const res = await _synMsg('SYN_FILA_ATUALIZAR', {
    id: d.id, updateTime: d._updateTime || undefined,
    campos: { status: 'agendando', ok: 0, falhas: [], idx: 0, progresso: `0/${itens.length}`, nota: '' }
  });
  if (res.erro) return { erro: res.erro };
  // A rotação de pacotes e o histórico já foram feitos pelo site: aqui não mexe no cfg do modo antigo
  await chrome.storage.local.set({
    acp_agenda_job: {
      itens, idx: 0, teste: !!d.teste, limiteDia: Math.max(1, parseInt(d.limiteDia) || 10),
      ok: 0, falhas: [], seguidas: 0, filaId: d.id
    }
  });
  _irCalendario();
  return { ok: true };
}

// ── Automático: clicou "Mandar pra fila" no site → a Privacy aberta dessa modelo começa sozinha ──
// Só pega fila desta conta (pelo @, pelo nome ou pelo vínculo já confirmado). Fila de outra conta nunca começa sozinha.
const SYN_AUTO_INTERVALO = 15000;
const SYN_CONTA_VALIDADE = 6 * 3600 * 1000;
let _synAutoOcupado = false;
async function _synContaCacheada() {
  if (_synConta) return _synConta;
  const { syn_conta_cache: c } = await chrome.storage.local.get('syn_conta_cache');
  if (c && c.em && Date.now() - c.em < SYN_CONTA_VALIDADE && c.url === location.host) { _synConta = c.conta; return _synConta; }
  try {
    _synConta = await _detectarModeloAtivo();
    if (_synConta) await chrome.storage.local.set({ syn_conta_cache: { conta: _synConta, em: Date.now(), url: location.host } });
  } catch (e) { _synConta = null; }
  return _synConta;
}
async function _synAutoVerificar() {
  if (_synAutoOcupado || document.hidden) return;
  _synAutoOcupado = true;
  try {
    const st = await chrome.storage.local.get(['syn_auto', 'acp_agenda_job']);
    if (st.syn_auto === false || st.acp_agenda_job) return;
    const login = await _synMsg('SYN_STATUS');
    if (!login.email) return;
    const r = await _synMsg('SYN_FILA_LISTAR');
    if (r.erro || !(r.docs || []).length) return;
    _synFilas = r.docs;
    if (!(await _synContaCacheada())) return;
    const d = _synFilas.find(_synEhDaConta);
    if (!d) return;
    const res = await _synIniciarFila(d);
    if (res.erro) console.warn('[Agendador] fila do Synora:', res.erro);
    else _overlayAgenda(`Synora: começando ${d.itens?.length || ''} disparos de ${d.modelo || 'modelo'}…`);
  } catch (e) {
    console.warn('[Agendador] automático:', e);
  } finally {
    _synAutoOcupado = false;
  }
}

function renderizarSecaoSynora(box) {
  box.innerHTML = `
    <div class="acp-card syn-card">
      <div class="acp-card-label">${icone('lista')}Fila do Synora <span class="agd-label-extra" id="syn-chip"></span></div>
      <div class="agd-aviso-box syn-versao" id="syn-versao" hidden></div>
      <div id="syn-carregando" class="agd-dica">Conferindo login…</div>
      <div id="syn-off" hidden>
        <div class="agd-dica">Entre com o login do site geradorcopys.com.br</div>
        <form id="syn-form" class="syn-form">
          <input class="acp-save-input" id="syn-email" type="email" placeholder="E-mail" autocomplete="username" spellcheck="false">
          <input class="acp-save-input" id="syn-senha" type="password" placeholder="Senha" autocomplete="current-password">
          <button class="acp-big-btn" id="syn-entrar" type="submit">Entrar</button>
        </form>
        <div class="agd-status" id="syn-login-status"></div>
      </div>
      <div id="syn-on" hidden>
        <div class="syn-linha syn-muted">Conectado como <b id="syn-email-on"></b><button class="agd-link" id="syn-sair">Sair</button></div>
        <div class="syn-conta" id="syn-conta"></div>
        <label class="syn-linha syn-auto"><input type="checkbox" id="syn-auto"> <span>Agendar sozinho quando chegar fila do site <em class="syn-muted">(confere a cada 15 s com esta aba aberta)</em></span></label>
        <div class="syn-linha syn-subtitulo"><span>Pendentes desta conta</span><button class="agd-link" id="syn-recarregar">${icone('atualizar')}Atualizar</button></div>
        <div id="syn-lista"></div>
        <details id="syn-outras" hidden>
          <summary>Outras filas (<span id="syn-n-outras">0</span>)</summary>
          <div class="agd-aviso-box syn-aviso-outras">${icone('alerta')}<span id="syn-aviso-outras-txt">Estas filas são de OUTRA conta/modelo. Só agende se tiver certeza de que a Privacy aberta agora é a conta certa.</span></div>
          <div id="syn-lista-outras"></div>
        </details>
        <div class="agd-status" id="syn-status"></div>
        <div class="syn-acervo">
          <div class="agd-sub-label">Pacotes do Acervo</div>
          <div class="agd-dica">Abra uma conversa no chat da Privacy (caixa de mensagem aparecendo) e clique abaixo. No site: Pacotes › Atualizar do Acervo.</div>
          <label class="agd-campo">
            <span>Modelo no Synora <em class="agd-campo-uso">cadastrada na Agenda do site</em></span>
            <select class="acp-save-input" id="syn-acervo-modelo"><option value="">Carregando…</option></select>
          </label>
          <button class="acp-save-btn" id="syn-acervo-btn">${icone('pacote')}Mandar pacotes do Acervo pro Synora</button>
          <div class="agd-status" id="syn-acervo-status"></div>
        </div>
      </div>
    </div>`;
  const q = (s) => box.querySelector(s);
  const status = (txt) => { q('#syn-status').textContent = txt || ''; };
  // Versão nova publicada no site? (geradorcopys.com.br/downloads/versoes.json)
  (async () => {
    try {
      const r = await fetch('https://geradorcopys.com.br/downloads/versoes.json?_=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) return;
      const v = (await r.json()).agendador;
      const minha = chrome.runtime.getManifest().version;
      const maior = (x, y) => {
        const a = String(x || '0').split('.').map(Number), b = String(y || '0').split('.').map(Number);
        for (let i = 0; i < Math.max(a.length, b.length); i++) { if ((a[i] || 0) !== (b[i] || 0)) return (a[i] || 0) > (b[i] || 0); }
        return false;
      };
      if (!v || !maior(v, minha)) return;
      const el = q('#syn-versao');
      el.innerHTML = `${icone('alerta')}<span>Tem versão nova do Agendador (${_synEsc(v)}; a sua é ${_synEsc(minha)}). <a href="https://geradorcopys.com.br/#extensoes" target="_blank" rel="noopener">Baixar no Synora</a></span>`;
      el.hidden = false;
    } catch (e) { /* sem internet: segue */ }
  })();
  chrome.storage.local.get('syn_auto').then(r => { q('#syn-auto').checked = r.syn_auto !== false; });
  q('#syn-auto').addEventListener('change', (e) => chrome.storage.local.set({ syn_auto: e.target.checked }));
  let modeloAcervoEditado = false;
  let minhas = null; // null = ainda carregando
  q('#syn-acervo-modelo').addEventListener('change', () => { modeloAcervoEditado = true; });
  // Lista as modelos da agência (as da Agenda) e já escolhe a da conta aberta pelo @
  const carregarMinhas = async () => {
    const r = await _synMsg('SYN_MINHAS_LISTAR');
    minhas = r.modelos || [];
    renderMinhas(r.erro);
  };
  const renderMinhas = (erro) => {
    const sel = q('#syn-acervo-modelo');
    if (erro) { sel.innerHTML = `<option value="">⚠️ ${_synEsc(erro)}</option>`; return; }
    if (minhas === null) { sel.innerHTML = '<option value="">Carregando suas modelos…</option>'; return; }
    if (!minhas.length) { sel.innerHTML = '<option value="">Nenhuma modelo cadastrada: cadastre na Agenda do site</option>'; return; }
    const atual = sel.value;
    sel.innerHTML = '<option value="">Escolha a modelo…</option>' + minhas.map(m => `<option value="${_synEsc(m.id)}">${_synEsc(m.nome)}${m.contaPrivacy ? ' (@' + _synEsc(m.contaPrivacy) + ')' : ''}</option>`).join('');
    const h = _synConta ? synNormConta(_synConta.handle) : '';
    const daConta = h && minhas.find(m => m.contaPrivacy === h);
    sel.value = modeloAcervoEditado && minhas.some(m => m.id === atual) ? atual : (daConta ? daConta.id : '');
  };

  const mostrarLogin = (email) => {
    q('#syn-carregando').hidden = true;
    q('#syn-off').hidden = !!email;
    q('#syn-on').hidden = !email;
    q('#syn-email-on').textContent = email || '';
    q('#syn-chip').textContent = email ? 'conectado' : 'não conectado';
  };

  const renderConta = () => {
    const c = _synConta;
    const el = q('#syn-conta');
    const detectar = `<button class="agd-link" id="syn-detectar">${icone('atualizar')}Detectar de novo</button>`;
    if (c === undefined) el.innerHTML = `<span>${icone('carregando', 'agd-girando')}Detectando a conta logada na Privacy…</span>`;
    else if (!c) el.innerHTML = `<span class="agd-aviso-txt">${icone('alerta')}Não detectei a conta${_synContaErro ? ': ' + _synEsc(_synContaErro) : ''}</span>${detectar}`;
    else el.innerHTML = `<span>${icone('pessoa')}Privacy aberta em <b>${_synEsc(c.nome)}</b>${c.handle ? ` <span class="syn-muted">${_synEsc(c.handle)}</span>` : ''}</span>${detectar}`;
    el.querySelector('#syn-detectar')?.addEventListener('click', () => detectarConta());
  };

  const cartao = (d, outra) => {
    const r = synResumoFila(d);
    const conta = synNormConta(d.contaPrivacy);
    const criado = d.criadoEm && !isNaN(Date.parse(d.criadoEm))
      ? new Date(d.criadoEm).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '';
    return `<div class="syn-item${outra ? ' syn-item-outra' : ''}">
      <div class="syn-item-topo">
        <b>${_synEsc(d.modelo || 'Sem nome')}</b>${conta ? ` <span class="syn-muted">@${_synEsc(conta)}</span>` : ''}
        ${d.teste ? '<span class="syn-badge">teste</span>' : ''}
      </div>
      <div class="syn-item-info">${r.total} ${r.total === 1 ? 'disparo' : 'disparos'}${r.periodo ? ` · ${_synEsc(r.periodo)}` : ''}</div>
      <div class="syn-item-info syn-muted">${criado ? _synEsc(criado) : ''}${d.criadoPor?.nome ? ` · por ${_synEsc(d.criadoPor.nome)}` : ''}</div>
      ${r.passados ? `<div class="syn-item-info agd-aviso-txt">${r.passados} ${r.passados === 1 ? 'horário já passou' : 'horários já passaram'} (a Privacy pode recusar)</div>` : ''}
      <button class="acp-big-btn syn-agendar${outra ? ' agd-incompleto' : ''}" data-syn-agendar="${_synEsc(d.id)}">${icone('calendario')}<span>Agendar na Privacy</span></button>
    </div>`;
  };

  const renderFilas = () => {
    const conhecida = !!_synConta;
    const daConta = conhecida ? _synFilas.filter(_synEhDaConta) : [];
    const outras = _synFilas.filter(d => !daConta.includes(d));
    q('#syn-lista').innerHTML = daConta.length
      ? daConta.map(d => cartao(d, false)).join('')
      : `<div class="agd-dica syn-vazio">${conhecida ? 'Nada pendente pra esta conta. Programe no site e mande pra fila.' : 'Detecte a conta pra ver as filas dela.'}</div>`;
    q('#syn-lista-outras').innerHTML = outras.map(d => cartao(d, true)).join('');
    q('#syn-n-outras').textContent = outras.length;
    q('#syn-outras').hidden = !outras.length;
    if (!conhecida && outras.length) q('#syn-outras').open = true;
    q('#syn-aviso-outras-txt').textContent = conhecida
      ? 'Estas filas são de OUTRA conta/modelo. Só agende se tiver certeza de que a Privacy aberta agora é a conta certa.'
      : 'Não sei qual conta está aberta. Confira se a Privacy está na modelo certa antes de agendar.';

    // Nomes pro Acervo: os das filas + o detectado; preenche com o da 1ª fila desta conta (ou o nome detectado)
    const nomes = [...new Set([...daConta, ..._synFilas].map(d => String(d.modelo || '').trim()).filter(Boolean))];
    renderMinhas();
  };

  const carregarFilas = async () => {
    const btn = q('#syn-recarregar');
    btn.disabled = true;
    q('#syn-lista').innerHTML = `<div class="agd-dica syn-vazio">${icone('carregando', 'agd-girando')}Carregando a fila…</div>`;
    const r = await _synMsg('SYN_FILA_LISTAR');
    btn.disabled = false;
    if (r.erro) {
      q('#syn-lista').innerHTML = `<div class="agd-aviso-box">${icone('alerta')}<span>${_synEsc(r.erro)}</span></div>`;
      if (/expirou|Entre com o login/i.test(r.erro)) mostrarLogin(null);
      return;
    }
    _synFilas = r.docs || [];
    renderFilas();
  };

  const detectarConta = async () => {
    _synConta = undefined;
    _synContaErro = '';
    renderConta();
    try {
      _synConta = await _detectarModeloAtivo();
      if (_synConta) chrome.storage.local.set({ syn_conta_cache: { conta: _synConta, em: Date.now(), url: location.host } });
    } catch (err) {
      _synConta = null;
      _synContaErro = err.message;
    }
    renderConta();
    renderFilas();
  };

  const agendar = async (id, btn) => {
    const d = _synFilas.find(x => x.id === id);
    if (!d) return;
    const outra = !_synEhDaConta(d);
    const itens = synItensParaJob(d.itens);
    if (!itens.length) return alert('Essa fila está vazia.');
    const r = synResumoFila(d);
    const aviso = outra
      ? `\n\n⚠️ ATENÇÃO: essa fila é de ${d.modelo || 'outra modelo'}${d.contaPrivacy ? ' (@' + synNormConta(d.contaPrivacy) + ')' : ''}${_synConta ? `, mas a Privacy aberta é ${_synConta.nome}${_synConta.handle ? ' ' + _synConta.handle : ''}` : ''}. As mensagens vão sair na conta aberta agora.`
      : '';
    // fila da conta aberta: começa direto; só pede confirmação quando é de outra conta
    if (outra && !confirm(`Agendar ${itens.length} ${itens.length === 1 ? 'disparo' : 'disparos'} de ${d.modelo || 'sem nome'}${r.periodo ? ' (' + r.periodo + ')' : ''} na Privacy?${d.teste ? '\n\nModo teste: só preenche o 1º e para antes de enviar.' : ''}\n\nA aba vai pro calendário e o robô agenda um por um. Não mexa nesta aba até terminar.${aviso}${_synConta ? '\n\nSe essa Privacy é mesmo da ' + (d.modelo || 'modelo') + ', clique em OK: eu lembro e não pergunto mais.' : ''}`)) return;
    if (outra && _synChaveConta(_synConta) && d.modelo) {
      _synVinculos[synNormId(d.modelo)] = _synChaveConta(_synConta);
      chrome.storage.local.set({ syn_vinculos: _synVinculos });
    }

    const { acp_agenda_job: andando } = await chrome.storage.local.get('acp_agenda_job');
    if (andando) {
      if (!confirm(`Já tem um agendamento em andamento nesta extensão (${andando.idx || 0} de ${andando.itens?.length || 0}). Parar ele e começar este?`)) return;
      await chrome.storage.local.remove('acp_agenda_job');
      _reportarFilaFim(andando, 'parado');
    }

    btn.disabled = true;
    btn.innerHTML = `${icone('carregando', 'agd-girando')}<span>Pegando a fila…</span>`;
    const res = await _synIniciarFila(d);
    if (res.erro) {
      status('⚠️ ' + res.erro);
      btn.disabled = false;
      btn.innerHTML = `${icone('calendario')}<span>Agendar na Privacy</span>`;
      carregarFilas();
      return;
    }
    status('✅ Começando… indo pro calendário.');
  };

  box.addEventListener('click', (e) => {
    const b = e.target.closest('[data-syn-agendar]');
    if (b && !b.disabled) agendar(b.dataset.synAgendar, b);
  });

  q('#syn-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = q('#syn-entrar');
    const st = q('#syn-login-status');
    btn.disabled = true;
    btn.textContent = 'Entrando…';
    st.textContent = '';
    const r = await _synMsg('SYN_LOGIN', { email: q('#syn-email').value.trim(), senha: q('#syn-senha').value });
    q('#syn-senha').value = '';
    btn.disabled = false;
    btn.textContent = 'Entrar';
    if (r.erro) { st.textContent = '⚠️ ' + r.erro; return; }
    entrou(r.email);
  });

  q('#syn-sair').addEventListener('click', async () => {
    await _synMsg('SYN_SAIR');
    _synFilas = [];
    mostrarLogin(null);
  });
  q('#syn-recarregar').addEventListener('click', carregarFilas);

  q('#syn-acervo-btn').addEventListener('click', async () => {
    const modeloId = q('#syn-acervo-modelo').value;
    const st = q('#syn-acervo-status');
    const m = (minhas || []).find(x => x.id === modeloId);
    if (!m) { st.textContent = '⚠️ Escolha a modelo (as que estão cadastradas na Agenda do site).'; return; }
    const nome = m.nome;
    const btn = q('#syn-acervo-btn');
    btn.disabled = true;
    btn.innerHTML = `${icone('carregando', 'agd-girando')}Lendo o Acervo…`;
    st.textContent = '';
    try {
      const lidos = await _listarPacotesAcervo();
      if (!lidos.length) throw new Error('Não achei nenhum pacote no Acervo.');
      btn.innerHTML = `${icone('carregando', 'agd-girando')}Mandando pro Synora…`;
      const r = await _synMsg('SYN_ACERVO_GRAVAR', { modelo: nome, modeloId, itens: lidos });
      if (r.erro) throw new Error(r.erro);
      st.textContent = `✅ ${r.total} ${r.total === 1 ? 'pacote mandado' : 'pacotes mandados'} pro Synora (${nome}). No site: Pacotes › Atualizar do Acervo.`;
    } catch (err) {
      st.textContent = '⚠️ ' + err.message;
    }
    btn.disabled = false;
    btn.innerHTML = `${icone('pacote')}Mandar pacotes do Acervo pro Synora`;
  });

  const entrou = (email) => {
    mostrarLogin(email);
    renderConta();
    renderFilas();
    carregarFilas();
    carregarMinhas();
    if (_synConta === undefined) detectarConta();
  };

  _synMsg('SYN_STATUS').then(r => {
    if (r.email) entrou(r.email);
    else {
      mostrarLogin(null);
      if (r.erro) q('#syn-login-status').textContent = '⚠️ ' + r.erro;
    }
  });
}

function abrirPainelAgendador() {
  if (_agdHost) { _agdHost.style.display = ''; return; }
  _agdHost = document.createElement('div');
  _agdHost.id = 'agd-host';
  // Shadow fechado: os seletores do robô (deepQueryAll) não enxergam os botões do painel
  _agdRaiz = _agdHost.attachShadow({ mode: 'closed' });
  const style = document.createElement('style');
  style.textContent = AGD_CSS;
  _agdRaiz.appendChild(style);
  const painel = document.createElement('div');
  painel.id = 'acp-embedded';
  painel.innerHTML = `<div id="agd-topo"><div id="agd-marca"><div id="agd-logo">${icone('calendario')}</div><div><div id="agd-nome">Agendador Privacy</div><div id="agd-sub">Mensagens em massa</div></div></div><div class="agd-topo-acoes"><button class="agd-btn-icone" id="agd-config-btn" title="Configurações (chave da IA)">${icone('engrenagem')}</button><button class="agd-btn-icone" id="agd-exportar" title="Exportar configuração (backup .json)">${icone('baixar')}</button><button class="agd-btn-icone" id="agd-importar" title="Importar configuração (.json)">${icone('enviar')}</button><input type="file" id="agd-importar-arquivo" accept=".json,application/json" hidden><button class="agd-btn-icone" id="agd-mapa" title="Baixar mapa da tela (debug)">${icone('mapa')}</button><button class="agd-btn-icone" id="agd-fechar" title="Fechar">${icone('fechar')}</button></div></div><div id="agd-conteudo"></div>`;
  _agdRaiz.appendChild(painel);
  painel.querySelector('#agd-fechar').addEventListener('click', fecharPainelAgendador);
  painel.querySelector('#agd-mapa').addEventListener('click', baixarMapaTela);
  painel.querySelector('#agd-config-btn').addEventListener('click', () => abrirConfigAgenda(painel));
  painel.querySelector('#agd-exportar').addEventListener('click', exportarConfigAgenda);
  const arquivo = painel.querySelector('#agd-importar-arquivo');
  painel.querySelector('#agd-importar').addEventListener('click', () => arquivo.click());
  arquivo.addEventListener('change', async () => {
    const f = arquivo.files[0];
    arquivo.value = '';
    if (f && await importarConfigAgenda(f)) {
      const corpo = painel.querySelector('#agd-antigo-corpo');
      corpo.innerHTML = '';
      corpo.hidden = false;
      painel.querySelector('#agd-antigo').setAttribute('aria-expanded', 'true');
      renderizarSecaoAgendaMassa(corpo);
    }
  });
  document.body.appendChild(_agdHost);
  const conteudo = painel.querySelector('#agd-conteudo');
  // O planejador antigo fica recolhido (div + botão, não <details>: o overflow do details quebraria o cabeçalho/rodapé fixos dele)
  conteudo.innerHTML = `<div id="syn-sec"></div>
    <button class="agd-antigo-toggle" id="agd-antigo" aria-expanded="false">${icone('lapis')}<span>Planejar aqui (modo antigo)</span><span class="agd-antigo-seta"></span></button>
    <div id="agd-antigo-corpo" hidden></div>`;
  const toggleAntigo = conteudo.querySelector('#agd-antigo');
  toggleAntigo.addEventListener('click', () => {
    const corpo = conteudo.querySelector('#agd-antigo-corpo');
    corpo.hidden = !corpo.hidden;
    toggleAntigo.setAttribute('aria-expanded', String(!corpo.hidden));
  });
  renderizarSecaoSynora(conteudo.querySelector('#syn-sec'));
  renderizarSecaoAgendaMassa(conteudo.querySelector('#agd-antigo-corpo'));
}

function fecharPainelAgendador() {
  if (_agdHost) _agdHost.style.display = 'none';
}

function alternarPainelAgendador() {
  if (_agdHost && _agdHost.style.display !== 'none') fecharPainelAgendador();
  else abrirPainelAgendador();
}

function criarBotaoAgendador() {
  if (document.getElementById('agd-botao')) return;
  const btn = document.createElement('div');
  btn.id = 'agd-botao';
  btn.innerHTML = icone('calendario').replace('class="agd-ic "', 'width="16" height="16" style="color:#ff7a2f"') + '<span>Agendador</span>';
  btn.style.cssText = AGD_BOTAO_CSS;
  btn.addEventListener('mouseenter', () => { btn.style.transform = 'translateY(-1px)'; btn.style.boxShadow = '0 10px 28px rgba(0,0,0,.5),0 0 0 4px rgba(255,122,47,.18)'; });
  btn.addEventListener('mouseleave', () => { btn.style.transform = ''; btn.style.boxShadow = '0 8px 24px rgba(0,0,0,.45),0 0 0 4px rgba(255,122,47,.08)'; });
  btn.addEventListener('click', alternarPainelAgendador);
  document.body.appendChild(btn);
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.tipo === 'AGD_TOGGLE_PAINEL') alternarPainelAgendador();
});

// ═══════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════

retomarAgendaMassa().catch(err => _etapaAgenda('erro geral: ' + err.message));
criarBotaoAgendador();
setTimeout(_synAutoVerificar, 4000);
setInterval(_synAutoVerificar, SYN_AUTO_INTERVALO);
