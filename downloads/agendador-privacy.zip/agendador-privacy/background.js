/* Agendador Privacy — background.js (service worker) */

importScripts('synora.js');

const MODELOS_MIGRADOS = {
  'cognitivecomputations/dolphin-llama-3-70b': 'google/gemma-4-31b-it',
  'eva-unit-01/eva-llama-3.33-70b': 'google/gemma-4-31b-it',
  'neversleep/llama-3.1-lumimaid-70b': 'google/gemma-4-31b-it',
  'cognitivecomputations/dolphin-3.0-llama-3.3-70b': 'google/gemma-4-31b-it',
  'nousresearch/hermes-4-70b': 'google/gemma-4-31b-it',
  'meta-llama/llama-3.3-70b-instruct:free': 'google/gemma-4-31b-it',
  'sao10k/l3.3-euryale-70b': 'google/gemma-4-31b-it',
  'thedrummer/cydonia-24b-v4.1': 'google/gemma-4-31b-it',
  'google/gemma-4-26b-a4b-it': 'google/gemma-4-31b-it',
};

const CONFIG_PADRAO = {
  apiUrl: 'https://openrouter.ai/api/v1/chat/completions',
  modelo: 'google/gemma-4-31b-it',
  modeloVenda: 'google/gemma-4-31b-it'
};

(async () => {
  // A chave da API NÃO fica no código: cada PC cola a sua em Configurações (engrenagem no topo do painel)
  const dados = await chrome.storage.local.get(['apiUrl', 'modelo', 'modeloVenda']);
  const updates = {};
  if (!dados.apiUrl) updates.apiUrl = CONFIG_PADRAO.apiUrl;
  if (!dados.modelo) updates.modelo = CONFIG_PADRAO.modelo;
  if (!dados.modeloVenda) updates.modeloVenda = CONFIG_PADRAO.modeloVenda;
  if (dados.modelo && MODELOS_MIGRADOS[dados.modelo]) updates.modelo = MODELOS_MIGRADOS[dados.modelo];
  if (dados.modeloVenda && MODELOS_MIGRADOS[dados.modeloVenda]) updates.modeloVenda = MODELOS_MIGRADOS[dados.modeloVenda];
  if (Object.keys(updates).length > 0) {
    await chrome.storage.local.set(updates);
    console.log('[Agendador] Config inicializada:', updates);
  }
})();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.tipo === 'GERAR_COPIES_MASSA') {
    gerarCopiesMassa(msg.dados, sender.tab?.id).then(sendResponse).catch(err => {
      sendResponse({ erro: err.message || 'Erro ao gerar copies' });
    });
    return true;
  }
  if (msg.tipo === 'AGD_TESTAR_CHAVE') {
    testarChave(msg.apiKey).then(sendResponse);
    return true;
  }
  if (typeof msg.tipo === 'string' && msg.tipo.startsWith('SYN_')) {
    tratarSynora(msg).then(sendResponse).catch(err => sendResponse({ erro: String((err && err.message) || err) }));
    return true;
  }
});

// ═══════════════════════════════════════════════
// SYNORA COPYS (Firebase) — login + fila de agendamentos (agenda_fila) + Acervo (agenda_acervo)
// Mesmo jeito da extensão Synora Coletor: REST sem SDK, só o refresh token fica guardado (a senha nunca).
// ═══════════════════════════════════════════════

async function tratarSynora(msg) {
  switch (msg.tipo) {
    case 'SYN_LOGIN': return { ok: true, email: await fbLogin(msg.email, msg.senha) };
    case 'SYN_SAIR': await fbSair(); return { ok: true };
    case 'SYN_STATUS': return { ok: true, email: await fbStatus() };
    case 'SYN_FILA_LISTAR': return { ok: true, docs: await fsListarFilaPendente() };
    case 'SYN_FILA_ATUALIZAR': return { ok: true, ...(await fsAtualizarFila(msg.id, msg.campos, msg.updateTime)) };
    case 'SYN_ACERVO_GRAVAR': return { ok: true, ...(await fsGravarAcervo(msg.modelo, msg.itens, msg.modeloId)) };
    case 'SYN_MINHAS_LISTAR': return { ok: true, modelos: await fsListarMinhas() };
  }
  return { erro: 'mensagem desconhecida' };
}

const fbGet = k => chrome.storage.local.get(k);
const fbSet = o => chrome.storage.local.set(o);

async function fbLogin(email, senha) {
  if (!email || !senha) throw new Error('Preencha e-mail e senha');
  const r = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=' + SYN_FB_KEY, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: senha, returnSecureToken: true })
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    const cod = (j.error && j.error.message) || '';
    throw new Error(/INVALID|PASSWORD|EMAIL_NOT_FOUND|CREDENTIAL/.test(cod) ? 'E-mail ou senha incorretos' : /TOO_MANY/.test(cod) ? 'Muitas tentativas, espere um pouco' : 'Erro ao entrar: ' + (cod || r.status));
  }
  await fbSet({ fbEmail: j.email, fbRefresh: j.refreshToken, fbToken: j.idToken, fbExp: Date.now() + (Number(j.expiresIn) - 120) * 1000 });
  return j.email;
}

async function fbToken(forcar) {
  const s = await fbGet(['fbRefresh', 'fbToken', 'fbExp']);
  if (!s.fbRefresh) throw new Error('Entre com o login do Synora no painel do Agendador');
  if (!forcar && s.fbToken && s.fbExp > Date.now()) return s.fbToken;
  const r = await fetch('https://securetoken.googleapis.com/v1/token?key=' + SYN_FB_KEY, {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(s.fbRefresh)
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { await fbSet({ fbToken: null, fbExp: 0 }); throw new Error('Login do Synora expirou, entre de novo no painel do Agendador'); }
  await fbSet({ fbRefresh: j.refresh_token, fbToken: j.id_token, fbExp: Date.now() + (Number(j.expires_in) - 120) * 1000 });
  return j.id_token;
}

async function fbStatus() {
  const s = await fbGet(['fbEmail', 'fbRefresh']);
  return s.fbRefresh ? s.fbEmail : null;
}

async function fbSair() {
  await fbSet({ fbEmail: null, fbRefresh: null, fbToken: null, fbExp: 0 });
}

// POST no Firestore REST com o token; se der 401, renova o token e tenta uma vez de novo
async function fsPost(caminho, corpo) {
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    const token = await fbToken(tentativa > 0);
    const r = await fetch(`https://firestore.googleapis.com/v1/${caminho}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify(corpo)
    });
    if (r.status === 401 && tentativa === 0) continue;
    const j = await r.json().catch(() => null);
    if (!r.ok) {
      const e = Array.isArray(j) ? j[0] && j[0].error : j && j.error;
      const msg = (e && e.message) || 'erro ' + r.status;
      const err = new Error(r.status === 403 ? 'Firebase recusou (permissão): ' + msg : 'Firebase: ' + msg);
      err.status = r.status;
      err.codigo = e && e.status;
      throw err;
    }
    return j;
  }
}

async function fsListarFilaPendente() {
  const resp = await fsPost(`${SYN_FB_PROJ}:runQuery`, {
    structuredQuery: {
      from: [{ collectionId: 'agenda_fila' }],
      where: { fieldFilter: { field: { fieldPath: 'status' }, op: 'EQUAL', value: { stringValue: 'pendente' } } },
      limit: 200
    }
  });
  return synDecodeRunQuery(resp);
}

const CAMPOS_FILA = ['status', 'ok', 'falhas', 'idx', 'progresso', 'nota'];
// As gravações do mesmo documento saem uma de cada vez, na ordem em que chegaram
const _filaGravacoes = new Map();

function fsAtualizarFila(id, campos, updateTime) {
  if (!/^[A-Za-z0-9_-]{1,200}$/.test(String(id || ''))) return Promise.reject(new Error('id da fila inválido'));
  const limpos = {};
  for (const k of CAMPOS_FILA) if (campos && campos[k] !== undefined) limpos[k] = campos[k];
  const write = {
    update: { name: `${SYN_FB_PROJ}/agenda_fila/${id}`, fields: synFsEncodeCampos(limpos) },
    updateMask: { fieldPaths: Object.keys(limpos) },
    updateTransforms: [{ fieldPath: 'atualizadoEm', setToServerValue: 'REQUEST_TIME' }],
    // Nunca recria um item que o site já cancelou (apagou); com updateTime, só grava se ninguém mexeu desde a leitura
    currentDocument: updateTime ? { updateTime } : { exists: true }
  };
  const anterior = _filaGravacoes.get(id) || Promise.resolve();
  const agora = anterior.catch(() => {}).then(async () => {
    try {
      await fsPost(`${SYN_FB_PROJ}:commit`, { writes: [write] });
      return { gravado: true };
    } catch (err) {
      if (err.codigo === 'FAILED_PRECONDITION' || err.codigo === 'NOT_FOUND') {
        throw new Error(updateTime
          ? 'Essa fila mudou ou foi cancelada no site (talvez outro PC já pegou). Atualize a lista.'
          : 'Essa fila não existe mais no site (foi cancelada).');
      }
      throw err;
    }
  });
  _filaGravacoes.set(id, agora);
  agora.finally(() => { if (_filaGravacoes.get(id) === agora) _filaGravacoes.delete(id); }).catch(() => {});
  return agora;
}

// Modelos da agência cadastradas na Agenda do site (agenda_cfg com propria: true)
async function fsListarMinhas() {
  const resp = await fsPost(`${SYN_FB_PROJ}:runQuery`, {
    structuredQuery: {
      from: [{ collectionId: 'agenda_cfg' }],
      where: { fieldFilter: { field: { fieldPath: 'propria' }, op: 'EQUAL', value: { booleanValue: true } } },
      select: { fields: [{ fieldPath: 'nome' }, { fieldPath: 'contaPrivacy' }] },
      limit: 300
    }
  });
  return synDecodeRunQuery(resp)
    .filter(d => /^p/.test(d.id))
    .map(d => ({ id: d.id, nome: String(d.nome || '').trim(), contaPrivacy: synNormConta(d.contaPrivacy) }))
    .sort((a, b) => a.nome.localeCompare(b.nome));
}

async function fsGravarAcervo(modelo, itens, modeloId) {
  const nome = String(modelo || '').trim();
  if (!nome) throw new Error('Falta o nome da modelo no Synora');
  const lista = (Array.isArray(itens) ? itens : [])
    .filter(x => x && typeof x.nome === 'string' && x.nome.trim())
    .map(x => ({ nome: x.nome.trim().slice(0, 200), preco: String(x.preco ?? '').slice(0, 20) }));
  // id da modelo da agência (o mesmo doc da Agenda); sem ele cai no id antigo pelo nome
  const id = /^p[A-Za-z0-9_-]{1,80}$/.test(String(modeloId || '')) ? modeloId : synIdModelo(nome);
  await fsPost(`${SYN_FB_PROJ}:commit`, {
    writes: [{
      update: { name: `${SYN_FB_PROJ}/agenda_acervo/${id}`, fields: synFsEncodeCampos({ itens: lista, modelo: nome }) },
      updateTransforms: [{ fieldPath: 'em', setToServerValue: 'REQUEST_TIME' }]
    }]
  });
  return { modeloId: id, total: lista.length };
}

// Confere a chave na OpenRouter e devolve o uso/limite de crédito dela
async function testarChave(apiKey) {
  if (!apiKey) return { erro: 'Cole a chave primeiro.' };
  try {
    const r = await fetch('https://openrouter.ai/api/v1/key', { headers: { Authorization: `Bearer ${apiKey}` } });
    if (r.status === 401) return { erro: 'Chave inválida ou revogada.' };
    if (!r.ok) return { erro: `A OpenRouter respondeu ${r.status}.` };
    const d = (await r.json()).data || {};
    return { ok: true, uso: d.usage, limite: d.limit, restante: d.limit_remaining, gratis: d.is_free_tier };
  } catch (err) {
    return { erro: 'Não consegui falar com a OpenRouter: ' + err.message };
  }
}

// Clique no ícone da extensão abre/fecha o painel na aba da Privacy
chrome.action.onClicked.addListener((tab) => {
  if (tab?.id) chrome.tabs.sendMessage(tab.id, { tipo: 'AGD_TOGGLE_PAINEL' }).catch(() => {});
});

// A IA não aguenta muitas copies numa resposta só: gera em lotes de 30 até completar a quantidade,
// e pede de novo só as que faltaram quando um lote vem incompleto.
const COPIES_POR_LOTE = 30;

async function gerarCopiesMassa(dados, tabId) {
  const total = Math.min(Math.max(parseInt(dados.quantidade) || 5, 1), 500);
  const horarios = dados.horarios || [];
  const roteiro = dados.roteiro || [];
  const copies = [];
  let tentativasSemAvanco = 0;
  while (copies.length < total) {
    const faltam = Math.min(COPIES_POR_LOTE, total - copies.length);
    const ini = copies.length;
    if (tabId) chrome.tabs.sendMessage(tabId, { tipo: 'ACP_COPIES_PROGRESSO', feitas: copies.length, total }).catch(() => {});
    const r = await _gerarLoteCopies({
      ...dados,
      quantidade: faltam,
      horarios: horarios.slice(ini, ini + faltam),
      roteiro: roteiro.slice(ini, ini + faltam),
      // Evita repetir as que já saíram em programações anteriores (histórico) e as deste mesmo pedido
      evitar: [...(dados.historico || []).slice(-20), ...copies.slice(-15)]
    });
    if (r.erro) {
      // Já tem algumas: devolve o que deu, com aviso; senão, o erro
      if (copies.length) return { copies, aviso: `Gerei ${copies.length} de ${total}: ${r.erro}` };
      return r;
    }
    const novas = r.copies.slice(0, faltam);
    if (!novas.length) {
      if (++tentativasSemAvanco >= 3) break;
      continue;
    }
    tentativasSemAvanco = 0;
    copies.push(...novas);
  }
  if (!copies.length) return { erro: 'A IA não devolveu nenhuma copy. Tente de novo.' };
  return copies.length < total ? { copies, aviso: `A IA só devolveu ${copies.length} de ${total}. Clique de novo pra tentar completar.` } : { copies };
}

async function _gerarLoteCopies({ quantidade, horarios, briefing, prompt, tipos, emoji, persona, roteiro, oferta, evitar }) {
  const { apiUrl, apiKey, modelo } = await chrome.storage.local.get(['apiUrl', 'apiKey', 'modelo']);
  if (!apiUrl || !apiKey) return { erro: 'Falta a chave da OpenRouter: cole em Configurações (engrenagem no topo do painel).' };

  const n = Math.min(Math.max(parseInt(quantidade) || 5, 1), COPIES_POR_LOTE);
  const pedido = (persona
      ? `PERSONA DA CRIADORA (escreva TODAS as mensagens como essa personagem, com o jeito, vocabulário e rotina dela; ela é adulta, 18+):\n${persona}\n\n`
      : '')
    + `Escreva ${n} mensagens em massa DIFERENTES entre si.`
    + (horarios?.length ? `\nHorário de envio de cada uma, na ordem: ${horarios.slice(0, n).join(', ')}` : '')
    + (roteiro?.length
      ? `\nASSUNTO PRINCIPAL de cada mensagem, NESTA ORDEM (respeite exatamente o assunto de cada horário; uma oferta que vem depois de aquecimento pode puxar o gancho dele):\n${roteiro.slice(0, n).map((r, i) => `${i + 1}. ${r}`).join('\n')}`
      : '')
    + (roteiro?.length && oferta ? `\nDetalhe da oferta (use exatamente isto, não invente outro valor): ${oferta}` : '')
    + (briefing ? `\nTema de hoje: ${briefing}` : '')
    + (tipos?.length ? `\n${roteiro?.length ? 'Abordagens pra variar o jeito de chamar' : 'Tipos de copy (use só estes, alternando)'}: ${tipos.join('; ')}` : '')
    + (emoji ? `\nEmojis: ${emoji}` : '')
    + (evitar?.length ? `\nJá foram escritas estas (NÃO repita nem copie o começo delas):\n${evitar.map(c => `- ${c.replace(/\s+/g, ' ').substring(0, 120)}`).join('\n')}` : '')
    + `\nResponda SÓ com as mensagens, sem numeração, separadas por uma linha contendo apenas ---`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: montarHeaders(apiUrl, apiKey),
    body: JSON.stringify({
      model: modelo || CONFIG_PADRAO.modelo,
      messages: [
        { role: 'system', content: prompt },
        { role: 'user', content: pedido }
      ],
      temperature: 1,
      max_tokens: 3000
    })
  });

  if (!response.ok) {
    if (response.status === 401) return { erro: 'Chave da API inválida ou revogada: troque em Configurações (engrenagem no topo).' };
    if (response.status === 429) return { erro: 'Limite da API atingido. Espere 1 minuto.' };
    return { erro: `Erro da API (${response.status})` };
  }

  const data = await response.json();
  const texto = data.choices?.[0]?.message?.content || '';
  const copies = texto.split(/\n\s*-{3,}\s*\n?/)
    .map(c => c.trim().replace(/^\d+[.)]\s*/, '').replace(/^["“]|["”]$/g, '').trim())
    .filter(c => c && c !== '---');
  if (!copies.length) return { erro: 'A IA não devolveu nenhuma copy. Tente de novo.' };
  return { copies };
}

function montarHeaders(apiUrl, apiKey) {
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${apiKey}`
  };

  if (apiUrl.includes('openrouter.ai')) {
    headers['HTTP-Referer'] = 'https://privacy.com.br';
    headers['X-Title'] = 'Assistente de Chat Privacy';
  }

  return headers;
}
