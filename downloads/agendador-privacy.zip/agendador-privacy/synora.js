/* Agendador Privacy — synora.js
 * Funções puras compartilhadas entre o background (importScripts) e o content script (manifest):
 * conversão de valores do Firestore REST, id da modelo igual ao do site Synora Copys,
 * qual fila é desta conta e qual status mandar pro site no fim do agendamento.
 * Sem chrome.* e sem DOM aqui, pra dar pra testar no Node. */

const SYN_FB_KEY = 'AIzaSyCJ8kKdGZHhHzsFYicUGzyy9Z_J-aoiPmM';
const SYN_FB_DB = 'projects/synora-copys/databases/(default)';
const SYN_FB_PROJ = SYN_FB_DB + '/documents';

// ── Igual ao app.js do site (idModeloFirebase/cyrb53/normId). Mudar aqui sem mudar lá quebra o vínculo. ──
function synCyrb53(str) {
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0, ch; i < str.length; i++) { ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507); h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507); h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}
function synNormId(t) { return String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[\s\p{P}\p{M}\p{C}]/gu, ''); }
function synIdModelo(nome) { return 'm' + synCyrb53(synNormId(nome)).toString(36); }

// @ da conta na Privacy, sem "@" nem espaço, minúsculo (o site guarda sem @)
function synNormConta(v) { return String(v || '').trim().replace(/^@+/, '').replace(/\s+/g, '').toLowerCase(); }

// ── Firestore REST: valor → JS e JS → valor ──
function synFsDecode(v) {
  if (!v || typeof v !== 'object') return null;
  if ('stringValue' in v) return v.stringValue;
  if ('integerValue' in v) return Number(v.integerValue);
  if ('doubleValue' in v) return Number(v.doubleValue);
  if ('booleanValue' in v) return !!v.booleanValue;
  if ('nullValue' in v) return null;
  if ('timestampValue' in v) return v.timestampValue; // texto ISO
  if ('arrayValue' in v) return (v.arrayValue.values || []).map(synFsDecode);
  if ('mapValue' in v) return synFsDecodeCampos(v.mapValue.fields || {});
  if ('referenceValue' in v) return v.referenceValue;
  if ('geoPointValue' in v) return { ...v.geoPointValue };
  return null;
}
function synFsDecodeCampos(fields) {
  const o = {};
  for (const [k, v] of Object.entries(fields || {})) o[k] = synFsDecode(v);
  return o;
}
function synFsEncode(v) {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === 'boolean') return { booleanValue: v };
  if (typeof v === 'number') return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
  if (typeof v === 'string') return { stringValue: v };
  if (v instanceof Date) return { timestampValue: v.toISOString() };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(synFsEncode) } };
  if (typeof v === 'object') return { mapValue: { fields: synFsEncodeCampos(v) } };
  return { stringValue: String(v) };
}
function synFsEncodeCampos(obj) {
  const f = {};
  for (const [k, v] of Object.entries(obj || {})) if (v !== undefined) f[k] = synFsEncode(v);
  return f;
}
// Documento REST { name, fields, createTime, updateTime } → { id, ...campos, _updateTime }
function synFsDecodeDoc(doc) {
  if (!doc || !doc.name) return null;
  return { id: doc.name.split('/').pop(), ...synFsDecodeCampos(doc.fields), _updateTime: doc.updateTime || '' };
}
// Resposta do documents:runQuery (lista de { document?, readTime }) → docs decodificados, mais antigos primeiro
function synDecodeRunQuery(resp) {
  const docs = (Array.isArray(resp) ? resp : []).map(r => r && synFsDecodeDoc(r.document)).filter(Boolean);
  const t = d => { const ms = Date.parse(d.criadoEm || ''); return isNaN(ms) ? Infinity : ms; };
  return docs.sort((a, b) => t(a) - t(b));
}

// ── Fila: qual é desta conta ──
// Com @ dos dois lados, só o @ decide (mesmo nome em contas diferentes não mistura). Sem @, compara o nome da modelo.
function synFilaDaConta(doc, conta) {
  if (!conta) return false;
  const h = synNormConta(conta.handle), dc = synNormConta(doc && doc.contaPrivacy);
  if (h && dc) return h === dc;
  const n = synNormId(conta.nome);
  return !!n && synNormId(doc && doc.modelo) === n;
}
function synSepararFilas(docs, conta) {
  const daConta = [], outras = [];
  for (const d of docs || []) (synFilaDaConta(d, conta) ? daConta : outras).push(d);
  return { daConta, outras };
}

// Itens da fila do site → itens no formato que o robô (retomarAgendaMassa) usa
function synItensParaJob(itens) {
  return (Array.isArray(itens) ? itens : []).filter(it => it && typeof it === 'object').map(it => ({
    dia: String(it.dia || ''),
    hora: String(it.hora || ''),
    mensagem: String(it.mensagem || ''),
    pack: it.pack && typeof it.pack === 'object'
      ? { tipo: it.pack.tipo === 'video' ? 'video' : 'pack', apelido: String(it.pack.apelido || ''), preco: String(it.pack.preco ?? ''), nome: String(it.pack.nome || '') }
      : null
  }));
}

// Período "12/11 → 15/11" e quantos horários já passaram
function synResumoFila(doc, agora = Date.now()) {
  const itens = Array.isArray(doc && doc.itens) ? doc.itens : [];
  const dias = [...new Set(itens.map(it => it && it.dia).filter(Boolean))].sort();
  const curto = iso => { const p = String(iso).split('-'); return p.length === 3 ? `${p[2]}/${p[1]}` : String(iso); };
  const periodo = !dias.length ? '' : dias.length === 1 ? curto(dias[0]) : `${curto(dias[0])} → ${curto(dias[dias.length - 1])}`;
  const passados = itens.filter(it => {
    const ms = Date.parse(`${it && it.dia}T${it && it.hora}:00`);
    return !isNaN(ms) && ms < agora;
  }).length;
  return { total: Number(doc && doc.total) || itens.length, periodo, passados };
}

// ── Status que vai pro site quando o agendamento termina ──
// motivo: 'fim' (passou por todos), 'erros' (3 erros seguidos), 'teste' (modo teste parou antes de enviar),
//         'parado' (clicou em "Parar agendamento")
const synEhPulado = f => /^\S+ \S+: pulado \(/.test(String(f)) || /^pulado\b/.test(String(f));
function synStatusFinal(job, motivo) {
  const total = Array.isArray(job.itens) ? job.itens.length : (Number(job.total) || 0);
  const idx = Number(job.idx) || 0, ok = Number(job.ok) || 0;
  const falhas = Array.isArray(job.falhas) ? job.falhas.map(String) : [];
  const base = { ok, idx, progresso: `${Math.min(idx, total)}/${total}` };
  if (motivo === 'parado') {
    if (!idx && !ok && !falhas.length) {
      return { ...base, status: 'pendente', falhas: [], nota: 'Parado na extensão antes de agendar qualquer disparo; dá pra mandar de novo.' };
    }
    falhas.push(`parado pelo usuário: faltaram ${Math.max(0, total - idx)} de ${total}`);
    return { ...base, status: 'erro', falhas, nota: `Parado pelo usuário: ${ok} de ${total} agendado(s).` };
  }
  if (motivo === 'teste') {
    falhas.push('teste: parou antes de enviar');
    return { ...base, status: 'concluido', falhas, nota: 'Teste: tudo preenchido na Privacy, sem enviar.' };
  }
  if (motivo === 'erros') return { ...base, status: 'erro', falhas, nota: `Parou depois de 3 erros seguidos: ${ok} de ${total} agendado(s).` };
  const status = falhas.some(f => !synEhPulado(f)) ? 'erro' : 'concluido';
  return { ...base, status, falhas, nota: `${ok} de ${total} agendado(s).` };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    SYN_FB_KEY, SYN_FB_DB, SYN_FB_PROJ, synCyrb53, synNormId, synIdModelo, synNormConta,
    synFsDecode, synFsDecodeCampos, synFsEncode, synFsEncodeCampos, synFsDecodeDoc, synDecodeRunQuery,
    synFilaDaConta, synSepararFilas, synItensParaJob, synResumoFila, synEhPulado, synStatusFinal
  };
}
