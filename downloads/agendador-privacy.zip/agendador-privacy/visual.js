/* Agendador Privacy — visual.js
 * Tudo que é aparência: fonte, ícones e o CSS do painel (vive dentro do shadow DOM).
 * Carregado antes do content.js (ver manifest.json). */

// Fonte: @font-face não funciona dentro de shadow DOM, então a fonte entra na página.
(function carregarFonte() {
  if (document.getElementById('agd-fonte')) return;
  const link = document.createElement('link');
  link.id = 'agd-fonte';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
  (document.head || document.documentElement).appendChild(link);
})();

// Ícones (traço 24x24, estilo Lucide)
const _ICONES = {
  calendario: '<rect x="3" y="4" width="18" height="18" rx="3"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  raio: '<path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/>',
  pessoa: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  brilho: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 3v4M17 5h4"/>',
  lista: '<path d="M9 6h12M9 12h12M9 18h12"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
  pacote: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
  relogio: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  fechar: '<path d="M18 6 6 18M6 6l12 12"/>',
  mapa: '<path d="M9 3 3 6v15l6-3 6 3 6-3V3l-6 3-6-3z"/><path d="M9 3v15M15 6v15"/>',
  atualizar: '<path d="M21 12a9 9 0 1 1-2.6-6.4L21 8"/><path d="M21 3v5h-5"/>',
  lixo: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',
  lapis: '<path d="M17 3l4 4L8 20H4v-4z"/>',
  mais: '<path d="M12 5v14M5 12h14"/>',
  frasco: '<path d="M9 3h6M10 3v6L4.5 18.5A2 2 0 0 0 6.2 21.5h11.6a2 2 0 0 0 1.7-3L14 9V3"/><path d="M7 15h10"/>',
  mensagem: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  seta: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  alerta: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
  parar: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  baixar: '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 21h14"/>',
  enviar: '<path d="M12 21V9M7 14l5-5 5 5"/><path d="M5 3h14"/>',
  olho: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  engrenagem: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  chave: '<circle cx="7.5" cy="15.5" r="4.5"/><path d="m10.7 12.3 9.8-9.8M17 6l3 3M14 9l2 2"/>',
  carregando: '<path d="M21 12a9 9 0 1 1-6.2-8.6"/>'
};

function icone(nome, classe = '') {
  return `<svg class="agd-ic ${classe}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${_ICONES[nome] || ''}</svg>`;
}

const AGD_CSS = `
:host { all: initial; }
#acp-embedded {
  --bg: #0f0f12; --surface: #17171c; --surface-2: #1e1e25; --input: #0b0b0e;
  --border: #25252d; --border-2: #32323c;
  --text: #f3f0eb; --text-2: #bdb7af; --muted: #8a857f; --faint: #5d5954;
  --accent: #ff7a2f; --accent-2: #e2601a; --accent-soft: rgba(255,122,47,0.12); --accent-line: rgba(255,122,47,0.45);
  --ok: #34c77b; --warn: #f5a524; --danger: #f25a4e;
  --r-lg: 18px; --r-md: 12px; --r-sm: 9px;

  position: fixed; top: 16px; right: 16px; bottom: 16px; z-index: 2147483646;
  width: 400px; max-width: calc(100vw - 32px);
  display: flex; flex-direction: column; overflow: hidden;
  font: 13px/1.45 'Inter', -apple-system, 'Segoe UI', sans-serif; color: var(--text);
  -webkit-font-smoothing: antialiased;
  background: radial-gradient(440px 240px at 100% 0%, rgba(255,122,47,0.09), transparent 70%), var(--bg);
  border: 1px solid var(--border); border-radius: 22px;
  box-shadow: 0 24px 64px rgba(0,0,0,0.55), inset 0 0 0 1px rgba(255,255,255,0.03);
  animation: agdEntrar .22s cubic-bezier(.2,.8,.2,1);
}
@keyframes agdEntrar { from { opacity: 0; transform: translateY(8px) scale(.985); } to { opacity: 1; transform: none; } }
@keyframes agdGirar { to { transform: rotate(360deg); } }
#acp-embedded *, #acp-embedded *::before, #acp-embedded *::after { box-sizing: border-box; }
#acp-embedded [hidden] { display: none !important; }
#acp-embedded button, #acp-embedded input, #acp-embedded textarea { font: inherit; color: inherit; }
#acp-embedded button { cursor: pointer; }
#acp-embedded button:disabled { opacity: .5; cursor: not-allowed; }
#acp-embedded :focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.agd-ic { width: 15px; height: 15px; flex-shrink: 0; display: block; }
.agd-girando { animation: agdGirar .8s linear infinite; }

/* ── topo ── */
#agd-topo { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 14px 12px 12px 16px; border-bottom: 1px solid var(--border); flex-shrink: 0; }
#agd-marca { display: flex; align-items: center; gap: 11px; min-width: 0; }
#agd-logo { width: 34px; height: 34px; border-radius: 11px; display: grid; place-items: center; color: #fff; flex-shrink: 0;
  background: linear-gradient(135deg, #ff8f4d, var(--accent-2)); box-shadow: 0 6px 18px rgba(255,122,47,.35); }
#agd-logo .agd-ic { width: 18px; height: 18px; }
#agd-nome { font-weight: 700; font-size: 14.5px; letter-spacing: -.015em; line-height: 1.15; }
#agd-sub { font-size: 11px; color: var(--muted); margin-top: 2px; }
.agd-topo-acoes { display: flex; gap: 2px; }
.agd-btn-icone { width: 32px; height: 32px; display: grid; place-items: center; border-radius: 10px; border: 1px solid transparent; background: none; color: var(--muted); transition: all .15s; }
.agd-btn-icone:hover { color: var(--text); background: rgba(255,255,255,.06); border-color: var(--border); }
.agd-btn-icone.agd-perigo:hover { color: var(--danger); background: rgba(242,90,78,.1); border-color: rgba(242,90,78,.3); }

#agd-conteudo { flex: 1; min-height: 0; overflow-y: auto; scrollbar-width: thin; scrollbar-color: var(--border-2) transparent; }
#acp-agenda-sec { display: flex; flex-direction: column; min-height: 100%; }

/* ── modelo ativa ── */
#acp-modelo-bar { display: flex; align-items: center; gap: 10px; margin: 12px 12px 10px; padding: 8px 8px 8px 10px; background: var(--surface); border: 1px solid var(--border); border-radius: var(--r-lg); }
#acp-modelo-card-info { display: flex; align-items: center; gap: 10px; flex: 1; min-width: 0; }
#acp-modelo-card-info img, .agd-avatar { width: 34px; height: 34px; border-radius: 50%; object-fit: cover; flex-shrink: 0; border: 2px solid var(--accent); box-shadow: 0 0 0 3px rgba(255,122,47,.15); }
.agd-avatar { display: grid; place-items: center; background: var(--surface-2); border: 1px dashed var(--border-2); box-shadow: none; color: var(--muted); }
#acp-modelo-nome { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
#acp-modelo-handle, .agd-modelo-vazio { font-size: 11px; color: var(--muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.agd-min0 { min-width: 0; }

/* ── abas ── */
#acp-header { position: sticky; top: 0; z-index: 2; margin: 0 12px 2px; padding: 3px; background: var(--surface); border: 1px solid var(--border); border-radius: 14px; box-shadow: 0 10px 16px -10px rgba(0,0,0,.8); }
#acp-tabs { display: grid; grid-template-columns: repeat(6, 1fr); gap: 2px; }
.acp-tab { display: flex; flex-direction: column; align-items: center; gap: 3px; padding: 7px 2px 6px; border: none; border-radius: 10px; background: none; color: var(--muted); font-size: 10.5px; font-weight: 600; transition: color .15s, background .15s; }
.acp-tab .agd-ic { width: 16px; height: 16px; }
.acp-tab:hover { color: var(--text); background: rgba(255,255,255,.04); }
.acp-tab-ativa { color: #fff; background: linear-gradient(135deg, rgba(255,122,47,.24), rgba(226,96,26,.14)); box-shadow: inset 0 0 0 1px var(--accent-line); }
.acp-tab-ativa .agd-ic { color: var(--accent); }

/* ── cards ── */
.acp-abatab-painel { padding: 6px 0 4px; }
.acp-card { margin: 8px 12px; padding: 13px; background: var(--surface); border: 1px solid var(--border); border-radius: var(--r-lg); }
.acp-card-label { display: flex; align-items: center; gap: 7px; margin-bottom: 10px; font-size: 12px; font-weight: 600; color: var(--text); }
.acp-card-label .agd-ic { color: var(--accent); }
.agd-label-extra { margin-left: auto; font-size: 11px; font-weight: 500; color: var(--muted); }
.agd-label-extra.agd-aviso { color: var(--warn); }
.agd-dica { font-size: 11.5px; color: var(--muted); margin: -4px 0 10px; line-height: 1.5; }
.agd-sub-label { font-size: 11px; font-weight: 500; color: var(--muted); margin: 0 0 6px; }
.agd-sub-label + .acp-pills { margin-bottom: 12px; }
.agd-status { font-size: 11.5px; color: var(--text-2); margin-top: 8px; line-height: 1.5; }
.agd-status:empty { display: none; }
.agd-aviso-txt { color: var(--warn); }

/* ── pílulas ── */
.acp-pills { display: flex; flex-wrap: wrap; gap: 5px; }
.agd-agitada { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin: -2px 0 10px; padding: 7px 7px 7px 11px; border-radius: 12px; background: var(--accent-soft); border: 1px solid var(--accent-line); font-size: 11.5px; color: #ffb488; }
.agd-agitada-card { flex-direction: column; align-items: stretch; margin: 12px 0 0; padding: 11px; }
.agd-agitada-txt { display: flex; align-items: center; gap: 7px; }
.agd-agitada-txt .agd-ic { width: 14px; height: 14px; flex: none; color: var(--accent); }
.agd-agitada-acoes { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-top: 9px; }
#acp-embedded .agd-agitada-btn { flex: none; padding: 6px 11px; border: 0; border-radius: 9px; background: var(--accent); color: #fff; font-size: 11.5px; font-weight: 600; white-space: nowrap; transition: filter .15s; }
#acp-embedded .agd-agitada-btn:hover { filter: brightness(1.1); }
#acp-embedded .agd-agitada-sec { background: var(--surface-2); color: var(--text); box-shadow: inset 0 0 0 1px var(--border-2); }
.agd-atalhos { display: flex; flex-wrap: wrap; gap: 4px; margin: -2px 0 10px; }
#acp-embedded .agd-atalhos button { padding: 4px 9px; border: 1px dashed var(--border-2); border-radius: 999px; background: none; color: var(--muted); font-size: 11px; font-weight: 500; transition: all .15s; }
#acp-embedded .agd-atalhos button:hover { border-style: solid; border-color: var(--accent-line); color: var(--text); background: var(--accent-soft); }
#acp-embedded .agd-atalhos [data-atalho="limpar"] { margin-left: auto; border-color: transparent; }
#acp-embedded .agd-atalhos [data-atalho="limpar"]:hover { color: var(--danger); background: rgba(242,90,78,.1); border-color: rgba(242,90,78,.3); }
.agd-grade-dias { display: grid; grid-template-columns: repeat(5, 1fr); gap: 5px; }
.agd-grade-horas { display: grid; grid-template-columns: repeat(6, 1fr); gap: 5px; }
.acp-pill { display: inline-flex; align-items: center; justify-content: center; gap: 5px; padding: 6px 11px; min-height: 30px;
  border: 1px solid var(--border-2); border-radius: 999px; background: var(--surface-2); color: var(--text-2);
  font-size: 11.5px; font-weight: 500; white-space: nowrap; transition: all .15s; }
.agd-grade-dias .acp-pill, .agd-grade-horas .acp-pill { padding: 6px 4px; border-radius: 10px; }
.acp-pill:hover { border-color: var(--accent-line); color: var(--text); background: #24242c; }
.acp-pill:active { transform: scale(.97); }
.acp-pill-ativo, .acp-pill-ativo:hover { background: linear-gradient(135deg, #ff8f4d, var(--accent-2)); border-color: transparent; color: #fff; font-weight: 600; box-shadow: 0 4px 12px rgba(255,122,47,.28); }
.agd-pill-icone { padding: 6px 8px; }
.agd-pill-icone:hover.agd-perigo { color: var(--danger); border-color: rgba(242,90,78,.4); background: rgba(242,90,78,.08); }

/* ── campos ── */
.acp-save-input, .acp-disparo-msg {
  width: 100%; padding: 9px 11px; background: var(--input); border: 1px solid var(--border-2); border-radius: var(--r-md);
  color: var(--text); font-size: 12.5px; transition: border-color .15s, box-shadow .15s; }
.acp-disparo-msg { resize: vertical; line-height: 1.5; min-height: 60px; }
.acp-save-input:focus, .acp-disparo-msg:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(255,122,47,.18); }
.acp-save-input::placeholder, .acp-disparo-msg::placeholder { color: var(--faint); }
#acp-embedded input[type="time"], #acp-embedded input[type="number"] { color-scheme: dark; }
.agd-campo { display: flex; flex-direction: column; gap: 5px; min-width: 0; }
.agd-campo > span { font-size: 11px; font-weight: 500; color: var(--muted); }
.agd-linha { display: flex; align-items: center; gap: 8px; }
.agd-linha-campo { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border); font-size: 12px; color: var(--text-2); }
.agd-linha-campo .acp-save-input { width: 72px; text-align: center; }
.agd-grade-3 { display: grid; grid-template-columns: .8fr 1fr 1fr; gap: 8px; }
.agd-espaco { margin-top: 8px; }
.agd-txt-persona { min-height: 120px; }
.agd-txt-curto { min-height: 64px; }

/* ── persona ── */
.agd-persona-linha { display: grid; grid-template-columns: 1fr 76px auto; gap: 8px; align-items: end; }
.agd-persona-linha .agd-btn-icone { margin-bottom: 2px; }
.agd-erro { margin-top: 6px; font-size: 11px; color: var(--danger); }
#acp-embedded .agd-invalido { border-color: rgba(242,90,78,.6); box-shadow: 0 0 0 3px rgba(242,90,78,.12); }
.agd-persona-conta { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 8px; margin-top: 10px; padding: 8px 10px; border: 1px solid var(--border); border-radius: 10px; background: var(--surface-2); font-size: 11.5px; color: var(--text-2); }
.agd-persona-conta > .agd-ic { width: 14px; height: 14px; color: var(--muted); }
.agd-persona-conta b { color: var(--text); font-weight: 600; }
.agd-persona-conta > span:not(.agd-pc-acoes) { flex: 1; min-width: 0; }
.agd-pc-acoes { display: flex; align-items: center; gap: 2px; margin-left: auto; }
#acp-embedded .agd-pc-acoes .agd-link { margin: 0; color: var(--accent); white-space: nowrap; }
#acp-embedded .agd-pc-acoes [data-persona-conta="soltar"] { color: var(--muted); padding: 3px 5px; }
.agd-dica-mini { margin-left: auto; font-size: 10.5px; color: var(--faint); }
#acp-persona-aviso { align-items: center; }
#acp-persona-aviso span { flex: 1; }
#acp-embedded #acp-persona-aviso .agd-link { color: var(--warn); font-weight: 600; white-space: nowrap; }
.agd-amostra { margin-top: 6px; padding: 9px 11px; border-radius: 10px; background: var(--input); border: 1px solid var(--border); font-size: 12px; line-height: 1.5; color: var(--text-2); white-space: pre-line; }
.agd-txt-msgs { min-height: 180px; }
.agd-txt-prompt { min-height: 160px; font-size: 11.5px; }

/* ── botões ── */
.acp-save-btn { display: flex; align-items: center; justify-content: center; gap: 7px; width: 100%; margin-top: 10px; padding: 10px 12px;
  border: 1px solid var(--accent-line); border-radius: var(--r-md); background: var(--accent-soft); color: #ffa36b;
  font-size: 12.5px; font-weight: 600; transition: all .15s; }
.acp-save-btn:hover:not(:disabled) { background: linear-gradient(135deg, #ff8f4d, var(--accent-2)); border-color: transparent; color: #fff; box-shadow: 0 6px 16px rgba(255,122,47,.3); }
.acp-save-btn:active:not(:disabled) { transform: scale(.985); }

/* ── detalhes (prompt) ── */
#acp-embedded details { margin-top: 10px; border: 1px solid var(--border); border-radius: var(--r-md); background: var(--input); overflow: hidden; }
#acp-embedded summary { list-style: none; display: flex; align-items: center; gap: 8px; padding: 10px 12px; font-size: 11.5px; color: var(--text-2); cursor: pointer; user-select: none; }
#acp-embedded summary::-webkit-details-marker { display: none; }
#acp-embedded summary::before { content: ''; width: 6px; height: 6px; border-right: 1.5px solid var(--muted); border-bottom: 1.5px solid var(--muted); transform: rotate(-45deg); transition: transform .2s; }
#acp-embedded details[open] summary::before { transform: rotate(45deg); }
#acp-embedded details textarea { display: block; width: calc(100% - 16px); margin: 0 8px 8px; }

/* ── roteiro ── */
/* cor de cada assunto (faixa, contagem, chips) */
#acp-embedded [data-assunto] { --c: #ff7a2f; }
#acp-embedded [data-assunto="sexting"] { --c: #ff4d8d; }
#acp-embedded [data-assunto="chamada"] { --c: #4da3ff; }
#acp-embedded [data-assunto="desc_chamada"] { --c: #38d0e0; }
#acp-embedded [data-assunto="desc_sexting"] { --c: #b98bff; }
#acp-embedded [data-assunto="pack"] { --c: #f5c542; }
#acp-embedded [data-assunto="video"] { --c: #3ed598; }
.agd-ponto { display: inline-block; flex: none; width: 7px; height: 7px; border-radius: 50%; background: var(--c); box-shadow: 0 0 0 3px color-mix(in srgb, var(--c) 18%, transparent); }

#acp-embedded .agd-link { margin-left: auto; display: inline-flex; align-items: center; gap: 5px; padding: 3px 8px; border: 0; border-radius: 8px; background: none; color: var(--muted); font-size: 11px; font-weight: 500; }
#acp-embedded .agd-link:hover { color: var(--text); background: var(--surface-2); }
.agd-link .agd-ic { width: 12px; height: 12px; color: inherit !important; }
.agd-roteiro-estado { margin-left: 6px; padding: 1px 7px; border-radius: 999px; background: var(--surface-2); color: var(--text-2); font-size: 10.5px; }
.agd-roteiro-estado:empty { display: none; }

.agd-roteiro-faixa { display: flex; gap: 2px; height: 8px; margin: 4px 0 8px; border-radius: 4px; overflow: hidden; }
.agd-roteiro-faixa span { flex: 1; background: var(--c); }
.agd-roteiro-contagem { display: flex; flex-wrap: wrap; gap: 4px 12px; margin-bottom: 10px; font-size: 11px; color: var(--text-2); }
.agd-roteiro-contagem span { display: inline-flex; align-items: center; gap: 6px; }

.agd-roteiro-linha { display: grid; grid-template-columns: 44px 1fr; gap: 4px 8px; align-items: center; margin-top: 4px; }
.agd-roteiro-hora { font-size: 12px; font-weight: 600; color: var(--text-2); font-variant-numeric: tabular-nums; }
.agd-roteiro-chip { display: flex; align-items: center; gap: 9px; width: 100%; min-height: 34px; padding: 6px 10px 6px 12px; text-align: left;
  border: 1px solid var(--border); border-left: 3px solid var(--c); border-radius: 10px; background: var(--surface-2); color: var(--text); font-size: 12.5px; transition: border-color .15s, background .15s; }
.agd-roteiro-chip:hover { background: #24242c; border-color: var(--border-2); border-left-color: var(--c); }
.agd-roteiro-chip > span { flex: 1; }
.agd-roteiro-chip .agd-ic { width: 14px; height: 14px; color: var(--faint); }
.agd-roteiro-chip.agd-falta .agd-ic:not(.agd-roteiro-seta) { color: var(--warn); }
.agd-roteiro-seta { transform: rotate(90deg); transition: transform .15s; }
.agd-aberta .agd-roteiro-chip { border-color: var(--border-2); border-left-color: var(--c); background: #24242c; }
.agd-aberta .agd-roteiro-seta { transform: rotate(-90deg); }
.agd-roteiro-opcoes { grid-column: 2; display: grid; grid-template-columns: 1fr 1fr; gap: 4px; padding: 6px; margin-bottom: 4px; background: var(--input); border: 1px solid var(--border); border-radius: 10px; }
.agd-roteiro-op { display: flex; align-items: center; gap: 8px; padding: 8px 10px; white-space: nowrap; border-left: 3px solid var(--c) !important; border: 1px solid transparent; border-radius: 8px; background: none; color: var(--text-2); font-size: 12px; text-align: left; }
.agd-roteiro-op:hover { background: var(--surface-2); color: var(--text); }
.agd-roteiro-op.agd-op-ativa { color: var(--text); background: color-mix(in srgb, var(--c) 12%, transparent); border-color: color-mix(in srgb, var(--c) 45%, transparent); }
.agd-campo-uso { font-style: normal; font-weight: 400; color: var(--faint); margin-left: 4px; }
.agd-vazio { font-size: 12px; color: var(--muted); padding: 12px; text-align: center; border: 1px dashed var(--border-2); border-radius: var(--r-md); }

/* ── pacotes ── */
.agd-pacote { display: grid; grid-template-columns: auto 1fr auto; gap: 8px; align-items: start; margin-top: 8px; padding: 10px; background: var(--surface-2); border: 1px solid var(--border); border-radius: 14px; transition: border-color .15s; }
.agd-pacote:hover { border-color: var(--border-2); }
.agd-pacote.agd-desligado { opacity: .55; }
.agd-pacote-campos { display: grid; grid-template-columns: 1fr; gap: 6px; min-width: 0; }
.agd-pacote-campos .agd-sub-grade { display: grid; grid-template-columns: 86px 1fr; gap: 6px; }
.agd-pacote .acp-save-input { padding: 7px 9px; font-size: 12px; }
.agd-pacote-lado { display: flex; flex-direction: column; gap: 6px; align-items: center; }
.agd-tipo { width: 32px; height: 32px; display: grid; place-items: center; border-radius: 10px; border: 1px solid var(--border-2); background: var(--input); font-size: 14px; }
.agd-tipo:hover { border-color: var(--accent-line); }
.agd-orfao { display: flex; align-items: center; gap: 8px; margin-top: 6px; padding: 8px 10px; border: 1px dashed var(--border-2); border-radius: 12px; font-size: 12px; color: var(--text-2); }
.agd-orfao > span:nth-child(2) { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.agd-aviso-box { display: flex; gap: 8px; align-items: flex-start; margin-top: 10px; padding: 9px 11px; border-radius: 12px; font-size: 11.5px; line-height: 1.45; color: var(--warn); background: rgba(245,165,36,.08); border: 1px solid rgba(245,165,36,.25); }
.agd-aviso-box .agd-ic { margin-top: 1px; }
.agd-prox { margin-top: 8px; font-size: 11.5px; color: var(--text-2); }
.agd-prox:empty { display: none; }
.agd-prox b { color: var(--text); }

/* ── switch ── */
.agd-switch { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--text-2); cursor: pointer; flex-shrink: 0; user-select: none; }
.agd-switch input { appearance: none; -webkit-appearance: none; margin: 0; position: relative; width: 34px; height: 20px; border-radius: 999px; background: var(--border-2); cursor: pointer; transition: background .2s; }
.agd-switch input::after { content: ''; position: absolute; top: 3px; left: 3px; width: 14px; height: 14px; border-radius: 50%; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,.4); transition: transform .2s; }
.agd-switch input:checked { background: var(--accent); }
.agd-switch input:checked::after { transform: translateX(14px); }
.agd-check { appearance: none; -webkit-appearance: none; margin: 0; width: 18px; height: 18px; border-radius: 6px; border: 1.5px solid var(--border-2); background: var(--input); cursor: pointer; display: grid; place-items: center; transition: all .15s; }
.agd-check:checked { background: var(--accent); border-color: var(--accent); }
.agd-check:checked::after { content: ''; width: 5px; height: 9px; border: solid #fff; border-width: 0 2px 2px 0; transform: translateY(-1px) rotate(45deg); }

/* ── rodapé ── */
#agd-rodape { position: sticky; bottom: 0; z-index: 3; margin-top: auto; padding: 10px 12px 12px; background: linear-gradient(to top, var(--bg) 75%, rgba(15,15,18,0)); border-top: 1px solid var(--border); }
.agd-rodape-linha { display: flex; align-items: center; gap: 12px; }
.acp-big-btn { flex: 1; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 12px; border: none; border-radius: 14px; font-size: 13.5px; font-weight: 700; letter-spacing: .01em; color: #fff;
  background: linear-gradient(135deg, #ff8f4d, var(--accent-2)); box-shadow: 0 8px 22px rgba(255,122,47,.32); transition: box-shadow .15s, filter .15s, transform .1s; }
.acp-big-btn:hover:not(:disabled) { filter: brightness(1.06); box-shadow: 0 10px 28px rgba(255,122,47,.48); }
.acp-big-btn:active:not(:disabled) { transform: scale(.985); }
.acp-big-btn .agd-ic { width: 16px; height: 16px; }
.acp-big-btn.agd-incompleto { background: var(--surface-2); color: var(--text-2); box-shadow: inset 0 0 0 1px var(--border-2); }
.acp-progress-bar { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; padding: 9px 11px; background: var(--surface); border: 1px solid var(--accent-line); border-radius: 12px; }
.acp-progress-text { font-size: 12px; color: var(--text-2); line-height: 1.45; }
#acp-agenda-ultimo { margin-bottom: 8px; padding: 9px 11px; border-radius: 12px; font-size: 11.5px; line-height: 1.45; white-space: pre-line; color: #ff9b92; background: rgba(242,90,78,.08); border: 1px solid rgba(242,90,78,.25); max-height: 120px; overflow-y: auto; }
/* ── prévia da programação ── */
.agd-folha { position: absolute; inset: 0; z-index: 5; display: flex; flex-direction: column; background: var(--bg); border-radius: 22px; animation: agd-sobe .18s ease-out; }
@keyframes agd-sobe { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
.agd-folha-topo { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; padding: 16px 12px 12px 16px; border-bottom: 1px solid var(--border); }
.agd-folha-titulo { display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 700; }
.agd-folha-titulo .agd-ic { color: var(--accent); }
.agd-folha-sub { margin-top: 3px; font-size: 11.5px; color: var(--muted); }
.agd-folha-corpo { flex: 1; overflow-y: auto; padding: 4px 14px 14px; scrollbar-width: thin; scrollbar-color: var(--border-2) transparent; }
.agd-previa-dia { position: sticky; top: 0; z-index: 1; padding: 12px 2px 6px; background: var(--bg); font-size: 11px; font-weight: 600; letter-spacing: .04em; text-transform: uppercase; color: var(--muted); }
.agd-previa-item { margin-top: 6px; padding: 9px 11px; background: var(--surface); border: 1px solid var(--border); border-left: 3px solid var(--c); border-radius: 10px; }
.agd-previa-meta { display: flex; align-items: center; gap: 8px; margin-bottom: 4px; font-size: 12px; font-variant-numeric: tabular-nums; }
.agd-previa-tag { font-size: 11px; color: var(--text-2); }
.agd-previa-texto { display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; font-size: 12px; line-height: 1.5; color: var(--text-2); white-space: pre-line; }
.agd-previa-texto .agd-ic { width: 13px; height: 13px; margin-right: 5px; vertical-align: -2px; color: var(--c); }
.agd-previa-nota { color: var(--faint); }
.agd-folha-rodape { display: flex; gap: 8px; padding: 12px 14px 14px; border-top: 1px solid var(--border); }
.agd-folha-rodape .acp-save-btn { width: auto; margin: 0; padding: 0 14px; }
#acp-embedded .agd-btn-sec { background: var(--surface-2); border-color: var(--border-2); color: var(--text-2); }
#acp-embedded .agd-btn-sec:hover { background: #24242c; color: var(--text); box-shadow: none; border-color: var(--border-2); }

/* ── copy: mensagens por horário ── */
.agd-msg-dia { margin: 12px 0 2px; font-size: 11px; font-weight: 600; letter-spacing: .04em; text-transform: uppercase; color: var(--muted); }
.agd-msg-dia:first-child { margin-top: 0; }
.agd-msg { margin-top: 6px; padding: 8px 8px 8px 10px; background: var(--surface-2); border: 1px solid var(--border); border-left: 3px solid var(--c); border-radius: 10px; }
.agd-msg-meta { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; font-size: 12px; font-variant-numeric: tabular-nums; }
.agd-msg-meta span { flex: 1; font-size: 11px; color: var(--text-2); }
#acp-embedded .agd-msg-refazer { width: 26px; height: 26px; border-radius: 8px; }
.agd-msg-refazer .agd-ic { width: 14px; height: 14px; }
#acp-embedded .agd-msg-txt { min-height: 0; field-sizing: content; max-height: 220px; padding: 7px 9px; font-size: 12.5px; line-height: 1.5; resize: vertical; }
#acp-embedded .agd-msg-txt:placeholder-shown { background: transparent; border-style: dashed; }
#acp-embedded .agd-link-centro { display: flex; margin: 6px auto 0; }
.agd-historico { margin-top: 8px; font-size: 11px; color: var(--muted); text-align: center; }
.agd-historico:empty { display: none; }
.agd-historico .agd-link { display: inline-flex; margin-left: 2px; padding: 1px 6px; }
.agd-prompt-acoes { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 0 8px 8px; font-size: 11px; color: var(--faint); }
#acp-embedded .agd-btn-auto { width: auto; margin: 0; padding: 8px 14px; }
.agd-sem-chave { margin: 8px 12px 0; align-items: center; }
.agd-sem-chave span { flex: 1; }
#acp-embedded .agd-sem-chave .agd-link { color: var(--warn); font-weight: 600; }
.agd-perigo-box { color: var(--danger); background: rgba(242,90,78,.08); border-color: rgba(242,90,78,.3); }
#agd-config .acp-card { margin-top: 12px; }

/* Fila do Synora */
.syn-card { margin-top: 12px; border-color: var(--accent-line); }
.syn-form { display: flex; flex-direction: column; gap: 8px; }
.syn-linha { display: flex; align-items: center; gap: 6px; font-size: 11.5px; }
.syn-linha b { color: var(--text); font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.syn-muted { color: var(--muted); }
.syn-subtitulo { margin: 12px 0 6px; font-weight: 600; color: var(--text-2); }
.syn-conta { display: flex; align-items: center; gap: 6px; margin-top: 8px; padding: 8px 10px; border: 1px solid var(--border); border-radius: 10px; background: var(--surface-2); font-size: 11.5px; color: var(--text-2); }
.syn-conta > span { display: flex; align-items: center; gap: 6px; min-width: 0; flex: 1; }
.syn-conta b { color: var(--text); }
.syn-conta .agd-ic { width: 14px; height: 14px; }
.syn-item { margin-top: 8px; padding: 11px; border: 1px solid var(--border-2); border-radius: var(--r-md); background: var(--surface-2); }
.syn-item-outra { border-style: dashed; border-color: rgba(245,165,36,.35); }
.syn-item-topo { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; font-size: 12.5px; }
.syn-item-info { font-size: 11.5px; color: var(--text-2); margin-top: 3px; }
.syn-badge { margin-left: auto; padding: 1px 8px; border-radius: 999px; font-size: 10.5px; font-weight: 600; color: #ffb488; background: var(--accent-soft); border: 1px solid var(--accent-line); }
#acp-embedded .syn-agendar { width: 100%; margin-top: 10px; padding: 9px; font-size: 12.5px; }
.syn-vazio { margin: 4px 0 0; display: flex; align-items: center; gap: 6px; }
.syn-aviso-outras { margin: 0 8px 8px; }
#syn-outras > .syn-item, #syn-lista-outras { padding: 0 8px 8px; }
.syn-acervo { margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--border); }
.syn-acervo .agd-campo { margin-bottom: 8px; }
#acp-embedded .agd-antigo-toggle { display: flex; align-items: center; gap: 8px; width: calc(100% - 24px); margin: 6px 12px 10px; padding: 10px 12px; border: 1px dashed var(--border-2); border-radius: var(--r-md); background: none; color: var(--muted); font-size: 12px; font-weight: 600; text-align: left; }
#acp-embedded .agd-antigo-toggle:hover { color: var(--text); border-style: solid; }
.agd-antigo-toggle > span:nth-child(2) { flex: 1; }
.agd-antigo-seta { width: 7px; height: 7px; border-right: 1.5px solid currentColor; border-bottom: 1.5px solid currentColor; transform: rotate(-45deg); transition: transform .2s; }
.agd-antigo-toggle[aria-expanded="true"] .agd-antigo-seta { transform: rotate(45deg); }

`;

// Aviso flutuante que aparece enquanto o robô agenda (fica fora do painel, direto na página)
const AGD_OVERLAY_CSS = 'position:fixed;left:16px;bottom:64px;width:320px;max-width:calc(100vw - 32px);background:#141418;color:#f3f0eb;padding:12px 14px;border-radius:16px;font:12.5px/1.45 Inter,-apple-system,"Segoe UI",sans-serif;z-index:2147483647;box-shadow:0 16px 40px rgba(0,0,0,.5);border:1px solid rgba(255,122,47,.5);white-space:pre-line';
const AGD_OVERLAY_BTN_CSS = 'margin-top:10px;padding:6px 14px;border:1px solid rgba(242,90,78,.5);border-radius:10px;background:rgba(242,90,78,.12);color:#ff9b92;font:600 12px Inter,-apple-system,sans-serif;cursor:pointer';
const AGD_BOTAO_CSS = 'position:fixed;bottom:16px;left:16px;display:flex;align-items:center;gap:7px;background:#141418;color:#f3f0eb;padding:9px 16px 9px 12px;border:1px solid rgba(255,122,47,.45);border-radius:999px;font:600 12.5px Inter,-apple-system,"Segoe UI",sans-serif;z-index:2147483646;box-shadow:0 8px 24px rgba(0,0,0,.45),0 0 0 4px rgba(255,122,47,.08);cursor:pointer;user-select:none;transition:transform .15s,box-shadow .15s';
